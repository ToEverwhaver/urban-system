import { ERROR_CODES } from '../constants';

/**
 * Base error class for BCCP
 */
export class BCCPError extends Error {
  public readonly code: string;
  public readonly details?: Record<string, unknown>;

  constructor(code: string, message: string, details?: Record<string, unknown>) {
    super(message);
    this.name = 'BCCPError';
    this.code = code;
    this.details = details;
    Object.setPrototypeOf(this, BCCPError.prototype);
  }

  toJSON(): Record<string, unknown> {
    return {
      name: this.name,
      code: this.code,
      message: this.message,
      details: this.details
    };
  }
}

/**
 * Signature validation error
 */
export class SignatureError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.INVALID_SIGNATURE, message, details);
    this.name = 'SignatureError';
  }
}

/**
 * Chain integrity error
 */
export class ChainError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.CHAIN_BROKEN, message, details);
    this.name = 'ChainError';
  }
}

/**
 * Invalid state error
 */
export class StateError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.INVALID_STATE, message, details);
    this.name = 'StateError';
  }
}

/**
 * Weight configuration error
 */
export class WeightError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.WEIGHT_MISMATCH, message, details);
    this.name = 'WeightError';
  }
}

/**
 * Insufficient stake error
 */
export class StakeError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.INSUFFICIENT_STAKE, message, details);
    this.name = 'StakeError';
  }
}

/**
 * Node not found error
 */
export class NodeNotFoundError extends BCCPError {
  constructor(nodeId: string) {
    super(ERROR_CODES.NODE_NOT_FOUND, `Node not found: ${nodeId}`, { nodeId });
    this.name = 'NodeNotFoundError';
  }
}

/**
 * TX not found error
 */
export class TXNotFoundError extends BCCPError {
  constructor(txId: string) {
    super(ERROR_CODES.TX_NOT_FOUND, `TX not found: ${txId}`, { txId });
    this.name = 'TXNotFoundError';
  }
}

/**
 * Authorization error
 */
export class AuthorizationError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.UNAUTHORIZED, message, details);
    this.name = 'AuthorizationError';
  }
}

/**
 * Expiration error
 */
export class ExpirationError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.EXPIRED, message, details);
    this.name = 'ExpirationError';
  }
}

/**
 * Duplicate entry error
 */
export class DuplicateError extends BCCPError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(ERROR_CODES.ALREADY_EXISTS, message, details);
    this.name = 'DuplicateError';
  }
}

/**
 * Check if error is a BCCP error
 */
export function isBCCPError(error: unknown): error is BCCPError {
  return error instanceof BCCPError;
}

/**
 * Wrap unknown error as BCCP error
 */
export function wrapError(error: unknown, defaultCode: string = 'E999'): BCCPError {
  if (isBCCPError(error)) {
    return error;
  }

  const message = error instanceof Error ? error.message : String(error);
  return new BCCPError(defaultCode, message);
}
