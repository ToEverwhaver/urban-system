// Node management
export {
  registerNode,
  activateNode,
  processHeartbeat,
  deactivateNode,
  recordRelay,
  getNode,
  getActiveNodes,
  getNodesByOperator,
  getAllNodes,
  getNodesByStatus,
  updateStake,
  getNodeCount,
  clearNodes
} from './node';

// Scoring
export {
  ScoreMeasurement,
  AggregatedScore,
  submitMeasurement,
  aggregateScores,
  getScoringHistory,
  getScoreDistribution,
  rankNodes,
  getNodePercentile,
  getUnderperformingNodes,
  calculateMeasurementAgreement,
  clearMeasurements
} from './scoring';

// Slashing
export {
  createSlashingEvent,
  executeSlashing,
  fileAppeal,
  resolveAppeal,
  getSlashingEvents,
  getPendingSlashingEvents,
  getAppealedEvents,
  getTotalSlashed,
  getSlashingStats,
  isAtRisk,
  clearSlashingEvents
} from './slashing';

// Route selection
export {
  selectRoute,
  verifyRoute,
  getRouteQuality,
  findBestRoute,
  generateRouteOptions,
  calculateRouteDiversity,
  analyzeRouteDistribution,
  suggestRouteImprovements
} from './selector';
