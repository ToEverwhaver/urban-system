import { ContributorProfile, Role } from '../types/contributor';
import { Address } from '../types/common';
import { getProfile, getAllProfiles } from './profile';
import { PROTOCOL_CONSTANTS } from '../constants';

export interface ReputationBreakdown {
  address: Address;
  totalScore: number;
  components: {
    activityScore: number;
    acceptanceScore: number;
    diversityScore: number;
    consistencyScore: number;
    longevityScore: number;
  };
  percentile: number;
  tier: 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM' | 'DIAMOND';
}

/**
 * Get detailed reputation breakdown
 */
export function getReputationBreakdown(address: Address): ReputationBreakdown | null {
  const profile = getProfile(address);
  if (!profile) return null;

  const activityScore = Math.min(profile.closedTXCount * 5, 200);
  const acceptanceScore = Math.floor(profile.acceptRate * 150);
  const rolesUsed = Object.values(profile.roleCount).filter(c => c > 0).length;
  const diversityScore = rolesUsed * 20;

  const days = (Date.now() - profile.firstActivityAt) / (1000 * 60 * 60 * 24);
  const txPerDay = profile.closedTXCount / Math.max(days, 1);
  const consistencyScore = Math.min(Math.floor(txPerDay * 50), 50);
  const longevityScore = Math.min(Math.floor(days / 30) * 10, 100);

  const allScores = getAllProfiles()
    .map(p => p.reputationScore)
    .sort((a, b) => a - b);
  const rank = allScores.findIndex(s => s >= profile.reputationScore);
  const percentile = allScores.length > 0 ? (rank / allScores.length) * 100 : 0;

  let tier: ReputationBreakdown['tier'];
  const thresholds = PROTOCOL_CONSTANTS.REPUTATION_TIERS;
  if (profile.reputationScore >= thresholds.DIAMOND) tier = 'DIAMOND';
  else if (profile.reputationScore >= thresholds.PLATINUM) tier = 'PLATINUM';
  else if (profile.reputationScore >= thresholds.GOLD) tier = 'GOLD';
  else if (profile.reputationScore >= thresholds.SILVER) tier = 'SILVER';
  else tier = 'BRONZE';

  return {
    address,
    totalScore: profile.reputationScore,
    components: {
      activityScore,
      acceptanceScore,
      diversityScore,
      consistencyScore,
      longevityScore
    },
    percentile,
    tier
  };
}

/**
 * Get role specialization info
 */
export function getRoleSpecialization(profile: ContributorProfile): {
  dominantRole: Role;
  specializationRatio: number;
} {
  const roles = Object.entries(profile.roleCount) as [Role, number][];
  const total = roles.reduce((sum, [, count]) => sum + count, 0);

  if (total === 0) {
    return { dominantRole: Role.Initiator, specializationRatio: 0 };
  }

  const sorted = roles.sort((a, b) => b[1] - a[1]);
  const [dominantRole, count] = sorted[0];

  return { dominantRole, specializationRatio: count / total };
}

/**
 * Predict reliability for a specific role
 */
export function predictReliability(address: Address, role: Role): number {
  const profile = getProfile(address);
  if (!profile) return 0;

  let score = profile.reputationScore / 10;
  score += Math.min(profile.roleCount[role] * 2, 20);

  if (profile.closedTXCount > 10 && profile.roleCount[role] === 0) {
    score -= 10;
  }

  score += profile.acceptRate * 20;

  return Math.min(Math.max(Math.floor(score), 0), 100);
}

/**
 * Compare two contributors
 */
export function compareContributors(
  address1: Address,
  address2: Address
): {
  winner: Address | null;
  scoreDiff: number;
  comparison: Record<string, { a: number; b: number }>;
} {
  const p1 = getProfile(address1);
  const p2 = getProfile(address2);

  if (!p1 && !p2) return { winner: null, scoreDiff: 0, comparison: {} };
  if (!p1) return { winner: address2, scoreDiff: p2!.reputationScore, comparison: {} };
  if (!p2) return { winner: address1, scoreDiff: p1.reputationScore, comparison: {} };

  const comparison = {
    reputationScore: { a: p1.reputationScore, b: p2.reputationScore },
    closedTXCount: { a: p1.closedTXCount, b: p2.closedTXCount },
    acceptRate: { a: p1.acceptRate * 100, b: p2.acceptRate * 100 },
    totalEarnedBTC: { a: Number(p1.totalEarnedBTC), b: Number(p2.totalEarnedBTC) }
  };

  const scoreDiff = p1.reputationScore - p2.reputationScore;
  const winner = scoreDiff > 0 ? address1 : scoreDiff < 0 ? address2 : null;

  return { winner, scoreDiff: Math.abs(scoreDiff), comparison };
}

/**
 * Get reputation statistics
 */
export function getReputationStats(): {
  totalProfiles: number;
  averageScore: number;
  medianScore: number;
  tierDistribution: Record<string, number>;
  topPerformer: Address | null;
} {
  const profiles = getAllProfiles();

  if (profiles.length === 0) {
    return {
      totalProfiles: 0,
      averageScore: 0,
      medianScore: 0,
      tierDistribution: { BRONZE: 0, SILVER: 0, GOLD: 0, PLATINUM: 0, DIAMOND: 0 },
      topPerformer: null
    };
  }

  const scores = profiles.map(p => p.reputationScore).sort((a, b) => a - b);
  const averageScore = scores.reduce((a, b) => a + b, 0) / scores.length;
  const medianScore = scores[Math.floor(scores.length / 2)];

  const thresholds = PROTOCOL_CONSTANTS.REPUTATION_TIERS;
  const tierDistribution = {
    BRONZE: profiles.filter(p => p.reputationScore < thresholds.SILVER).length,
    SILVER: profiles.filter(p => p.reputationScore >= thresholds.SILVER && p.reputationScore < thresholds.GOLD).length,
    GOLD: profiles.filter(p => p.reputationScore >= thresholds.GOLD && p.reputationScore < thresholds.PLATINUM).length,
    PLATINUM: profiles.filter(p => p.reputationScore >= thresholds.PLATINUM && p.reputationScore < thresholds.DIAMOND).length,
    DIAMOND: profiles.filter(p => p.reputationScore >= thresholds.DIAMOND).length
  };

  const topPerformer = profiles.reduce(
    (top, p) => (p.reputationScore > (top?.reputationScore ?? 0) ? p : top),
    profiles[0]
  ).address;

  return {
    totalProfiles: profiles.length,
    averageScore,
    medianScore,
    tierDistribution,
    topPerformer
  };
}

/**
 * Calculate trust score for transaction
 */
export function calculateTrustScore(addresses: Address[]): number {
  const profiles = addresses.map(getProfile).filter(Boolean) as ContributorProfile[];

  if (profiles.length === 0) return 0;

  const avgReputation = profiles.reduce((sum, p) => sum + p.reputationScore, 0) / profiles.length;
  const avgAcceptRate = profiles.reduce((sum, p) => sum + p.acceptRate, 0) / profiles.length;
  const avgExperience = profiles.reduce((sum, p) => sum + Math.min(p.closedTXCount, 100), 0) / profiles.length;

  return Math.floor((avgReputation * 0.5) + (avgAcceptRate * 300) + (avgExperience * 2));
}

/**
 * Get recommended contributors for a role
 */
export function getRecommendedForRole(
  role: Role,
  excludeAddresses: Address[] = [],
  limit: number = 10
): ContributorProfile[] {
  const excluded = new Set(excludeAddresses);

  return getAllProfiles()
    .filter(p => !excluded.has(p.address))
    .map(p => ({
      profile: p,
      score: predictReliability(p.address, role)
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ profile }) => profile);
}
