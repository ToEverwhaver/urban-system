// Error classes
export {
  BCCPError,
  SignatureError,
  ChainError,
  StateError,
  WeightError,
  StakeError,
  NodeNotFoundError,
  TXNotFoundError,
  AuthorizationError,
  ExpirationError,
  DuplicateError,
  isBCCPError,
  wrapError
} from './errors';

// Validation utilities
export {
  addressSchema,
  hashSchema,
  uuidSchema,
  basisPointsSchema,
  roleSchema,
  txStateSchema,
  nodeStatusSchema,
  endpointSchema,
  positiveBigintSchema,
  signatureSchema,
  contributorSchema,
  createTXParamsSchema,
  registerNodeParamsSchema,
  validateAddress,
  validateHash,
  validateUUID,
  validateBasisPoints,
  validateWeightsSum,
  validatePayment,
  validateTimestamp,
  validateTimestampWindow,
  safeParse
} from './validation';
