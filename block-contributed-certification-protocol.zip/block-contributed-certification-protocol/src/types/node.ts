import { Address, Hash, Timestamp, Satoshi, HexString } from './common';
import { ECDSASignature } from './signature';

// Node status
export enum NodeStatus {
  Pending = 'PENDING',
  Active = 'ACTIVE',
  Inactive = 'INACTIVE',
  Slashed = 'SLASHED',
  Banned = 'BANNED'
}

// Relay node
export interface RelayNode {
  id: Hash;
  operator: Address;
  publicKey: HexString;
  endpoint: string;

  // Staking
  stake: Satoshi;

  // Scoring (0-100 each)
  score: number;
  uptimeScore: number;
  latencyScore: number;
  honestyScore: number;

  // Stats
  totalRelays: number;
  successfulRelays: number;
  failedRelays: number;

  // Status
  status: NodeStatus;

  // Timestamps
  registeredAt: Timestamp;
  lastHeartbeat: Timestamp;
  lastScoreUpdate: Timestamp;
}

// Registration params
export interface RegisterNodeParams {
  operator: Address;
  publicKey: HexString;
  endpoint: string;
  stake: Satoshi;
}

// Heartbeat
export interface Heartbeat {
  nodeId: Hash;
  timestamp: Timestamp;
  metrics: NodeMetrics;
  signature: ECDSASignature;
}

// Node metrics
export interface NodeMetrics {
  uptime: number;             // Seconds
  latencyAvg: number;         // Milliseconds
  latencyP99: number;
  bandwidth: number;          // Bytes/second
  activeConnections: number;
  cpuUsage: number;           // 0.0 - 1.0
  memoryUsage: number;        // 0.0 - 1.0
}

// Slashing
export enum SlashReason {
  ExtendedDowntime = 'EXTENDED_DOWNTIME',
  DataManipulation = 'DATA_MANIPULATION',
  MaliciousActivity = 'MALICIOUS_ACTIVITY',
  ProtocolViolation = 'PROTOCOL_VIOLATION'
}

export interface SlashingEvent {
  id: Hash;
  nodeId: Hash;
  reason: SlashReason;
  evidence?: Hash;
  amount: Satoshi;
  timestamp: Timestamp;
  appealed: boolean;
  appealDeadline: Timestamp;
  resolved: boolean;
  resolution?: 'UPHELD' | 'REVERSED';
}

// Route selection
export interface RouteNode {
  node: RelayNode;
  position: number;           // 0 = entry, 1 = middle, 2 = exit
}

export interface Route {
  id: Hash;
  nodes: RouteNode[];
  createdAt: Timestamp;
  expiresAt: Timestamp;
}

// Node summary
export interface NodeSummary {
  id: Hash;
  operator: Address;
  status: NodeStatus;
  score: number;
  stake: Satoshi;
  successRate: number;
}

export function getNodeSummary(node: RelayNode): NodeSummary {
  const successRate = node.totalRelays > 0
    ? node.successfulRelays / node.totalRelays
    : 1;

  return {
    id: node.id,
    operator: node.operator,
    status: node.status,
    score: node.score,
    stake: node.stake,
    successRate
  };
}

export function createDefaultMetrics(): NodeMetrics {
  return {
    uptime: 0,
    latencyAvg: 0,
    latencyP99: 0,
    bandwidth: 0,
    activeConnections: 0,
    cpuUsage: 0,
    memoryUsage: 0
  };
}
