import { Satoshi, TokenAmount, BasisPoints } from '../types/common';
import { getReserveState, getFloorPrice } from './reserve';
import { getTotalSupply } from './minter';
import { PROTOCOL_CONSTANTS } from '../constants';

/**
 * Convert BTC to token amount
 */
export function btcToTokens(btc: Satoshi): TokenAmount {
  return ((btc * BigInt(10 ** 18)) / PROTOCOL_CONSTANTS.TOKEN_RATE) as TokenAmount;
}

/**
 * Convert tokens to BTC value
 */
export function tokensToBTC(tokens: TokenAmount): Satoshi {
  return ((tokens * PROTOCOL_CONSTANTS.TOKEN_RATE) / BigInt(10 ** 18)) as Satoshi;
}

/**
 * Calculate market capitalization
 */
export function calculateMarketCap(pricePerToken: Satoshi): Satoshi {
  const supply = getTotalSupply();
  return ((supply * pricePerToken) / BigInt(10 ** 18)) as Satoshi;
}

/**
 * Calculate reserve ratio
 */
export function calculateReserveRatio(pricePerToken: Satoshi): number {
  const state = getReserveState();
  const marketCap = calculateMarketCap(pricePerToken);
  if (marketCap === 0n) return 0;
  return Number(state.totalBTC) / Number(marketCap);
}

/**
 * Calculate premium over floor price
 */
export function calculatePremium(marketPrice: Satoshi): number {
  const floor = getFloorPrice();
  if (floor === 0n) return 0;
  return (Number(marketPrice) - Number(floor)) / Number(floor);
}

/**
 * Project floor price after forfeit processing
 */
export function projectFloorAfterForfeit(forfeitAmount: TokenAmount): Satoshi {
  const state = getReserveState();
  const btcValue = tokensToBTC(forfeitAmount);
  const newBTC = (state.totalBTC + btcValue) as Satoshi;
  const newSupply = (state.circulatingSupply - forfeitAmount) as TokenAmount;
  if (newSupply <= 0n) return 0n as Satoshi;
  return ((newBTC * BigInt(10 ** 18)) / newSupply) as Satoshi;
}

/**
 * Calculate token distribution for a payment
 */
export function calculateTokenDistribution(
  payment: Satoshi,
  weights: Map<string, BasisPoints>
): Map<string, TokenAmount> {
  const protocolFee = BigInt(
    Math.floor(Number(payment) * PROTOCOL_CONSTANTS.PROTOCOL_FEE_RATE)
  );
  const distributable = payment - protocolFee;
  const tokenValue = BigInt(
    Math.floor(Number(distributable) * PROTOCOL_CONSTANTS.TOKEN_DISTRIBUTION_RATIO)
  );
  const totalTokens = btcToTokens(tokenValue as Satoshi);

  const result = new Map<string, TokenAmount>();
  for (const [address, weight] of weights) {
    const share = (totalTokens * BigInt(weight)) / 10000n;
    result.set(address, share as TokenAmount);
  }

  return result;
}

/**
 * Calculate fully diluted valuation
 */
export function calculateFDV(pricePerToken: Satoshi, maxSupply: TokenAmount): Satoshi {
  return ((maxSupply * pricePerToken) / BigInt(10 ** 18)) as Satoshi;
}

/**
 * Calculate token velocity
 */
export function calculateVelocity(
  volumeInPeriod: TokenAmount,
  averageSupply: TokenAmount
): number {
  if (averageSupply === 0n) return 0;
  return Number(volumeInPeriod) / Number(averageSupply);
}

/**
 * Estimate BTC backing per token
 */
export function estimateBTCPerToken(): Satoshi {
  const state = getReserveState();
  if (state.circulatingSupply === 0n) return 0n as Satoshi;
  return ((state.totalBTC * BigInt(10 ** 18)) / state.circulatingSupply) as Satoshi;
}

/**
 * Calculate token inflation rate
 */
export function calculateInflationRate(
  issuedInPeriod: TokenAmount,
  previousSupply: TokenAmount
): number {
  if (previousSupply === 0n) return 0;
  return Number(issuedInPeriod) / Number(previousSupply);
}

/**
 * Calculate effective yield for contributors
 */
export function calculateEffectiveYield(
  btcEarned: Satoshi,
  tokensEarned: TokenAmount,
  tokenPrice: Satoshi,
  timeframeMs: number
): {
  totalValueBTC: Satoshi;
  annualizedYieldPercent: number;
} {
  const tokenValueBTC = (tokensEarned * tokenPrice) / BigInt(10 ** 18);
  const totalValueBTC = (btcEarned + tokenValueBTC) as Satoshi;

  const msPerYear = 365 * 24 * 60 * 60 * 1000;
  const periodsPerYear = msPerYear / timeframeMs;

  const annualizedYieldPercent = Number(totalValueBTC) * periodsPerYear / 100_000_000;

  return { totalValueBTC, annualizedYieldPercent };
}

/**
 * Get token economics summary
 */
export function getTokenEconomicsSummary(marketPrice: Satoshi): {
  totalSupply: TokenAmount;
  circulatingSupply: TokenAmount;
  floorPrice: Satoshi;
  marketCap: Satoshi;
  reserveRatio: number;
  premium: number;
  btcPerToken: Satoshi;
} {
  const state = getReserveState();
  return {
    totalSupply: state.totalTokenSupply,
    circulatingSupply: state.circulatingSupply,
    floorPrice: state.floorPrice,
    marketCap: calculateMarketCap(marketPrice),
    reserveRatio: calculateReserveRatio(marketPrice),
    premium: calculatePremium(marketPrice),
    btcPerToken: estimateBTCPerToken()
  };
}
