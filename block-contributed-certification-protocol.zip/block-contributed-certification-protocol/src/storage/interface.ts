import { TX, TXState } from '../types/tx';
import { RelayNode } from '../types/node';
import { ContributorProfile } from '../types/contributor';
import { TokenIssuance, ForfeitRecord, ReserveState } from '../types/token';
import { Hash, UUID, Address, Timestamp } from '../types/common';

/**
 * Storage interface for persistence
 */
export interface Storage {
  // TX operations
  saveTX(tx: TX): Promise<void>;
  getTX(id: UUID): Promise<TX | null>;
  getTXsByState(state: TXState): Promise<TX[]>;
  getTXsByContributor(address: Address): Promise<TX[]>;
  deleteTX(id: UUID): Promise<boolean>;

  // Node operations
  saveNode(node: RelayNode): Promise<void>;
  getNode(id: Hash): Promise<RelayNode | null>;
  getNodesByOperator(operator: Address): Promise<RelayNode[]>;
  getActiveNodes(): Promise<RelayNode[]>;
  deleteNode(id: Hash): Promise<boolean>;

  // Profile operations
  saveProfile(profile: ContributorProfile): Promise<void>;
  getProfile(address: Address): Promise<ContributorProfile | null>;
  getAllProfiles(): Promise<ContributorProfile[]>;
  deleteProfile(address: Address): Promise<boolean>;

  // Token operations
  saveIssuance(issuance: TokenIssuance): Promise<void>;
  getIssuance(id: Hash): Promise<TokenIssuance | null>;
  getIssuancesByTX(txId: UUID): Promise<TokenIssuance[]>;

  // Forfeit operations
  saveForfeit(record: ForfeitRecord): Promise<void>;
  getForfeit(id: Hash): Promise<ForfeitRecord | null>;
  getUnprocessedForfeits(): Promise<ForfeitRecord[]>;

  // Reserve state
  saveReserveState(state: ReserveState): Promise<void>;
  getReserveState(): Promise<ReserveState | null>;

  // Utility
  clear(): Promise<void>;
  getStats(): Promise<StorageStats>;
}

/**
 * Storage statistics
 */
export interface StorageStats {
  txCount: number;
  nodeCount: number;
  profileCount: number;
  issuanceCount: number;
  forfeitCount: number;
  lastUpdated: Timestamp;
}

/**
 * Query options for listing operations
 */
export interface QueryOptions {
  limit?: number;
  offset?: number;
  orderBy?: string;
  orderDirection?: 'asc' | 'desc';
}

/**
 * Batch operation interface
 */
export interface BatchOperations {
  saveTXBatch(txs: TX[]): Promise<void>;
  saveNodeBatch(nodes: RelayNode[]): Promise<void>;
  saveProfileBatch(profiles: ContributorProfile[]): Promise<void>;
}

/**
 * Storage event types
 */
export type StorageEventType =
  | 'tx:saved'
  | 'tx:deleted'
  | 'node:saved'
  | 'node:deleted'
  | 'profile:saved'
  | 'profile:deleted';

/**
 * Storage event
 */
export interface StorageEvent {
  type: StorageEventType;
  key: string;
  timestamp: Timestamp;
}

/**
 * Storage with event support
 */
export interface EventedStorage extends Storage {
  onEvent(callback: (event: StorageEvent) => void): () => void;
}
