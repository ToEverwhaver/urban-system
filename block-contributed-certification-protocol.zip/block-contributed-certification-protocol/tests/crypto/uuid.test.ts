import {
  generateUUID,
  extractTimestamp,
  isValidUUID,
  compareUUIDs,
  sortUUIDs
} from '../../src/crypto/uuid';
import { Timestamp } from '../../src/types/common';

describe('UUID Module', () => {
  describe('generateUUID', () => {
    it('should generate valid UUID v7', () => {
      const uuid = generateUUID();

      expect(isValidUUID(uuid)).toBe(true);
      expect(uuid).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
    });

    it('should generate unique UUIDs', () => {
      const uuids = new Set<string>();
      for (let i = 0; i < 100; i++) {
        uuids.add(generateUUID());
      }
      expect(uuids.size).toBe(100);
    });

    it('should respect provided timestamp', () => {
      const ts = 1700000000000 as Timestamp;
      const uuid = generateUUID(ts);
      const extracted = extractTimestamp(uuid);

      expect(extracted).toBe(ts);
    });
  });

  describe('extractTimestamp', () => {
    it('should extract correct timestamp', () => {
      const now = Date.now() as Timestamp;
      const uuid = generateUUID(now);
      const extracted = extractTimestamp(uuid);

      expect(extracted).toBe(now);
    });
  });

  describe('isValidUUID', () => {
    it('should validate correct UUID v7', () => {
      const uuid = generateUUID();
      expect(isValidUUID(uuid)).toBe(true);
    });

    it('should reject invalid formats', () => {
      expect(isValidUUID('not-a-uuid')).toBe(false);
      expect(isValidUUID('00000000-0000-4000-8000-000000000000')).toBe(false); // v4
      expect(isValidUUID('')).toBe(false);
    });
  });

  describe('compareUUIDs', () => {
    it('should compare UUIDs chronologically', () => {
      const earlier = generateUUID(1000 as Timestamp);
      const later = generateUUID(2000 as Timestamp);

      expect(compareUUIDs(earlier, later)).toBe(-1);
      expect(compareUUIDs(later, earlier)).toBe(1);
    });

    it('should return 0 for same timestamp', () => {
      const ts = Date.now() as Timestamp;
      const uuid1 = generateUUID(ts);
      const uuid2 = generateUUID(ts);

      // Random part may differ, but timestamp comparison should handle it
      const result = compareUUIDs(uuid1, uuid2);
      expect([-1, 0, 1]).toContain(result);
    });
  });

  describe('sortUUIDs', () => {
    it('should sort UUIDs by timestamp', () => {
      const uuids = [
        generateUUID(3000 as Timestamp),
        generateUUID(1000 as Timestamp),
        generateUUID(2000 as Timestamp)
      ];

      const sorted = sortUUIDs(uuids);

      expect(extractTimestamp(sorted[0])).toBe(1000);
      expect(extractTimestamp(sorted[1])).toBe(2000);
      expect(extractTimestamp(sorted[2])).toBe(3000);
    });
  });
});
