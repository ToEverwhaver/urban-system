import {
  distributeRewards,
  calculateProtocolFee,
  processTokenDecisions,
  getTotalForfeited,
  previewDistribution,
  calculateContributorShare,
  validateDistribution,
  redistributeForfeited
} from '../../src/closure/distribution';
import { createTX, addContributor, setWeights } from '../../src/tx/chain';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { createSignaturePair } from '../../src/signature/protocol';
import { hash } from '../../src/crypto/hash';
import { Role } from '../../src/types/contributor';
import { DistributionResult } from '../../src/types/tx';
import { Hash, Address, BasisPoints, Timestamp, Satoshi, TokenAmount } from '../../src/types/common';
import { PROTOCOL_CONSTANTS } from '../../src/constants';

describe('Closure Distribution Module', () => {
  const initiatorKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();

  const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);

  const assetHash = hash('test-asset') as Hash;

  function createOpenTX() {
    let tx = createTX({
      assetHash,
      assetType: 'test',
      initiator: initiatorAddress
    });

    const contentHash = hash('content') as Hash;
    const sigPair = createSignaturePair(
      { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
      { address: receiverAddress, privateKey: receiverKeys.privateKey },
      contentHash,
      assetHash,
      Role.Receiver
    );

    tx = addContributor(
      tx,
      {
        address: receiverAddress,
        role: Role.Receiver,
        weight: 4000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPair,
      contentHash
    );

    const weights = new Map<Address, BasisPoints>();
    weights.set(initiatorAddress, 6000 as BasisPoints);
    weights.set(receiverAddress, 4000 as BasisPoints);
    tx = setWeights(tx, weights);

    return tx;
  }

  describe('calculateProtocolFee', () => {
    it('should calculate correct protocol fee', () => {
      const payment = 1000000n as Satoshi;
      const fee = calculateProtocolFee(payment);
      const expectedFee = BigInt(Math.floor(Number(payment) * PROTOCOL_CONSTANTS.PROTOCOL_FEE_RATE));

      expect(fee).toBe(expectedFee);
    });

    it('should handle small amounts', () => {
      const payment = 100n as Satoshi;
      const fee = calculateProtocolFee(payment);

      expect(fee).toBeGreaterThanOrEqual(0n);
    });
  });

  describe('distributeRewards', () => {
    it('should distribute rewards according to weights', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      const distribution = await distributeRewards(tx, payment);

      expect(distribution).toHaveLength(2);

      const initiatorDist = distribution.find(d => d.contributor === initiatorAddress);
      const receiverDist = distribution.find(d => d.contributor === receiverAddress);

      expect(initiatorDist).toBeDefined();
      expect(receiverDist).toBeDefined();

      // Initiator has 60%, receiver has 40%
      expect(initiatorDist!.btcAmount).toBeGreaterThan(receiverDist!.btcAmount);
    });

    it('should apply 80/20 BTC/Token split', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      const distribution = await distributeRewards(tx, payment);

      const totalBTC = distribution.reduce((sum, d) => sum + d.btcAmount, 0n);
      const protocolFee = calculateProtocolFee(payment);
      const distributable = payment - protocolFee;
      const expectedBTC = BigInt(Math.floor(Number(distributable) * PROTOCOL_CONSTANTS.BTC_DISTRIBUTION_RATIO));

      // Allow small rounding difference
      expect(Math.abs(Number(totalBTC - expectedBTC))).toBeLessThanOrEqual(2);
    });
  });

  describe('processTokenDecisions', () => {
    it('should mark forfeited tokens', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      let distribution = await distributeRewards(tx, payment);

      const decisions = new Map<Address, boolean>();
      decisions.set(initiatorAddress, true);
      decisions.set(receiverAddress, false);

      distribution = processTokenDecisions(distribution, decisions);

      const initiatorDist = distribution.find(d => d.contributor === initiatorAddress);
      const receiverDist = distribution.find(d => d.contributor === receiverAddress);

      expect(initiatorDist!.tokenAccepted).toBe(true);
      expect(receiverDist!.tokenAccepted).toBe(false);
      expect(receiverDist!.forfeitedAmount).toBe(receiverDist!.tokenAmount);
    });

    it('should default to accepting tokens', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      let distribution = await distributeRewards(tx, payment);

      // Empty decisions map - all should default to accepting
      const decisions = new Map<Address, boolean>();

      distribution = processTokenDecisions(distribution, decisions);

      expect(distribution.every(d => d.tokenAccepted)).toBe(true);
    });
  });

  describe('getTotalForfeited', () => {
    it('should calculate total forfeited amount', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      let distribution = await distributeRewards(tx, payment);

      const decisions = new Map<Address, boolean>();
      decisions.set(initiatorAddress, false);
      decisions.set(receiverAddress, false);

      distribution = processTokenDecisions(distribution, decisions);

      const forfeited = getTotalForfeited(distribution);
      const totalTokens = distribution.reduce((sum, d) => sum + d.tokenAmount, 0n);

      expect(forfeited).toBe(totalTokens);
    });

    it('should return 0 when nothing forfeited', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      const distribution = await distributeRewards(tx, payment);

      const forfeited = getTotalForfeited(distribution);

      expect(forfeited).toBe(0n);
    });
  });

  describe('previewDistribution', () => {
    it('should preview distribution breakdown', () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      const preview = previewDistribution(tx, payment);

      expect(preview.protocolFee).toBeGreaterThan(0n);
      expect(preview.totalBTC).toBeGreaterThan(0n);
      expect(preview.totalTokens).toBeGreaterThan(0n);
      expect(preview.distributions).toHaveLength(2);
    });

    it('should calculate correct weights', () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      const preview = previewDistribution(tx, payment);

      const initiatorDist = preview.distributions.find(d => d.address === initiatorAddress);
      const receiverDist = preview.distributions.find(d => d.address === receiverAddress);

      expect(initiatorDist!.weight).toBe(6000);
      expect(receiverDist!.weight).toBe(4000);
    });
  });

  describe('calculateContributorShare', () => {
    it('should calculate share for given weight', () => {
      const payment = 1000000n as Satoshi;
      const weight = 5000 as BasisPoints; // 50%

      const share = calculateContributorShare(payment, weight);

      expect(share.btc).toBeGreaterThan(0n);
      expect(share.tokens).toBeGreaterThan(0n);
    });

    it('should scale with weight', () => {
      const payment = 1000000n as Satoshi;

      const share25 = calculateContributorShare(payment, 2500 as BasisPoints);
      const share50 = calculateContributorShare(payment, 5000 as BasisPoints);

      // 50% should be approximately double 25%
      expect(Math.abs(Number(share50.btc) - Number(share25.btc) * 2)).toBeLessThanOrEqual(2);
    });
  });

  describe('validateDistribution', () => {
    it('should validate correct distribution', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      const distribution = await distributeRewards(tx, payment);

      const result = validateDistribution(distribution, payment);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should fail if weights do not sum to 10000', async () => {
      const distribution: DistributionResult[] = [
        {
          contributor: initiatorAddress,
          role: Role.Initiator,
          weight: 5000 as BasisPoints,
          btcAmount: 100000n as Satoshi,
          tokenAmount: 1000n as TokenAmount,
          tokenAccepted: true
        }
      ];

      const result = validateDistribution(distribution, 1000000n as Satoshi);

      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.includes('10000'))).toBe(true);
    });
  });

  describe('redistributeForfeited', () => {
    it('should redistribute forfeited tokens to acceptors', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      let distribution = await distributeRewards(tx, payment);

      const decisions = new Map<Address, boolean>();
      decisions.set(initiatorAddress, true);
      decisions.set(receiverAddress, false);

      distribution = processTokenDecisions(distribution, decisions);

      const initiatorBefore = distribution.find(d => d.contributor === initiatorAddress)!.tokenAmount;

      distribution = redistributeForfeited(distribution);

      const initiatorAfter = distribution.find(d => d.contributor === initiatorAddress)!.tokenAmount;

      // Initiator should have received bonus from forfeited tokens
      expect(initiatorAfter).toBeGreaterThan(initiatorBefore);
    });

    it('should not change anything if nothing forfeited', async () => {
      const tx = createOpenTX();
      const payment = 1000000n as Satoshi;

      const distribution = await distributeRewards(tx, payment);
      const initiatorBefore = distribution.find(d => d.contributor === initiatorAddress)!.tokenAmount;

      const redistributed = redistributeForfeited(distribution);
      const initiatorAfter = redistributed.find(d => d.contributor === initiatorAddress)!.tokenAmount;

      expect(initiatorAfter).toBe(initiatorBefore);
    });
  });
});
