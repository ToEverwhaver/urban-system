import { Hash, Satoshi, TokenAmount, Timestamp, Address, UUID } from './common';

// Token issuance event
export interface TokenIssuance {
  id: Hash;
  txId: UUID;
  amount: TokenAmount;
  timestamp: Timestamp;
  recipients: TokenRecipient[];
}

export interface TokenRecipient {
  address: Address;
  amount: TokenAmount;
  accepted: boolean;
}

// Reserve state
export interface ReserveState {
  totalBTC: Satoshi;
  totalTokenSupply: TokenAmount;
  circulatingSupply: TokenAmount;
  forfeitPool: TokenAmount;
  floorPrice: Satoshi;        // Per token in satoshi
  lastUpdated: Timestamp;
}

// Forfeit record
export interface ForfeitRecord {
  id: Hash;
  contributor: Address;
  amount: TokenAmount;
  txId: UUID;
  timestamp: Timestamp;
  processed: boolean;
  processedAt?: Timestamp;
  action?: 'AIRDROP' | 'BURN_AND_BUY';
}

// Forfeit action type
export type ForfeitAction = 'AIRDROP' | 'BURN_AND_BUY';

// Token transfer event
export interface TokenTransfer {
  id: Hash;
  from: Address;
  to: Address;
  amount: TokenAmount;
  timestamp: Timestamp;
}

// Token balance
export interface TokenBalance {
  address: Address;
  balance: TokenAmount;
  lastUpdated: Timestamp;
}

// Reserve metrics
export interface ReserveMetrics {
  reserveRatio: number;       // BTC Reserve / Market Cap
  floorPrice: Satoshi;
  marketCap?: Satoshi;
  premium?: number;           // (Market Price - Floor) / Floor
}

export function createInitialReserveState(): ReserveState {
  return {
    totalBTC: 0n as Satoshi,
    totalTokenSupply: 0n as TokenAmount,
    circulatingSupply: 0n as TokenAmount,
    forfeitPool: 0n as TokenAmount,
    floorPrice: 0n as Satoshi,
    lastUpdated: Date.now() as Timestamp
  };
}
