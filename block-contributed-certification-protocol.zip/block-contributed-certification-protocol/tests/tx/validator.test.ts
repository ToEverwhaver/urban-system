import { validateTX, validateWeights, validateForClosure } from '../../src/tx/validator';
import { createTX, addContributor, setWeights } from '../../src/tx/chain';
import { hash } from '../../src/crypto/hash';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { createSignaturePair } from '../../src/signature/protocol';
import { Role } from '../../src/types/contributor';
import { TXState } from '../../src/types/tx';
import { Hash, Address, BasisPoints, Timestamp } from '../../src/types/common';

describe('TX Validator Module', () => {
  const initiatorKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();

  const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);

  const assetHash = hash('test-asset') as Hash;

  describe('validateTX', () => {
    it('should validate valid TX', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contentHash = hash('content') as Hash;
      const sigPair = createSignaturePair(
        { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        assetHash,
        Role.Receiver
      );

      tx = addContributor(
        tx,
        {
          address: receiverAddress,
          role: Role.Receiver,
          weight: 2500 as BasisPoints,
          joinedAt: Date.now() as Timestamp
        },
        sigPair,
        contentHash
      );

      const weights = new Map<Address, BasisPoints>();
      weights.set(initiatorAddress, 6000 as BasisPoints);
      weights.set(receiverAddress, 4000 as BasisPoints);
      tx = setWeights(tx, weights);

      const result = validateTX(tx);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should fail for empty chain', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });
      (tx as any).chain = [];

      const result = validateTX(tx);

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it('should fail for initiator with signature', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contentHash = hash('content') as Hash;
      const sigPair = createSignaturePair(
        { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        assetHash,
        Role.Receiver
      );

      (tx.chain[0] as any).signaturePair = sigPair;

      const result = validateTX(tx);

      expect(result.valid).toBe(false);
    });
  });

  describe('validateWeights', () => {
    it('should pass for weights summing to 10000', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const weights = new Map<Address, BasisPoints>();
      weights.set(initiatorAddress, 10000 as BasisPoints);
      tx = setWeights(tx, weights);

      const result = validateWeights(tx);

      expect(result.valid).toBe(true);
    });

    it('should fail for missing contributor weight', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contentHash = hash('content') as Hash;
      const sigPair = createSignaturePair(
        { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        assetHash,
        Role.Receiver
      );

      tx = addContributor(
        tx,
        {
          address: receiverAddress,
          role: Role.Receiver,
          weight: 2500 as BasisPoints,
          joinedAt: Date.now() as Timestamp
        },
        sigPair,
        contentHash
      );

      // Remove receiver's weight
      tx.weights.delete(receiverAddress);

      const result = validateWeights(tx);

      expect(result.valid).toBe(false);
    });

    it('should warn for zero weight', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contentHash = hash('content') as Hash;
      const sigPair = createSignaturePair(
        { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        assetHash,
        Role.Receiver
      );

      tx = addContributor(
        tx,
        {
          address: receiverAddress,
          role: Role.Receiver,
          weight: 0 as BasisPoints,
          joinedAt: Date.now() as Timestamp
        },
        sigPair,
        contentHash
      );

      const weights = new Map<Address, BasisPoints>();
      weights.set(initiatorAddress, 10000 as BasisPoints);
      weights.set(receiverAddress, 0 as BasisPoints);
      tx = setWeights(tx, weights);

      const result = validateWeights(tx);

      expect(result.warnings.length).toBeGreaterThan(0);
    });
  });

  describe('validateForClosure', () => {
    it('should pass for valid open TX', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contentHash = hash('content') as Hash;
      const sigPair = createSignaturePair(
        { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        assetHash,
        Role.Receiver
      );

      tx = addContributor(
        tx,
        {
          address: receiverAddress,
          role: Role.Receiver,
          weight: 4000 as BasisPoints,
          joinedAt: Date.now() as Timestamp
        },
        sigPair,
        contentHash
      );

      const weights = new Map<Address, BasisPoints>();
      weights.set(initiatorAddress, 6000 as BasisPoints);
      weights.set(receiverAddress, 4000 as BasisPoints);
      tx = setWeights(tx, weights);

      const result = validateForClosure(tx);

      expect(result.valid).toBe(true);
    });

    it('should fail for draft TX', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const result = validateForClosure(tx);

      expect(result.valid).toBe(false);
    });
  });
});
