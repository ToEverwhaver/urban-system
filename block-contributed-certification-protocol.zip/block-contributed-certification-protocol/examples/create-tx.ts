/**
 * Example: Creating a TX chain with multiple contributors
 */

import {
  createTX,
  addContributor,
  setWeights,
  validateTX,
  txBuilder,
  generateKeyPair,
  privateKeyToAddress,
  createSignaturePair,
  hash,
  Role,
  BasisPoints,
  Hash,
  Address
} from '../src';

async function main() {
  console.log('=== BCCP TX Creation Example ===\n');

  // Generate keypairs for participants
  const initiatorKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();
  const producerKeys = generateKeyPair();
  const editorKeys = generateKeyPair();

  const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);
  const producerAddress = privateKeyToAddress(producerKeys.privateKey);
  const editorAddress = privateKeyToAddress(editorKeys.privateKey);

  console.log('Participants:');
  console.log(`  Initiator: ${initiatorAddress}`);
  console.log(`  Receiver:  ${receiverAddress}`);
  console.log(`  Producer:  ${producerAddress}`);
  console.log(`  Editor:    ${editorAddress}`);
  console.log('');

  // Create asset hash
  const assetContent = 'Original creative content by initiator';
  const assetHash = hash(assetContent) as Hash;

  // Method 1: Using low-level functions
  console.log('Method 1: Low-level TX creation');
  console.log('-------------------------------');

  let tx = createTX({
    assetHash,
    assetType: 'article',
    assetMetadata: { title: 'Sample Article', version: '1.0' },
    initiator: initiatorAddress
  });

  console.log(`TX created: ${tx.id}`);
  console.log(`State: ${tx.state}`);

  // Add receiver with signature pair
  const receiverContent = hash('Receiver processed content');
  const receiverSigPair = createSignaturePair(
    { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
    { address: receiverAddress, privateKey: receiverKeys.privateKey },
    receiverContent as Hash,
    assetHash,
    Role.Receiver
  );

  tx = addContributor(
    tx,
    {
      address: receiverAddress,
      role: Role.Receiver,
      weight: 2500 as BasisPoints,
      joinedAt: Date.now() as any
    },
    receiverSigPair,
    receiverContent as Hash
  );

  console.log(`Receiver added. Chain length: ${tx.chain.length}`);

  // Add producer
  const producerContent = hash('Producer created content');
  const producerSigPair = createSignaturePair(
    { address: receiverAddress, privateKey: receiverKeys.privateKey },
    { address: producerAddress, privateKey: producerKeys.privateKey },
    producerContent as Hash,
    receiverContent as Hash,
    Role.Producer
  );

  tx = addContributor(
    tx,
    {
      address: producerAddress,
      role: Role.Producer,
      weight: 2000 as BasisPoints,
      joinedAt: Date.now() as any
    },
    producerSigPair,
    producerContent as Hash
  );

  console.log(`Producer added. Chain length: ${tx.chain.length}`);

  // Set final weights
  const weights = new Map<Address, BasisPoints>();
  weights.set(initiatorAddress, 3000 as BasisPoints);
  weights.set(receiverAddress, 2500 as BasisPoints);
  weights.set(producerAddress, 4500 as BasisPoints);

  tx = setWeights(tx, weights);

  // Validate
  const validation = validateTX(tx);
  console.log(`\nValidation: ${validation.valid ? 'PASSED' : 'FAILED'}`);
  if (validation.errors.length > 0) {
    console.log('Errors:', validation.errors);
  }
  if (validation.warnings.length > 0) {
    console.log('Warnings:', validation.warnings);
  }

  console.log('\n');

  // Method 2: Using TXBuilder
  console.log('Method 2: Using TXBuilder (fluent API)');
  console.log('--------------------------------------');

  const builderTX = txBuilder({
    assetHash,
    assetType: 'video',
    initiator: initiatorAddress
  })
    .addReceiver(
      receiverAddress,
      receiverSigPair,
      receiverContent as Hash,
      2500 as BasisPoints
    )
    .addProducer(
      producerAddress,
      producerSigPair,
      producerContent as Hash,
      2000 as BasisPoints
    )
    .build();

  console.log(`TX created: ${builderTX.id}`);
  console.log(`State: ${builderTX.state}`);
  console.log(`Contributors: ${builderTX.chain.length}`);
  console.log(`Merkle Root: ${builderTX.chainMerkleRoot}`);

  const builderValidation = validateTX(builderTX);
  console.log(`Validation: ${builderValidation.valid ? 'PASSED' : 'FAILED'}`);

  console.log('\n=== Example Complete ===');
}

main().catch(console.error);
