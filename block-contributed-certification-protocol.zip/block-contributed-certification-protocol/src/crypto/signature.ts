import * as secp256k1 from 'secp256k1';
import { hash, hashObject } from './hash';
import { ECDSASignature, EIP712Domain } from '../types/signature';
import { Address, Hash, HexString } from '../types/common';

// Re-export hashObject for use in signature protocol
export { hashObject };

/**
 * Generate a new keypair
 */
export function generateKeyPair(): { privateKey: Buffer; publicKey: Buffer } {
  let privateKey: Buffer;
  do {
    privateKey = Buffer.from(crypto.getRandomValues(new Uint8Array(32)));
  } while (!secp256k1.privateKeyVerify(privateKey));

  const publicKey = Buffer.from(secp256k1.publicKeyCreate(privateKey));
  return { privateKey, publicKey };
}

/**
 * Derive address from public key
 */
export function publicKeyToAddress(publicKey: Buffer): Address {
  const pubKeyHash = hash(publicKey);
  return `0x${pubKeyHash.slice(-40)}` as Address;
}

/**
 * Get address from private key
 */
export function privateKeyToAddress(privateKey: Buffer): Address {
  const publicKey = Buffer.from(secp256k1.publicKeyCreate(privateKey));
  return publicKeyToAddress(publicKey);
}

/**
 * Sign a message hash
 */
export function sign(messageHash: Hash, privateKey: Buffer): ECDSASignature {
  const msgBuffer = Buffer.from(messageHash.slice(2), 'hex');
  const { signature, recid } = secp256k1.ecdsaSign(msgBuffer, privateKey);

  return {
    r: `0x${Buffer.from(signature.slice(0, 32)).toString('hex')}` as HexString,
    s: `0x${Buffer.from(signature.slice(32, 64)).toString('hex')}` as HexString,
    v: recid + 27
  };
}

/**
 * Verify a signature against a public key
 */
export function verify(
  messageHash: Hash,
  signature: ECDSASignature,
  publicKey: Buffer
): boolean {
  const msgBuffer = Buffer.from(messageHash.slice(2), 'hex');
  const sigBuffer = Buffer.concat([
    Buffer.from(signature.r.slice(2), 'hex'),
    Buffer.from(signature.s.slice(2), 'hex')
  ]);

  return secp256k1.ecdsaVerify(sigBuffer, msgBuffer, publicKey);
}

/**
 * Recover public key from signature
 */
export function recoverPublicKey(messageHash: Hash, signature: ECDSASignature): Buffer {
  const msgBuffer = Buffer.from(messageHash.slice(2), 'hex');
  const sigBuffer = Buffer.concat([
    Buffer.from(signature.r.slice(2), 'hex'),
    Buffer.from(signature.s.slice(2), 'hex')
  ]);
  const recid = signature.v - 27;

  return Buffer.from(secp256k1.ecdsaRecover(sigBuffer, recid, msgBuffer));
}

/**
 * Recover address from signature
 */
export function recoverAddress(messageHash: Hash, signature: ECDSASignature): Address {
  const publicKey = recoverPublicKey(messageHash, signature);
  return publicKeyToAddress(publicKey);
}

/**
 * Hash typed data according to EIP-712
 */
export function hashTypedData(
  domain: EIP712Domain,
  message: Record<string, unknown>
): Hash {
  const domainSeparator = hashObject({
    name: domain.name,
    version: domain.version,
    chainId: domain.chainId,
    verifyingContract: domain.verifyingContract
  });

  const messageHash = hashObject(message);
  return hash(`\x19\x01${domainSeparator.slice(2)}${messageHash.slice(2)}`);
}

/**
 * Sign typed data according to EIP-712
 */
export function signTypedData(
  domain: EIP712Domain,
  message: Record<string, unknown>,
  privateKey: Buffer
): ECDSASignature {
  const messageHash = hashTypedData(domain, message);
  return sign(messageHash, privateKey);
}

/**
 * Verify typed data signature
 */
export function verifyTypedData(
  domain: EIP712Domain,
  message: Record<string, unknown>,
  signature: ECDSASignature,
  expectedAddress: Address
): boolean {
  const messageHash = hashTypedData(domain, message);
  const recoveredAddress = recoverAddress(messageHash, signature);
  return recoveredAddress === expectedAddress;
}

/**
 * Sign a raw message with prefix
 */
export function signMessage(message: string, privateKey: Buffer): ECDSASignature {
  const prefixed = `\x19BCCP Signed Message:\n${message.length}${message}`;
  const messageHash = hash(prefixed);
  return sign(messageHash, privateKey);
}

/**
 * Verify a raw message signature
 */
export function verifyMessage(
  message: string,
  signature: ECDSASignature,
  expectedAddress: Address
): boolean {
  const prefixed = `\x19BCCP Signed Message:\n${message.length}${message}`;
  const messageHash = hash(prefixed);
  const recoveredAddress = recoverAddress(messageHash, signature);
  return recoveredAddress === expectedAddress;
}
