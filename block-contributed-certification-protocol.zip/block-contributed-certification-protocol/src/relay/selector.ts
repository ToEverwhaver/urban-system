import { RelayNode, Route, RouteNode, NodeStatus } from '../types/node';
import { Hash, Timestamp } from '../types/common';
import { hash } from '../crypto/hash';
import { getActiveNodes } from './node';
import { PROTOCOL_CONSTANTS } from '../constants';

/**
 * Select nodes for a route
 */
export function selectRoute(
  excludeNodes: Hash[] = [],
  nodeCount: number = 3
): Route | null {
  const activeNodes = getActiveNodes()
    .filter(n => !excludeNodes.includes(n.id))
    .sort((a, b) => b.score - a.score);

  const requiredNodes = Math.max(
    PROTOCOL_CONSTANTS.MIN_ROUTE_NODES,
    Math.min(nodeCount, PROTOCOL_CONSTANTS.MAX_ROUTE_NODES)
  );

  if (activeNodes.length < requiredNodes) {
    return null;
  }

  const selectedNodes = weightedRandomSelection(activeNodes, requiredNodes);
  const now = Date.now() as Timestamp;

  const routeNodes: RouteNode[] = selectedNodes.map((node, index) => ({
    node,
    position: index
  }));

  return {
    id: hash(`route:${now}:${Math.random()}`) as Hash,
    nodes: routeNodes,
    createdAt: now,
    expiresAt: (now + PROTOCOL_CONSTANTS.ROUTE_EXPIRY_MS) as Timestamp
  };
}

/**
 * Weighted random selection based on node scores
 */
function weightedRandomSelection(nodes: RelayNode[], count: number): RelayNode[] {
  const selected: RelayNode[] = [];
  const remaining = [...nodes];

  while (selected.length < count && remaining.length > 0) {
    const totalWeight = remaining.reduce((sum, n) => sum + n.score, 0);
    let random = Math.random() * totalWeight;

    for (let i = 0; i < remaining.length; i++) {
      random -= remaining[i].score;
      if (random <= 0) {
        selected.push(remaining[i]);
        remaining.splice(i, 1);
        break;
      }
    }
  }

  return selected;
}

/**
 * Verify route is still valid
 */
export function verifyRoute(route: Route): {
  valid: boolean;
  reason?: string;
} {
  const now = Date.now();

  if (now > route.expiresAt) {
    return { valid: false, reason: 'Route expired' };
  }

  for (const routeNode of route.nodes) {
    if (routeNode.node.status !== NodeStatus.Active) {
      return { valid: false, reason: `Node ${routeNode.node.id} not active` };
    }
  }

  return { valid: true };
}

/**
 * Get route quality score
 */
export function getRouteQuality(route: Route): number {
  const scores = route.nodes.map(rn => rn.node.score);
  const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;
  const minScore = Math.min(...scores);

  return Math.floor((avgScore * 0.7) + (minScore * 0.3));
}

/**
 * Find best route among options
 */
export function findBestRoute(
  routes: Route[],
  excludeNodeIds: Hash[] = []
): Route | null {
  const validRoutes = routes
    .filter(r => verifyRoute(r).valid)
    .filter(r => !r.nodes.some(rn => excludeNodeIds.includes(rn.node.id)));

  if (validRoutes.length === 0) return null;

  return validRoutes.reduce((best, current) =>
    getRouteQuality(current) > getRouteQuality(best) ? current : best
  );
}

/**
 * Generate multiple route options
 */
export function generateRouteOptions(
  count: number = 3,
  excludeNodes: Hash[] = []
): Route[] {
  const routes: Route[] = [];
  const usedNodes = new Set<Hash>(excludeNodes);

  for (let i = 0; i < count; i++) {
    const route = selectRoute(Array.from(usedNodes));
    if (route) {
      routes.push(route);
      for (const rn of route.nodes) {
        usedNodes.add(rn.node.id);
      }
    }
  }

  return routes;
}

/**
 * Calculate route diversity score
 */
export function calculateRouteDiversity(routes: Route[]): number {
  if (routes.length < 2) return 0;

  const allNodeIds = new Set<Hash>();
  let totalNodes = 0;

  for (const route of routes) {
    for (const rn of route.nodes) {
      allNodeIds.add(rn.node.id);
      totalNodes++;
    }
  }

  return allNodeIds.size / totalNodes;
}

/**
 * Get geographic distribution of route
 */
export function analyzeRouteDistribution(route: Route): {
  nodeCount: number;
  avgScore: number;
  scoreVariance: number;
  totalStake: bigint;
} {
  const scores = route.nodes.map(rn => rn.node.score);
  const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;
  const variance = scores.reduce((sum, s) => sum + Math.pow(s - avgScore, 2), 0) / scores.length;
  const totalStake = route.nodes.reduce((sum, rn) => sum + rn.node.stake, 0n);

  return {
    nodeCount: route.nodes.length,
    avgScore,
    scoreVariance: variance,
    totalStake
  };
}

/**
 * Suggest route improvements
 */
export function suggestRouteImprovements(route: Route): {
  suggestion: string;
  replacementCandidates: RelayNode[];
}[] {
  const suggestions: { suggestion: string; replacementCandidates: RelayNode[] }[] = [];
  const activeNodes = getActiveNodes();

  for (const routeNode of route.nodes) {
    if (routeNode.node.score < 50) {
      const betterNodes = activeNodes
        .filter(n => !route.nodes.some(rn => rn.node.id === n.id))
        .filter(n => n.score > routeNode.node.score)
        .slice(0, 3);

      if (betterNodes.length > 0) {
        suggestions.push({
          suggestion: `Replace node at position ${routeNode.position} (score: ${routeNode.node.score})`,
          replacementCandidates: betterNodes
        });
      }
    }
  }

  return suggestions;
}
