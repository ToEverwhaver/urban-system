import { TX, CreateTXParams } from '../types/tx';
import { Contributor, Role } from '../types/contributor';
import { SignaturePair } from '../types/signature';
import { Hash, Address, BasisPoints, Timestamp } from '../types/common';
import { createTX, addContributor, setWeights } from './chain';

/**
 * Fluent builder for constructing TX chains
 */
export class TXBuilder {
  private tx: TX;
  private pendingWeights: Map<Address, BasisPoints> = new Map();

  constructor(params: CreateTXParams) {
    this.tx = createTX(params);
    if (params.initialWeights) {
      this.pendingWeights = new Map(params.initialWeights);
    }
  }

  /**
   * Add a Receiver to the chain
   */
  addReceiver(
    address: Address,
    signaturePair: SignaturePair,
    contentHash: Hash,
    weight: BasisPoints = 2500 as BasisPoints
  ): TXBuilder {
    const contributor: Contributor = {
      address,
      role: Role.Receiver,
      weight,
      joinedAt: Date.now() as Timestamp
    };
    this.tx = addContributor(this.tx, contributor, signaturePair, contentHash);
    this.pendingWeights.set(address, weight);
    return this;
  }

  /**
   * Add a Producer to the chain
   */
  addProducer(
    address: Address,
    signaturePair: SignaturePair,
    contentHash: Hash,
    weight: BasisPoints = 2000 as BasisPoints
  ): TXBuilder {
    const contributor: Contributor = {
      address,
      role: Role.Producer,
      weight,
      joinedAt: Date.now() as Timestamp
    };
    this.tx = addContributor(this.tx, contributor, signaturePair, contentHash);
    this.pendingWeights.set(address, weight);
    return this;
  }

  /**
   * Add an Editor to the chain
   */
  addEditor(
    address: Address,
    signaturePair: SignaturePair,
    contentHash: Hash,
    weight: BasisPoints = 1500 as BasisPoints
  ): TXBuilder {
    const contributor: Contributor = {
      address,
      role: Role.Editor,
      weight,
      joinedAt: Date.now() as Timestamp
    };
    this.tx = addContributor(this.tx, contributor, signaturePair, contentHash);
    this.pendingWeights.set(address, weight);
    return this;
  }

  /**
   * Add a custom role contributor
   */
  addCustom(
    address: Address,
    roleName: string,
    signaturePair: SignaturePair,
    contentHash: Hash,
    weight: BasisPoints
  ): TXBuilder {
    const contributor: Contributor = {
      address,
      role: Role.Custom,
      customRoleName: roleName,
      weight,
      joinedAt: Date.now() as Timestamp
    };
    this.tx = addContributor(this.tx, contributor, signaturePair, contentHash);
    this.pendingWeights.set(address, weight);
    return this;
  }

  /**
   * Set weight for a specific address
   */
  setWeight(address: Address, weight: BasisPoints): TXBuilder {
    this.pendingWeights.set(address, weight);
    return this;
  }

  /**
   * Finalize weights ensuring they sum to 10000
   */
  finalizeWeights(): TXBuilder {
    const total = Array.from(this.pendingWeights.values()).reduce((a, b) => a + b, 0);

    if (total !== 10000) {
      const initiator = this.tx.chain[0].contributor.address;
      const current = this.pendingWeights.get(initiator) ?? 0;
      this.pendingWeights.set(initiator, (current + 10000 - total) as BasisPoints);
    }

    this.tx = setWeights(this.tx, this.pendingWeights);
    return this;
  }

  /**
   * Get current TX state
   */
  current(): TX {
    return this.tx;
  }

  /**
   * Build and return the finalized TX
   */
  build(): TX {
    this.finalizeWeights();
    return this.tx;
  }
}

/**
 * Factory function for creating a TXBuilder
 */
export function txBuilder(params: CreateTXParams): TXBuilder {
  return new TXBuilder(params);
}

/**
 * Quick builder for simple TX chains
 */
export function buildSimpleTX(
  assetHash: Hash,
  assetType: string,
  initiator: Address,
  contributors: Array<{
    address: Address;
    role: Role;
    signaturePair: SignaturePair;
    contentHash: Hash;
    weight?: BasisPoints;
  }>
): TX {
  const builder = txBuilder({
    assetHash,
    assetType,
    initiator
  });

  for (const c of contributors) {
    const contributor: Contributor = {
      address: c.address,
      role: c.role,
      weight: c.weight ?? 2000 as BasisPoints,
      joinedAt: Date.now() as Timestamp
    };
    builder['tx'] = addContributor(builder['tx'], contributor, c.signaturePair, c.contentHash);
    builder['pendingWeights'].set(c.address, contributor.weight);
  }

  return builder.build();
}
