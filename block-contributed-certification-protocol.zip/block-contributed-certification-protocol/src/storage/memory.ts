import { TX, TXState } from '../types/tx';
import { RelayNode, NodeStatus } from '../types/node';
import { ContributorProfile } from '../types/contributor';
import { TokenIssuance, ForfeitRecord, ReserveState } from '../types/token';
import { Hash, UUID, Address, Timestamp } from '../types/common';
import { Storage, StorageStats, StorageEvent, EventedStorage, StorageEventType } from './interface';
import { serializeTX, deserializeTX } from '../tx/chain';

/**
 * In-memory storage implementation
 */
export class MemoryStorage implements EventedStorage {
  private txStore = new Map<UUID, string>();
  private nodeStore = new Map<Hash, RelayNode>();
  private profileStore = new Map<Address, ContributorProfile>();
  private issuanceStore = new Map<Hash, TokenIssuance>();
  private forfeitStore = new Map<Hash, ForfeitRecord>();
  private reserveState: ReserveState | null = null;
  private eventListeners: Array<(event: StorageEvent) => void> = [];

  private emit(type: StorageEventType, key: string): void {
    const event: StorageEvent = {
      type,
      key,
      timestamp: Date.now() as Timestamp
    };
    for (const listener of this.eventListeners) {
      listener(event);
    }
  }

  onEvent(callback: (event: StorageEvent) => void): () => void {
    this.eventListeners.push(callback);
    return () => {
      const index = this.eventListeners.indexOf(callback);
      if (index > -1) {
        this.eventListeners.splice(index, 1);
      }
    };
  }

  async saveTX(tx: TX): Promise<void> {
    this.txStore.set(tx.id, serializeTX(tx));
    this.emit('tx:saved', tx.id);
  }

  async getTX(id: UUID): Promise<TX | null> {
    const data = this.txStore.get(id);
    return data ? deserializeTX(data) : null;
  }

  async getTXsByState(state: TXState): Promise<TX[]> {
    const results: TX[] = [];
    for (const data of this.txStore.values()) {
      const tx = deserializeTX(data);
      if (tx.state === state) {
        results.push(tx);
      }
    }
    return results;
  }

  async getTXsByContributor(address: Address): Promise<TX[]> {
    const results: TX[] = [];
    for (const data of this.txStore.values()) {
      const tx = deserializeTX(data);
      if (tx.chain.some(e => e.contributor.address === address)) {
        results.push(tx);
      }
    }
    return results;
  }

  async deleteTX(id: UUID): Promise<boolean> {
    const deleted = this.txStore.delete(id);
    if (deleted) {
      this.emit('tx:deleted', id);
    }
    return deleted;
  }

  async saveNode(node: RelayNode): Promise<void> {
    this.nodeStore.set(node.id, { ...node });
    this.emit('node:saved', node.id);
  }

  async getNode(id: Hash): Promise<RelayNode | null> {
    return this.nodeStore.get(id) ?? null;
  }

  async getNodesByOperator(operator: Address): Promise<RelayNode[]> {
    return Array.from(this.nodeStore.values())
      .filter(n => n.operator === operator);
  }

  async getActiveNodes(): Promise<RelayNode[]> {
    return Array.from(this.nodeStore.values())
      .filter(n => n.status === NodeStatus.Active);
  }

  async deleteNode(id: Hash): Promise<boolean> {
    const deleted = this.nodeStore.delete(id);
    if (deleted) {
      this.emit('node:deleted', id);
    }
    return deleted;
  }

  async saveProfile(profile: ContributorProfile): Promise<void> {
    this.profileStore.set(profile.address, { ...profile });
    this.emit('profile:saved', profile.address);
  }

  async getProfile(address: Address): Promise<ContributorProfile | null> {
    return this.profileStore.get(address) ?? null;
  }

  async getAllProfiles(): Promise<ContributorProfile[]> {
    return Array.from(this.profileStore.values());
  }

  async deleteProfile(address: Address): Promise<boolean> {
    const deleted = this.profileStore.delete(address);
    if (deleted) {
      this.emit('profile:deleted', address);
    }
    return deleted;
  }

  async saveIssuance(issuance: TokenIssuance): Promise<void> {
    this.issuanceStore.set(issuance.id, { ...issuance });
  }

  async getIssuance(id: Hash): Promise<TokenIssuance | null> {
    return this.issuanceStore.get(id) ?? null;
  }

  async getIssuancesByTX(txId: UUID): Promise<TokenIssuance[]> {
    return Array.from(this.issuanceStore.values())
      .filter(i => i.txId === txId);
  }

  async saveForfeit(record: ForfeitRecord): Promise<void> {
    this.forfeitStore.set(record.id, { ...record });
  }

  async getForfeit(id: Hash): Promise<ForfeitRecord | null> {
    return this.forfeitStore.get(id) ?? null;
  }

  async getUnprocessedForfeits(): Promise<ForfeitRecord[]> {
    return Array.from(this.forfeitStore.values())
      .filter(f => !f.processed);
  }

  async saveReserveState(state: ReserveState): Promise<void> {
    this.reserveState = { ...state };
  }

  async getReserveState(): Promise<ReserveState | null> {
    return this.reserveState;
  }

  async clear(): Promise<void> {
    this.txStore.clear();
    this.nodeStore.clear();
    this.profileStore.clear();
    this.issuanceStore.clear();
    this.forfeitStore.clear();
    this.reserveState = null;
  }

  async getStats(): Promise<StorageStats> {
    return {
      txCount: this.txStore.size,
      nodeCount: this.nodeStore.size,
      profileCount: this.profileStore.size,
      issuanceCount: this.issuanceStore.size,
      forfeitCount: this.forfeitStore.size,
      lastUpdated: Date.now() as Timestamp
    };
  }
}

/**
 * Create a new memory storage instance
 */
export function createMemoryStorage(): MemoryStorage {
  return new MemoryStorage();
}

/**
 * Singleton instance for convenience
 */
let defaultStorage: MemoryStorage | null = null;

export function getDefaultStorage(): MemoryStorage {
  if (!defaultStorage) {
    defaultStorage = createMemoryStorage();
  }
  return defaultStorage;
}

export function resetDefaultStorage(): void {
  defaultStorage = null;
}
