import {
  btcToTokens,
  tokensToBTC,
  calculateMarketCap,
  calculateReserveRatio,
  calculatePremium,
  projectFloorAfterForfeit,
  calculateTokenDistribution,
  calculateFDV,
  calculateVelocity,
  estimateBTCPerToken,
  calculateInflationRate,
  calculateEffectiveYield,
  getTokenEconomicsSummary
} from '../../src/token/calculator';
import { depositBTC, resetReserve } from '../../src/token/reserve';
import { clearLedger, mintTokens } from '../../src/token/minter';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { DistributionResult } from '../../src/types/tx';
import { Role } from '../../src/types/contributor';
import { Address, BasisPoints, Satoshi, TokenAmount, UUID } from '../../src/types/common';
import { generateUUID } from '../../src/crypto/uuid';
import { PROTOCOL_CONSTANTS } from '../../src/constants';

describe('Token Calculator Module', () => {
  const keys1 = generateKeyPair();
  const address1 = privateKeyToAddress(keys1.privateKey);

  beforeEach(() => {
    resetReserve();
    clearLedger();
  });

  describe('btcToTokens', () => {
    it('should convert BTC to token amount', () => {
      const btc = 1000000n as Satoshi;

      const tokens = btcToTokens(btc);

      expect(tokens).toBeGreaterThan(0n);
    });

    it('should be consistent with rate', () => {
      const btc = PROTOCOL_CONSTANTS.TOKEN_RATE;

      const tokens = btcToTokens(btc as Satoshi);

      // 1 TOKEN_RATE worth of BTC should equal 10^18 tokens (1 token)
      expect(tokens).toBe(1000000000000000000n);
    });
  });

  describe('tokensToBTC', () => {
    it('should convert tokens to BTC value', () => {
      const tokens = 1000000000000000000n as TokenAmount;

      const btc = tokensToBTC(tokens);

      expect(btc).toBe(PROTOCOL_CONSTANTS.TOKEN_RATE);
    });

    it('should be inverse of btcToTokens', () => {
      const originalBTC = 5000000n as Satoshi;
      const tokens = btcToTokens(originalBTC);
      const backToBTC = tokensToBTC(tokens);

      // Should be close (may have rounding)
      expect(Math.abs(Number(backToBTC - originalBTC))).toBeLessThanOrEqual(1);
    });
  });

  describe('calculateMarketCap', () => {
    it('should calculate market cap from price and supply', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];
      await mintTokens(txId, distribution);

      const pricePerToken = 100000n as Satoshi;
      const marketCap = calculateMarketCap(pricePerToken);

      expect(marketCap).toBeGreaterThan(0n);
    });

    it('should return 0 for no supply', () => {
      const marketCap = calculateMarketCap(100000n as Satoshi);

      expect(marketCap).toBe(0n);
    });
  });

  describe('calculateReserveRatio', () => {
    it('should return 0 for no supply', () => {
      depositBTC(1000000n as Satoshi);

      const ratio = calculateReserveRatio(100000n as Satoshi);

      expect(ratio).toBe(0);
    });
  });

  describe('calculatePremium', () => {
    it('should return 0 when no floor price', () => {
      const premium = calculatePremium(100000n as Satoshi);

      expect(premium).toBe(0);
    });

    it('should calculate premium over floor', async () => {
      depositBTC(1000000n as Satoshi);

      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];
      await mintTokens(txId, distribution);

      // Set market price higher than floor
      const marketPrice = 2000000n as Satoshi;
      const premium = calculatePremium(marketPrice);

      expect(premium).toBeGreaterThanOrEqual(0);
    });
  });

  describe('projectFloorAfterForfeit', () => {
    it('should project higher floor after forfeit', async () => {
      depositBTC(1000000n as Satoshi);

      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 10000000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];
      await mintTokens(txId, distribution);

      const forfeitAmount = 1000000000000000000n as TokenAmount;
      const projectedFloor = projectFloorAfterForfeit(forfeitAmount);

      expect(projectedFloor).toBeGreaterThan(0n);
    });
  });

  describe('calculateTokenDistribution', () => {
    it('should distribute tokens according to weights', () => {
      const payment = 1000000n as Satoshi;
      const weights = new Map<string, BasisPoints>();
      weights.set('addr1', 6000 as BasisPoints);
      weights.set('addr2', 4000 as BasisPoints);

      const distribution = calculateTokenDistribution(payment, weights);

      expect(distribution.size).toBe(2);
      const addr1Tokens = distribution.get('addr1')!;
      const addr2Tokens = distribution.get('addr2')!;
      expect(addr1Tokens).toBeGreaterThan(addr2Tokens);
    });
  });

  describe('calculateFDV', () => {
    it('should calculate fully diluted valuation', () => {
      const pricePerToken = 100000n as Satoshi;
      const maxSupply = 1000000000000000000000n as TokenAmount; // 1000 tokens

      const fdv = calculateFDV(pricePerToken, maxSupply);

      expect(fdv).toBeGreaterThan(0n);
    });
  });

  describe('calculateVelocity', () => {
    it('should calculate token velocity', () => {
      const volume = 100000n as TokenAmount;
      const supply = 1000000n as TokenAmount;

      const velocity = calculateVelocity(volume, supply);

      expect(velocity).toBe(0.1);
    });

    it('should return 0 for zero supply', () => {
      const velocity = calculateVelocity(100000n as TokenAmount, 0n as TokenAmount);

      expect(velocity).toBe(0);
    });
  });

  describe('estimateBTCPerToken', () => {
    it('should return 0 for no supply', () => {
      depositBTC(1000000n as Satoshi);

      const btcPerToken = estimateBTCPerToken();

      expect(btcPerToken).toBe(0n);
    });
  });

  describe('calculateInflationRate', () => {
    it('should calculate inflation rate', () => {
      const issued = 100000n as TokenAmount;
      const previousSupply = 1000000n as TokenAmount;

      const rate = calculateInflationRate(issued, previousSupply);

      expect(rate).toBe(0.1);
    });

    it('should return 0 for zero previous supply', () => {
      const rate = calculateInflationRate(100000n as TokenAmount, 0n as TokenAmount);

      expect(rate).toBe(0);
    });
  });

  describe('calculateEffectiveYield', () => {
    it('should calculate total value and yield', () => {
      const btcEarned = 100000n as Satoshi;
      const tokensEarned = 1000000000000000000n as TokenAmount;
      const tokenPrice = 50000n as Satoshi;
      const timeframeMs = 30 * 24 * 60 * 60 * 1000; // 30 days

      const result = calculateEffectiveYield(btcEarned, tokensEarned, tokenPrice, timeframeMs);

      expect(result.totalValueBTC).toBeGreaterThan(btcEarned);
      expect(result.annualizedYieldPercent).toBeDefined();
    });
  });

  describe('getTokenEconomicsSummary', () => {
    it('should return complete summary', async () => {
      depositBTC(1000000n as Satoshi);

      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];
      await mintTokens(txId, distribution);

      const summary = getTokenEconomicsSummary(100000n as Satoshi);

      expect(summary.totalSupply).toBeDefined();
      expect(summary.circulatingSupply).toBeDefined();
      expect(summary.floorPrice).toBeDefined();
      expect(summary.marketCap).toBeDefined();
    });
  });
});
