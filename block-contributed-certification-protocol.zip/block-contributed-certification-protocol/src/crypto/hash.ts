import { sha3_256 } from 'js-sha3';
import { Hash } from '../types/common';

/**
 * Compute SHA3-256 hash of input data
 */
export function hash(data: string | Buffer | Uint8Array): Hash {
  const hashHex = sha3_256(data);
  return `0x${hashHex}` as Hash;
}

/**
 * Hash multiple values by concatenating them
 */
export function hashMultiple(...values: (string | Buffer | Uint8Array)[]): Hash {
  const combined = values.map(v =>
    typeof v === 'string' ? v : Buffer.from(v).toString('hex')
  ).join('');
  return hash(combined);
}

/**
 * Hash an object deterministically by sorting keys
 */
export function hashObject(obj: Record<string, unknown>): Hash {
  const sorted = JSON.stringify(obj, Object.keys(obj).sort());
  return hash(sorted);
}

/**
 * Verify that data matches expected hash
 */
export function verifyHash(data: string | Buffer | Uint8Array, expected: Hash): boolean {
  return hash(data) === expected;
}

/**
 * Create a hash chain from ordered items
 */
export function createHashChain(items: string[]): Hash[] {
  const chain: Hash[] = [];
  let prev: Hash | null = null;

  for (const item of items) {
    const input = prev ? `${prev}:${item}` : item;
    const current = hash(input);
    chain.push(current);
    prev = current;
  }

  return chain;
}

/**
 * Hash with domain separator for type safety
 */
export function hashWithDomain(domain: string, data: string | Buffer | Uint8Array): Hash {
  const domainHash = hash(domain);
  const dataHash = hash(data);
  return hash(`${domainHash}${dataHash}`);
}

/**
 * Create content-addressed identifier
 */
export function contentId(content: string | Buffer | Uint8Array, prefix: string = 'content'): Hash {
  return hashWithDomain(prefix, content);
}
