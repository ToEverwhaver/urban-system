// Profile management
export {
  getOrCreateProfile,
  updateProfileFromClosure,
  getProfile,
  getAllProfiles,
  getTopContributors,
  getContributorsByRole,
  getContributorsByMinReputation,
  getRecentlyActive,
  updateProfilesFromDistribution,
  clearProfiles,
  getProfileCount
} from './profile';

// Reputation calculator
export {
  ReputationBreakdown,
  getReputationBreakdown,
  getRoleSpecialization,
  predictReliability,
  compareContributors,
  getReputationStats,
  calculateTrustScore,
  getRecommendedForRole
} from './calculator';
