import {
  createOutboundSignature,
  createCounterSignature,
  createSignaturePair,
  getSignaturePairHash,
  createClosureSignature,
  getBCCPDomain,
  getOutboundMessageHash,
  getCounterMessageHash,
  computeChainHash
} from '../../src/signature/protocol';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { hash } from '../../src/crypto/hash';
import { Role } from '../../src/types/contributor';
import { Hash, Address, Satoshi, UUID } from '../../src/types/common';
import { generateUUID } from '../../src/crypto/uuid';

describe('Signature Protocol Module', () => {
  const senderKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();

  const senderAddress = privateKeyToAddress(senderKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);

  const contentHash = hash('test-content') as Hash;
  const previousHash = hash('previous') as Hash;

  describe('getBCCPDomain', () => {
    it('should return valid EIP-712 domain', () => {
      const domain = getBCCPDomain();

      expect(domain.name).toBe('BCCP Protocol');
      expect(domain.version).toBe('1');
      expect(domain.chainId).toBe(1);
    });

    it('should accept custom chainId', () => {
      const domain = getBCCPDomain(137);

      expect(domain.chainId).toBe(137);
    });
  });

  describe('createOutboundSignature', () => {
    it('should create valid outbound signature', () => {
      const sig = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      expect(sig.type).toBe('OUTBOUND');
      expect(sig.from).toBe(senderAddress);
      expect(sig.to).toBe(receiverAddress);
      expect(sig.contentHash).toBe(contentHash);
      expect(sig.previousHash).toBe(previousHash);
      expect(sig.role).toBe(Role.Receiver);
      expect(sig.timestamp).toBeDefined();
      expect(sig.signature).toBeDefined();
    });

    it('should handle null previousHash', () => {
      const sig = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        null,
        Role.Initiator,
        senderKeys.privateKey
      );

      expect(sig.previousHash).toBeNull();
    });
  });

  describe('createCounterSignature', () => {
    it('should create valid counter signature', () => {
      const outbound = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const counter = createCounterSignature(
        receiverAddress,
        outbound,
        true,
        receiverKeys.privateKey
      );

      expect(counter.type).toBe('COUNTER');
      expect(counter.from).toBe(receiverAddress);
      expect(counter.originalSigner).toBe(senderAddress);
      expect(counter.responsibilityAccepted).toBe(true);
      expect(counter.timestamp).toBeGreaterThanOrEqual(outbound.timestamp);
      expect(counter.signature).toBeDefined();
    });

    it('should allow rejecting responsibility', () => {
      const outbound = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const counter = createCounterSignature(
        receiverAddress,
        outbound,
        false,
        receiverKeys.privateKey
      );

      expect(counter.responsibilityAccepted).toBe(false);
    });
  });

  describe('createSignaturePair', () => {
    it('should create complete signature pair', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      expect(pair.outbound).toBeDefined();
      expect(pair.counter).toBeDefined();
      expect(pair.outbound.from).toBe(senderAddress);
      expect(pair.outbound.to).toBe(receiverAddress);
      expect(pair.counter.from).toBe(receiverAddress);
      expect(pair.counter.responsibilityAccepted).toBe(true);
    });
  });

  describe('getSignaturePairHash', () => {
    it('should return consistent hash', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      const hash1 = getSignaturePairHash(pair);
      const hash2 = getSignaturePairHash(pair);

      expect(hash1).toBe(hash2);
      expect(hash1).toMatch(/^0x[0-9a-f]{64}$/);
    });
  });

  describe('createClosureSignature', () => {
    it('should create closure signature', () => {
      const txId = generateUUID() as UUID;
      const txMerkleRoot = hash('merkle-root') as Hash;
      const paymentAmount = 100000n as Satoshi;

      const sig = createClosureSignature(
        senderAddress,
        txId,
        txMerkleRoot,
        paymentAmount,
        senderKeys.privateKey
      );

      expect(sig).toBeDefined();
      expect(sig.r).toMatch(/^0x[0-9a-f]+$/);
      expect(sig.s).toMatch(/^0x[0-9a-f]+$/);
      expect(sig.v).toBeGreaterThanOrEqual(27);
    });
  });

  describe('getOutboundMessageHash', () => {
    it('should return deterministic hash', () => {
      const sig = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const hash1 = getOutboundMessageHash(sig);
      const hash2 = getOutboundMessageHash(sig);

      expect(hash1).toBe(hash2);
    });
  });

  describe('getCounterMessageHash', () => {
    it('should return deterministic hash', () => {
      const outbound = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const counter = createCounterSignature(
        receiverAddress,
        outbound,
        true,
        receiverKeys.privateKey
      );

      const hash1 = getCounterMessageHash(counter);
      const hash2 = getCounterMessageHash(counter);

      expect(hash1).toBe(hash2);
    });
  });

  describe('computeChainHash', () => {
    it('should compute chain hash for multiple pairs', () => {
      const pair1 = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        null,
        Role.Receiver
      );

      const pair2 = createSignaturePair(
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        { address: senderAddress, privateKey: senderKeys.privateKey },
        hash('content-2') as Hash,
        contentHash,
        Role.Producer
      );

      const pairs = [pair1, pair2];
      const chainHash = computeChainHash(pairs, 1);

      expect(chainHash).toMatch(/^0x[0-9a-f]{64}$/);
    });

    it('should return different hash for different indices', () => {
      const pair1 = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        null,
        Role.Receiver
      );

      const pair2 = createSignaturePair(
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        { address: senderAddress, privateKey: senderKeys.privateKey },
        hash('content-2') as Hash,
        contentHash,
        Role.Producer
      );

      const pairs = [pair1, pair2];
      const hash0 = computeChainHash(pairs, 0);
      const hash1 = computeChainHash(pairs, 1);

      expect(hash0).not.toBe(hash1);
    });
  });
});
