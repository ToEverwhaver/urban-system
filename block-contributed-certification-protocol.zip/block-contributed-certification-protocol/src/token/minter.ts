import { TokenIssuance, TokenRecipient } from '../types/token';
import { DistributionResult } from '../types/tx';
import { Hash, TokenAmount, Timestamp, UUID, Address } from '../types/common';
import { hash } from '../crypto/hash';

const tokenLedger = new Map<Address, TokenAmount>();
const issuanceHistory: TokenIssuance[] = [];

/**
 * Mint tokens for a closed TX
 */
export async function mintTokens(
  txId: UUID,
  distribution: DistributionResult[]
): Promise<TokenIssuance> {
  const now = Date.now() as Timestamp;

  const recipients: TokenRecipient[] = distribution.map(d => ({
    address: d.contributor,
    amount: d.tokenAmount,
    accepted: d.tokenAccepted
  }));

  const totalMinted = recipients.reduce(
    (sum, r) => (sum + r.amount) as TokenAmount,
    0n as TokenAmount
  );

  const issuance: TokenIssuance = {
    id: hash(`issuance:${txId}:${now}`) as Hash,
    txId,
    amount: totalMinted,
    timestamp: now,
    recipients
  };

  for (const r of recipients) {
    if (r.accepted) {
      const current = tokenLedger.get(r.address) ?? (0n as TokenAmount);
      tokenLedger.set(r.address, (current + r.amount) as TokenAmount);
    }
  }

  issuanceHistory.push(issuance);
  return issuance;
}

/**
 * Get token balance for an address
 */
export function getBalance(address: Address): TokenAmount {
  return tokenLedger.get(address) ?? (0n as TokenAmount);
}

/**
 * Get total token supply
 */
export function getTotalSupply(): TokenAmount {
  let total = 0n as TokenAmount;
  for (const balance of tokenLedger.values()) {
    total = (total + balance) as TokenAmount;
  }
  return total;
}

/**
 * Get issuance by TX ID
 */
export function getIssuanceByTX(txId: UUID): TokenIssuance | undefined {
  return issuanceHistory.find(i => i.txId === txId);
}

/**
 * Get recent issuance history
 */
export function getIssuanceHistory(limit: number = 100): TokenIssuance[] {
  return issuanceHistory.slice(-limit);
}

/**
 * Get all balances
 */
export function getAllBalances(): Map<Address, TokenAmount> {
  return new Map(tokenLedger);
}

/**
 * Get top token holders
 */
export function getTopHolders(limit: number = 100): Array<{ address: Address; balance: TokenAmount }> {
  return Array.from(tokenLedger.entries())
    .map(([address, balance]) => ({ address, balance }))
    .sort((a, b) => (b.balance > a.balance ? 1 : -1))
    .slice(0, limit);
}

/**
 * Transfer tokens between addresses
 */
export function transfer(
  from: Address,
  to: Address,
  amount: TokenAmount
): boolean {
  const fromBalance = getBalance(from);
  if (fromBalance < amount) {
    return false;
  }

  tokenLedger.set(from, (fromBalance - amount) as TokenAmount);
  const toBalance = getBalance(to);
  tokenLedger.set(to, (toBalance + amount) as TokenAmount);

  return true;
}

/**
 * Burn tokens from an address
 */
export function burn(address: Address, amount: TokenAmount): boolean {
  const balance = getBalance(address);
  if (balance < amount) {
    return false;
  }

  tokenLedger.set(address, (balance - amount) as TokenAmount);
  return true;
}

/**
 * Get total minted tokens (including burned)
 */
export function getTotalMinted(): TokenAmount {
  return issuanceHistory.reduce(
    (sum, i) => (sum + i.amount) as TokenAmount,
    0n as TokenAmount
  );
}

/**
 * Clear ledger (for testing)
 */
export function clearLedger(): void {
  tokenLedger.clear();
  issuanceHistory.length = 0;
}
