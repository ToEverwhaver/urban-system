# BCCP - ブロックチェーン認証貢献プロトコル v2.0

ブロックチェーンベースの署名チェーンを通じて貢献を認証し報酬を付与するための包括的なプロトコル。

## 概要

BCCP（Blockchain Certified Contribution Protocol）は、協調的な貢献の透明な追跡、認証、報酬分配を可能にする分散型プロトコルです。暗号署名を使用して不変の貢献記録チェーンを作成します。

### 主要機能

- **署名ベースの信頼**: すべてのプロトコル決定は暗号署名のみに基づく
- **不変の記録**: 一度署名されると貢献は撤回・変更不可
- **公正な責任分配**: 二層構造の責任システム（金銭的・倫理的）
- **オンチェーンポートフォリオ**: すべての参加記録の永続的・公開記録
- **ステークシステム**: イニシエーターとレシーバーからの金銭的コミットメント
- **SIP-010準拠トークン**: Stacksブロックチェーン上のネイティブプロトコルトークン

### 核心原則

```
スポンサークローズなし = 価値創造なし
```

価値はスポンサーが暗号的にTXチェーンをクローズした時のみ生成され、以下を排除：
- インプレッション詐欺（カウントされるが行動されない広告）
- ラストクリック属性操作
- プライバシーネットワークにおける無償ボランティア労働

## アーキテクチャ

BCCP v2は2つの実装を提供：

| コンポーネント | 言語 | 目的 |
|---------------|------|------|
| TypeScript SDK | TypeScript | オフチェーン操作、API、クライアントライブラリ |
| Clarityコントラクト | Clarity | Stacksブロックチェーン上のオンチェーンスマートコントラクト |

## プロトコル仕様

### チェーン構造

```
A → B → C → D → ... → 終了宣言 → S（スポンサー）
```

| 項目 | 仕様 |
|------|------|
| 最小長 | A → B（2参加者） |
| 最大長 | 上限なし |
| 同一人物の複数参加 | 可能（A = C も有効） |

### 署名の種類

| 種類 | 署名者 | 意味 |
|------|--------|------|
| チェーン署名 | A, B, C, D, ... | 「前の成果を受け入れ、自分の責任を宣言」 |
| 終了宣言 | 誰でも | 「このTXは完成、スポンサー募集開始」 |
| スポンサー署名 | スポンサー（S） | 「この完成品を購入」+ 支払い |

### TX状態

```
Open（進行中）
    │
    ├─→ 終了宣言 → Open + 募集中
    │                  │
    │                  ├─→ スポンサー署名 → Closed
    │                  │
    │                  └─→ タイムアウト → Expired
    │
    └─→ 拒否 → Rejected
```

### ステークシステム

| 参加者 | ステーク必要 |
|--------|--------------|
| A（イニシエーター） | はい |
| B（レシーバー） | はい |
| C以降 | いいえ |

| TX結果 | ステーク処理 |
|--------|--------------|
| Closed | 返還 + 報酬 |
| Expired | 返還（ペナルティなし） |
| Rejected | 責任割合に応じて没収 |

### 責任分配

**核心原則：** 「誰が作ったか」ではなく「誰が承認したか」

**二層構造（独立）：**

| 種類 | 対象 | 配分 | 説明 |
|------|------|------|------|
| 金銭的責任 | A, Bのみ | 常に 50% / 50% | ステーク没収（チェーン長に関係なく） |
| 倫理的責任 | 拒否された者 + その前の者 | 51% / 49% | ポートフォリオ記録 |

**倫理的責任ルール：**

| チェーン長 | 拒否された者 (n-2) | その前の者 (n-3) | 拒否者 (n-1) | それ以前 |
|-----------|-------------------|-----------------|--------------|----------|
| 2 (A→B拒否) | A: 100% | N/A | B: 0% | N/A |
| 3+ (例：E拒否) | D: 51% | C: 49% | E: 0% | 0% |

**主要ルール：**
- 拒否者は常に0%（絶対ルール - 報酬なし、責任なし）
- 金銭的責任と倫理的責任は独立して計算
- 拒否者の直前2者のみが倫理的責任を負う

## プロジェクト構造

```
BCCP/
├── src/                          # TypeScript SDKソース
│   ├── api/                      # REST APIエンドポイント
│   │   ├── closure-api.ts        # クローズワークフローAPI
│   │   ├── node-api.ts           # ノード管理API
│   │   └── tx-api.ts             # トランザクションAPI
│   ├── closure/                  # TXクローズと分配
│   │   ├── distribution.ts       # 報酬分配ロジック
│   │   └── processor.ts          # クローズ処理
│   ├── crypto/                   # 暗号ユーティリティ
│   │   ├── hash.ts               # SHA3-256ハッシュ
│   │   ├── merkle.ts             # マークルツリー操作
│   │   ├── signature.ts          # ECDSA secp256k1署名
│   │   └── uuid.ts               # UUID v7生成
│   ├── relay/                    # ノードリレーシステム
│   │   ├── node.ts               # ノード登録
│   │   ├── scoring.ts            # ノードスコアリング
│   │   ├── selector.ts           # ルート選択
│   │   └── slashing.ts           # スラッシングメカニズム
│   ├── reputation/               # レピュテーション計算
│   │   ├── calculator.ts         # スコア計算
│   │   └── profile.ts            # ユーザープロファイル
│   ├── signature/                # 署名プロトコル
│   │   ├── protocol.ts           # 署名作成
│   │   └── verifier.ts           # 署名検証
│   ├── storage/                  # データストレージインターフェース
│   │   ├── interface.ts          # ストレージインターフェース
│   │   └── memory.ts             # インメモリ実装
│   ├── token/                    # トークンエコノミクス
│   │   ├── calculator.ts         # トークン計算
│   │   ├── forfeit.ts            # 没収処理
│   │   ├── minter.ts             # トークンミント
│   │   └── reserve.ts            # BTCリザーブ管理
│   ├── tx/                       # トランザクション管理
│   │   ├── builder.ts            # Fluent TXビルダー
│   │   ├── chain.ts              # チェーン管理
│   │   └── validator.ts          # TX検証
│   ├── types/                    # TypeScript型定義
│   │   ├── common.ts             # 共通型
│   │   ├── contributor.ts        # 貢献者型
│   │   ├── node.ts               # ノード型
│   │   ├── signature.ts          # 署名型
│   │   ├── token.ts              # トークン型
│   │   └── tx.ts                 # トランザクション型
│   ├── utils/                    # ユーティリティ関数
│   │   ├── errors.ts             # エラー定義
│   │   └── validation.ts         # バリデーションスキーマ
│   ├── constants.ts              # プロトコル定数
│   └── index.ts                  # メインエクスポート
├── tests/                        # TypeScriptテストスイート（173テスト）
│   ├── closure/                  # クローズテスト
│   ├── crypto/                   # 暗号テスト
│   ├── integration/              # 統合テスト
│   ├── signature/                # 署名テスト
│   ├── token/                    # トークンテスト
│   └── tx/                       # TXテスト
├── examples/                     # 使用例
│   ├── create-tx.ts              # TX作成例
│   ├── close-tx.ts               # TXクローズ例
│   └── run-node.ts               # ノード操作例
├── bccp-clarity/                 # Clarityスマートコントラクト
│   ├── contracts/
│   │   ├── bccp-traits.clar      # トレイト定義（SIP-010、core、stake、portfolio、pool）
│   │   ├── bccp-token.clar       # SIP-010準拠BCCPトークン
│   │   ├── bccp-pool.clar        # 没収金プール管理
│   │   ├── bccp-portfolio.clar   # ポートフォリオ記録
│   │   ├── bccp-stake.clar       # ステーク管理
│   │   └── bccp-core.clar        # コアTXロジック
│   ├── tests/                    # Clarityテスト（50+テスト）
│   │   ├── bccp-core_test.ts
│   │   ├── bccp-token_test.ts
│   │   ├── bccp-stake_test.ts
│   │   ├── bccp-portfolio_test.ts
│   │   └── bccp-pool_test.ts
│   ├── settings/
│   │   └── Devnet.toml           # Devnet設定
│   └── Clarinet.toml             # プロジェクト設定
└── docs/                         # 仕様書
    ├── BCCP_FULL_DEVELOPMENT_SPEC.md
    ├── BCCP_README_v2.md
    └── bccp-core-rules-v2.md
```

## インストール

### TypeScript SDK

```bash
# リポジトリをクローン
git clone https://github.com/ToEverwhaver/BCCP.git
cd BCCP

# 依存関係をインストール
npm install

# ビルド
npm run build

# テスト実行
npm test
```

### Clarityコントラクト

```bash
# Clarinetをインストール（https://github.com/hirosystems/clarinet）
brew install clarinet  # macOS
# または
curl -L https://github.com/hirosystems/clarinet/releases/download/v1.7.1/clarinet-linux-x64.tar.gz | tar xz

# Clarityプロジェクトに移動
cd bccp-clarity

# コントラクトをチェック
clarinet check

# テスト実行
clarinet test

# ローカルdevnetを起動
clarinet integrate
```

## 使い方

### TypeScript SDK

#### トランザクションの作成

```typescript
import {
  txBuilder,
  generateKeyPair,
  privateKeyToAddress,
  createSignaturePair,
  hash,
  Role,
  BasisPoints,
  Hash
} from 'bccp-protocol';

// 参加者のキーを生成
const initiatorKeys = generateKeyPair();
const receiverKeys = generateKeyPair();

const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);

// アセットハッシュを作成
const assetHash = hash('オリジナルコンテンツ') as Hash;
const receiverContent = hash('処理済みコンテンツ') as Hash;

// 署名ペアを作成
const sigPair = createSignaturePair(
  { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
  { address: receiverAddress, privateKey: receiverKeys.privateKey },
  receiverContent,
  assetHash,
  Role.Receiver
);

// TXをビルド
const tx = txBuilder({
  assetHash,
  assetType: 'article',
  initiator: initiatorAddress
})
  .addReceiver(receiverAddress, sigPair, receiverContent, 4000 as BasisPoints)
  .setWeight(initiatorAddress, 6000 as BasisPoints)
  .build();
```

#### トランザクションのクローズ

```typescript
import {
  processClosure,
  previewDistribution,
  mintTokens,
  createClosureSignature,
  Satoshi
} from 'bccp-protocol';

// 分配をプレビュー
const payment = 1000000n as Satoshi; // 0.01 BTC
const preview = previewDistribution(tx, payment);

console.log(`プロトコル手数料: ${preview.protocolFee}`);
console.log(`分配BTC: ${preview.totalBTC}`);
console.log(`ミントトークン: ${preview.totalTokens}`);

// スポンサー署名を作成
const sponsorSig = createClosureSignature(
  sponsorAddress,
  tx.id,
  tx.chainMerkleRoot!,
  payment,
  sponsorKeys.privateKey
);

// クローズを処理
const result = await processClosure(tx, {
  txId: tx.id,
  sponsor: sponsorAddress,
  sponsorSignature: sponsorSig,
  paymentAmount: payment
});

// トークンをミント
if (result.success) {
  await mintTokens(tx.id, result.distribution!);
}
```

### Clarityコントラクト

#### TX作成（オンチェーン）

```clarity
;; コンテンツハッシュで新しいTXを作成
(contract-call? .bccp-core create-tx 0x1234567890abcdef...)

;; レシーバーとして受諾（B）
(contract-call? .bccp-core accept-as-receiver u1)

;; 次の参加者を追加（C以降）
(contract-call? .bccp-core add-participant u1 'ST1PQHQKV0RJXZFY1DGX8MNSNYVE3VGZJSRTPGZGM)
```

#### ステーキング

```clarity
;; ステークを預入（AまたはBのみ、最小1 STX）
(contract-call? .bccp-stake deposit-stake u1 u1000000)

;; ステークステータスを確認
(contract-call? .bccp-stake get-tx-stake-summary u1)

;; 両者がステークしたか確認
(contract-call? .bccp-stake has-both-stakes u1)
```

#### クローズとスポンサリング

```clarity
;; クローズ準備完了を宣言（誰でも可能）
(contract-call? .bccp-core declare-closure-ready u1)

;; スポンサーしてクローズ（支払いと確定）
(contract-call? .bccp-core sponsor-close u1 u10000000)  ;; 10 STX支払い
```

#### 拒否

```clarity
;; TXを拒否（次の予定参加者のみ可能）
(contract-call? .bccp-core reject-tx u1)
```

## スマートコントラクトリファレンス

### bccp-core.clar

| 関数 | 説明 |
|------|------|
| `create-tx` | コンテンツハッシュで新しいTXを作成 |
| `accept-as-receiver` | レシーバーとして受諾（Bポジション） |
| `add-participant` | チェーンに参加者を追加（C以降） |
| `reject-tx` | TXを拒否（次の参加者のみ） |
| `declare-closure-ready` | スポンサー募集の準備完了を宣言 |
| `sponsor-close` | 支払いしてTXをクローズ |
| `expire-tx` | TXを期限切れとしてマーク |
| `get-tx-info` | TX情報を取得 |
| `get-tx-full` | 完全なTXデータを取得 |
| `get-chain-entry` | 位置のチェーン参加者を取得 |

### bccp-token.clar（SIP-010準拠）

| 関数 | 説明 |
|------|------|
| `transfer` | トークンを転送 |
| `get-balance` | プリンシパルの残高を取得 |
| `get-total-supply` | 総供給量を取得 |
| `get-name` | トークン名を取得（"BCCP Token"） |
| `get-symbol` | トークンシンボルを取得（"BCCP"） |
| `get-decimals` | 小数点以下桁数を取得（6） |
| `mint` | 新しいトークンをミント（認可済みのみ） |
| `burn` | トークンをバーン |
| `set-allowance` | 支出許可を設定 |
| `transfer-from` | 許可を使用して転送 |

### bccp-stake.clar

| 関数 | 説明 |
|------|------|
| `deposit-stake` | ステークを預入（AまたはBポジション） |
| `return-stakes` | 成功クローズ時にステークを返還 |
| `forfeit-stakes` | 拒否時にステークを没収 |
| `get-stake-info` | ステーク情報を取得 |
| `get-tx-stake-summary` | TXステークサマリーを取得 |
| `has-both-stakes` | AとBの両方がステークしたか確認 |

### bccp-portfolio.clar

| 関数 | 説明 |
|------|------|
| `record-participation` | 新しい参加を記録 |
| `record-rejection` | 拒否責任を記録 |
| `record-closure` | 成功クローズを記録 |
| `record-expiration` | TX期限切れを記録 |
| `get-portfolio-summary` | ポートフォリオサマリーを取得 |
| `get-participation` | 特定の参加記録を取得 |

### bccp-pool.clar

| 関数 | 説明 |
|------|------|
| `add-to-pool` | 没収STXを追加（自動的にBCCPに変換） |
| `add-bccp-to-pool` | BCCPを直接プールに追加 |
| `record-forfeiture` | 内訳付きで没収を記録 |
| `get-pool-balance` | 現在のプール残高を取得 |
| `distribute-from-pool` | プールから分配（ガバナンス） |
| `get-pool-stats` | プール統計を取得 |

## プロトコル定数

| 定数 | 値 | 説明 |
|------|------|------|
| `PROTOCOL_FEE_RATE` | 3% | クローズ支払いの手数料 |
| `BTC_DISTRIBUTION_RATIO` | 80% | BTCとして分配される割合 |
| `TOKEN_DISTRIBUTION_RATIO` | 20% | トークンとして分配される割合 |
| `MIN_NODE_STAKE` | 0.001 BTC | 最小リレーノードステーク |
| `DEFAULT_MIN_STAKE` | 1 STX | デフォルト最小ステーク（Clarity） |
| `DEFAULT_TIMEOUT_BLOCKS` | 1008 | 約7日のタイムアウト |
| `CONVERSION_RATE` | 100 | 1 STX = 100 BCCP |

## テスト

### TypeScriptテスト

```bash
# 全テスト実行
npm test

# 特定のテストファイルを実行
npm test -- tests/tx/chain.test.ts

# カバレッジ付きで実行
npm test -- --coverage
```

**テストカバレッジ: 13テストファイルで173テスト**

### Clarityテスト

```bash
cd bccp-clarity

# 全テスト実行
clarinet test

# 特定のテストを実行
clarinet test tests/bccp-core_test.ts

# 詳細出力で実行
clarinet test --verbose
```

**テストカバレッジ: 5テストファイルで50+テスト**

## デプロイ

### ローカル開発

```bash
cd bccp-clarity

# 全サービスでローカルdevnetを起動
clarinet integrate

# 起動されるもの:
# - Bitcoinノード（ポート18443）
# - Stacksノード（ポート20443）
# - Stacks API（ポート3999）
# - エクスプローラー（ポート3020）
```

### テストネットデプロイ

```bash
cd bccp-clarity

# デプロイプランを生成
clarinet deployments generate --testnet

# deployments/default.testnet.yamlで生成されたプランを確認

# テストネットにデプロイ
clarinet deployments apply --testnet
```

### メインネットデプロイ

```bash
# メインネットデプロイを生成
clarinet deployments generate --mainnet

# デプロイプランを確認・検証

# 適用（トランザクション手数料用のSTXが必要）
clarinet deployments apply --mainnet
```

## トークンエコノミクス

### フロアプライス保証

```
フロアプライス = 総BTCリザーブ / 流通トークン供給量
```

トークンは常にフロアプライスで償還可能で、下値保護を提供。

### 没収処理

| 戦略 | 効果 |
|------|------|
| **BURN_AND_BUY** | トークンをバーン、BTC価値をリザーブに追加、フロアプライス上昇 |
| **AIRDROP** | 没収トークンをアクティブホルダーに再分配 |

## レピュテーションシステム

### スコア構成（0-1000）

| 構成要素 | 最大ポイント | 計算 |
|----------|-------------|------|
| ベース | 500 | 開始スコア |
| アクティビティ | +200 | `min(closedTXCount * 5, 200)` |
| 受諾率 | +150 | `acceptRate * 150` |
| 多様性 | +100 | `rolesUsed * 20` |
| 一貫性 | +50 | `min(txPerDay * 50, 50)` |

### ティア

| スコア | ティア |
|--------|--------|
| 900+ | DIAMOND |
| 800-899 | PLATINUM |
| 700-799 | GOLD |
| 600-699 | SILVER |
| 0-599 | BRONZE |

## プロトコル境界

### プロトコルが定義するもの

- 署名検証とチェーン構造
- ステーク要件（AとBのみ）
- 責任分配ルール
- ポートフォリオ記録要件
- TX状態遷移

### 実装が定義するもの（プロトコル外）

- 報酬分配割合
- 価格交渉メカニズム
- スポンサー選定方法
- タイムアウト期間の詳細
- UI/UXデザイン
- 具体的なステーク金額

## 統計

| コンポーネント | ファイル数 | コード行数 |
|----------------|-----------|-----------|
| TypeScript SDK | 52 | 約6,800 |
| TypeScriptテスト | 13 | 約2,500 |
| Clarityコントラクト | 6 | 約2,200 |
| Clarityテスト | 5 | 約2,200 |
| **合計** | **76** | **約13,700** |

## エラーハンドリング

### TypeScriptエラー

```typescript
import { BCCPError, SignatureError, ChainError, isBCCPError } from 'bccp-protocol';

try {
  // 操作
} catch (error) {
  if (isBCCPError(error)) {
    console.log(error.code, error.message, error.details);
  }
}
```

### Clarityエラー

| コントラクト | エラーコード | 説明 |
|--------------|-------------|------|
| bccp-core | u5001 | 認可されていない |
| bccp-core | u5002 | 無効なTX |
| bccp-core | u5003 | 無効な状態 |
| bccp-core | u5004 | 次の参加者ではない |
| bccp-stake | u4001 | 認可されていない |
| bccp-stake | u4002 | 無効な金額 |
| bccp-stake | u4007 | 無効なポジション |
| bccp-token | u1001 | 認可されていない |
| bccp-token | u1002 | 残高不足 |

## コントリビューティング

1. リポジトリをフォーク
2. フィーチャーブランチを作成（`git checkout -b feature/amazing-feature`）
3. 変更をコミット（`git commit -m 'Add amazing feature'`）
4. ブランチにプッシュ（`git push origin feature/amazing-feature`）
5. プルリクエストを開く

## ライセンス

MITライセンス - 詳細は[LICENSE](LICENSE)ファイルを参照。

## リンク

- [コアルール v2](bccp-core-rules-v2.md)
- [完全開発仕様](BCCP_FULL_DEVELOPMENT_SPEC.md)
- [Stacksドキュメント](https://docs.stacks.co/)
- [Clarity言語リファレンス](https://docs.stacks.co/clarity)
- [SIP-010標準](https://github.com/stacksgov/sips/blob/main/sips/sip-010/sip-010-fungible-token-standard.md)

---

**バージョン**: 2.0.0
**最終更新**: 2025-12-14
**English Version**: [README.md](README.md)
