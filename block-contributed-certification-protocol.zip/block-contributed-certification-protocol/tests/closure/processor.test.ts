import {
  processClosure,
  validateClosureRequest,
  initiateClosure,
  cancelClosure,
  getClosureSummary,
  verifyClosureComplete,
  ClosureRequest,
  TokenDecision
} from '../../src/closure/processor';
import { createTX, addContributor, setWeights } from '../../src/tx/chain';
import { generateKeyPair, privateKeyToAddress, signMessage } from '../../src/crypto/signature';
import { createSignaturePair } from '../../src/signature/protocol';
import { hash } from '../../src/crypto/hash';
import { Role } from '../../src/types/contributor';
import { TXState } from '../../src/types/tx';
import { Hash, Address, BasisPoints, Timestamp, Satoshi } from '../../src/types/common';

describe('Closure Processor Module', () => {
  const initiatorKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();
  const sponsorKeys = generateKeyPair();

  const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);
  const sponsorAddress = privateKeyToAddress(sponsorKeys.privateKey);

  const assetHash = hash('test-asset') as Hash;

  function createOpenTX() {
    let tx = createTX({
      assetHash,
      assetType: 'test',
      initiator: initiatorAddress
    });

    const contentHash = hash('content') as Hash;
    const sigPair = createSignaturePair(
      { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
      { address: receiverAddress, privateKey: receiverKeys.privateKey },
      contentHash,
      assetHash,
      Role.Receiver
    );

    tx = addContributor(
      tx,
      {
        address: receiverAddress,
        role: Role.Receiver,
        weight: 4000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPair,
      contentHash
    );

    const weights = new Map<Address, BasisPoints>();
    weights.set(initiatorAddress, 6000 as BasisPoints);
    weights.set(receiverAddress, 4000 as BasisPoints);
    tx = setWeights(tx, weights);

    return tx;
  }

  describe('validateClosureRequest', () => {
    it('should validate correct request', () => {
      const tx = createOpenTX();

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 100000n as Satoshi
      };

      const result = validateClosureRequest(tx, request);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should fail for TX ID mismatch', () => {
      const tx = createOpenTX();

      const request: ClosureRequest = {
        txId: 'wrong-id' as any,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 100000n as Satoshi
      };

      const result = validateClosureRequest(tx, request);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('TX ID mismatch');
    });

    it('should fail for non-open TX', () => {
      let tx = createOpenTX();
      tx = { ...tx, state: TXState.Closed };

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 100000n as Satoshi
      };

      const result = validateClosureRequest(tx, request);

      expect(result.valid).toBe(false);
    });

    it('should fail for zero payment', () => {
      const tx = createOpenTX();

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 0n as Satoshi
      };

      const result = validateClosureRequest(tx, request);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Payment must be positive');
    });
  });

  describe('processClosure', () => {
    it('should process valid closure', async () => {
      const tx = createOpenTX();

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 1000000n as Satoshi
      };

      const result = await processClosure(tx, request);

      expect(result.success).toBe(true);
      expect(result.tx).toBeDefined();
      expect(result.tx!.state).toBe(TXState.Closed);
      expect(result.distribution).toBeDefined();
      expect(result.distribution!.length).toBe(2);
    });

    it('should process with token decisions', async () => {
      const tx = createOpenTX();

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 1000000n as Satoshi
      };

      const tokenDecisions: TokenDecision[] = [
        { contributor: initiatorAddress, accept: true },
        { contributor: receiverAddress, accept: false }
      ];

      const result = await processClosure(tx, request, tokenDecisions);

      expect(result.success).toBe(true);
      const receiverDist = result.distribution!.find(d => d.contributor === receiverAddress);
      expect(receiverDist!.tokenAccepted).toBe(false);
    });

    it('should fail for draft TX', async () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 1000000n as Satoshi
      };

      const result = await processClosure(tx, request);

      expect(result.success).toBe(false);
    });
  });

  describe('initiateClosure', () => {
    it('should move to pending closure state', () => {
      const tx = createOpenTX();

      const pending = initiateClosure(tx, sponsorAddress);

      expect(pending.state).toBe(TXState.PendingClosure);
    });

    it('should throw for non-open TX', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      expect(() => initiateClosure(tx, sponsorAddress)).toThrow();
    });
  });

  describe('cancelClosure', () => {
    it('should return to open state', () => {
      let tx = createOpenTX();
      tx = initiateClosure(tx, sponsorAddress);

      const cancelled = cancelClosure(tx);

      expect(cancelled.state).toBe(TXState.Open);
    });

    it('should throw for non-pending TX', () => {
      const tx = createOpenTX();

      expect(() => cancelClosure(tx)).toThrow();
    });
  });

  describe('getClosureSummary', () => {
    it('should return summary for unclosed TX', () => {
      const tx = createOpenTX();

      const summary = getClosureSummary(tx);

      expect(summary.isClosed).toBe(false);
      expect(summary.contributorCount).toBe(2);
    });

    it('should return full summary for closed TX', async () => {
      const tx = createOpenTX();

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 1000000n as Satoshi
      };

      const result = await processClosure(tx, request);
      const summary = getClosureSummary(result.tx!);

      expect(summary.isClosed).toBe(true);
      expect(summary.sponsor).toBe(sponsorAddress);
      expect(summary.paymentAmount).toBe(1000000n);
      expect(summary.totalDistributed).toBeDefined();
    });
  });

  describe('verifyClosureComplete', () => {
    it('should return false for unclosed TX', () => {
      const tx = createOpenTX();

      expect(verifyClosureComplete(tx)).toBe(false);
    });

    it('should return true for properly closed TX', async () => {
      const tx = createOpenTX();

      const request: ClosureRequest = {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as `0x${string}`, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as `0x${string}`, v: 27 },
        paymentAmount: 1000000n as Satoshi
      };

      const result = await processClosure(tx, request);

      expect(verifyClosureComplete(result.tx!)).toBe(true);
    });
  });
});
