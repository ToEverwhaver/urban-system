import { Address, Timestamp, Satoshi, TokenAmount, BasisPoints } from './common';

// Contributor roles in TX chain
export enum Role {
  Initiator = 'INITIATOR',    // A: Creates original asset
  Receiver = 'RECEIVER',      // B: Accepts with responsibility
  Producer = 'PRODUCER',      // C: Creates/processes
  Editor = 'EDITOR',          // D: Finalizes
  Custom = 'CUSTOM'           // Extensible
}

// Contributor in a TX
export interface Contributor {
  address: Address;
  role: Role;
  customRoleName?: string;    // Only if role === Custom
  weight: BasisPoints;        // Share of rewards
  joinedAt: Timestamp;
}

// Contributor profile (reputation data)
export interface ContributorProfile {
  address: Address;

  // Activity stats
  closedTXCount: number;
  totalEarnedBTC: Satoshi;
  totalEarnedToken: TokenAmount;

  // Token behavior
  acceptedTokens: TokenAmount;
  forfeitedTokens: TokenAmount;
  acceptRate: number;         // 0.0 - 1.0

  // Role breakdown
  roleCount: Record<Role, number>;

  // Reputation
  reputationScore: number;    // 0 - 1000

  // Timestamps
  firstActivityAt: Timestamp;
  lastActivityAt: Timestamp;
}

// Default weights by role
export const DEFAULT_WEIGHTS: Record<Role, BasisPoints> = {
  [Role.Initiator]: 3000 as BasisPoints,
  [Role.Receiver]: 2500 as BasisPoints,
  [Role.Producer]: 2000 as BasisPoints,
  [Role.Editor]: 1500 as BasisPoints,
  [Role.Custom]: 1000 as BasisPoints
};

export function createContributor(
  address: Address,
  role: Role,
  weight?: BasisPoints,
  customRoleName?: string
): Contributor {
  return {
    address,
    role,
    customRoleName: role === Role.Custom ? customRoleName : undefined,
    weight: weight ?? DEFAULT_WEIGHTS[role],
    joinedAt: Date.now() as Timestamp
  };
}
