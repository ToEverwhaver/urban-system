import { RelayNode, NodeStatus, RegisterNodeParams, Heartbeat, Route } from '../types/node';
import { Hash, Address, Satoshi, Timestamp } from '../types/common';
import { ECDSASignature } from '../types/signature';
import {
  registerNode,
  activateNode,
  deactivateNode,
  processHeartbeat,
  recordRelay,
  getNode,
  getActiveNodes,
  getNodesByOperator,
  getNodeCount
} from '../relay/node';
import { selectRoute, verifyRoute, getRouteQuality } from '../relay/selector';
import { createSlashingEvent, fileAppeal, getSlashingEvents, isAtRisk } from '../relay/slashing';
import { SlashReason, SlashingEvent } from '../types/node';
import { getDefaultStorage } from '../storage/memory';

export interface RegisterNodeRequest {
  operator: Address;
  publicKey: string;
  endpoint: string;
  stake: Satoshi;
}

export interface HeartbeatRequest {
  nodeId: Hash;
  metrics: {
    uptime: number;
    latencyAvg: number;
    latencyP99: number;
    bandwidth: number;
    activeConnections: number;
    cpuUsage: number;
    memoryUsage: number;
  };
  signature: ECDSASignature;
}

export interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

/**
 * Register a new node
 */
export async function apiRegisterNode(
  request: RegisterNodeRequest
): Promise<APIResponse<RelayNode>> {
  try {
    const node = registerNode({
      operator: request.operator,
      publicKey: request.publicKey as any,
      endpoint: request.endpoint,
      stake: request.stake
    });

    await getDefaultStorage().saveNode(node);
    return { success: true, data: node };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Activate a node
 */
export async function apiActivateNode(nodeId: Hash): Promise<APIResponse<RelayNode>> {
  try {
    const node = activateNode(nodeId);
    await getDefaultStorage().saveNode(node);
    return { success: true, data: node };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Deactivate a node
 */
export async function apiDeactivateNode(nodeId: Hash): Promise<APIResponse<RelayNode>> {
  try {
    const node = deactivateNode(nodeId);
    await getDefaultStorage().saveNode(node);
    return { success: true, data: node };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Submit heartbeat
 */
export async function apiSubmitHeartbeat(
  request: HeartbeatRequest
): Promise<APIResponse<RelayNode>> {
  try {
    const heartbeat: Heartbeat = {
      nodeId: request.nodeId,
      timestamp: Date.now() as Timestamp,
      metrics: request.metrics,
      signature: request.signature
    };

    const node = processHeartbeat(heartbeat);
    await getDefaultStorage().saveNode(node);
    return { success: true, data: node };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Record relay result
 */
export async function apiRecordRelay(
  nodeId: Hash,
  success: boolean
): Promise<APIResponse<RelayNode>> {
  try {
    const node = recordRelay(nodeId, success);
    await getDefaultStorage().saveNode(node);
    return { success: true, data: node };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get node info
 */
export async function apiGetNode(nodeId: Hash): Promise<APIResponse<RelayNode>> {
  try {
    const node = getNode(nodeId);
    if (!node) {
      return { success: false, error: 'Node not found' };
    }
    return { success: true, data: node };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get nodes by operator
 */
export async function apiGetNodesByOperator(
  operator: Address
): Promise<APIResponse<RelayNode[]>> {
  try {
    const nodes = getNodesByOperator(operator);
    return { success: true, data: nodes };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get active nodes
 */
export async function apiGetActiveNodes(): Promise<APIResponse<RelayNode[]>> {
  try {
    const nodes = getActiveNodes();
    return { success: true, data: nodes };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get network stats
 */
export async function apiGetNetworkStats(): Promise<APIResponse<{
  total: number;
  active: number;
  pending: number;
}>> {
  try {
    const stats = getNodeCount();
    return { success: true, data: stats };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Request a route
 */
export async function apiRequestRoute(
  excludeNodes: Hash[] = [],
  nodeCount: number = 3
): Promise<APIResponse<Route>> {
  try {
    const route = selectRoute(excludeNodes, nodeCount);
    if (!route) {
      return { success: false, error: 'Not enough active nodes for route' };
    }
    return { success: true, data: route };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Verify route validity
 */
export async function apiVerifyRoute(
  route: Route
): Promise<APIResponse<{ valid: boolean; reason?: string; quality?: number }>> {
  try {
    const verification = verifyRoute(route);
    const quality = verification.valid ? getRouteQuality(route) : undefined;
    return {
      success: true,
      data: { ...verification, quality }
    };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Report malicious node
 */
export async function apiReportNode(
  nodeId: Hash,
  reason: SlashReason,
  evidence?: Hash
): Promise<APIResponse<SlashingEvent>> {
  try {
    const event = createSlashingEvent(nodeId, reason, evidence);
    return { success: true, data: event };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Check if node is at risk
 */
export async function apiCheckNodeRisk(
  nodeId: Hash
): Promise<APIResponse<{ atRisk: boolean; reasons: SlashReason[] }>> {
  try {
    const result = isAtRisk(nodeId);
    return { success: true, data: result };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}
