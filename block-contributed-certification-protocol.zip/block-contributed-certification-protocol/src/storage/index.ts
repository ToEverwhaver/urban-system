export {
  Storage,
  StorageStats,
  QueryOptions,
  BatchOperations,
  StorageEventType,
  StorageEvent,
  EventedStorage
} from './interface';

export {
  MemoryStorage,
  createMemoryStorage,
  getDefaultStorage,
  resetDefaultStorage
} from './memory';
