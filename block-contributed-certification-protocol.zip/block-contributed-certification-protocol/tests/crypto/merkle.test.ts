import { buildMerkleTree, generateProof, verifyProof, getMerkleRoot } from '../../src/crypto/merkle';
import { hash } from '../../src/crypto/hash';
import { Hash } from '../../src/types/common';

describe('Merkle Tree Module', () => {
  const createLeaves = (count: number): Hash[] => {
    return Array.from({ length: count }, (_, i) => hash(`leaf-${i}`));
  };

  describe('buildMerkleTree', () => {
    it('should build tree from leaves', () => {
      const leaves = createLeaves(4);
      const tree = buildMerkleTree(leaves);

      expect(tree.root).toMatch(/^0x[0-9a-f]{64}$/);
      expect(tree.leaves.length).toBe(4);
      expect(tree.layers.length).toBeGreaterThan(1);
    });

    it('should pad odd number of leaves', () => {
      const leaves = createLeaves(3);
      const tree = buildMerkleTree(leaves);

      expect(tree.leaves.length).toBe(4); // Padded to even
    });

    it('should throw for empty leaves', () => {
      expect(() => buildMerkleTree([])).toThrow();
    });

    it('should handle single leaf', () => {
      const leaves = createLeaves(1);
      const tree = buildMerkleTree(leaves);

      expect(tree.root).toBeDefined();
    });
  });

  describe('generateProof', () => {
    it('should generate valid proof for leaf', () => {
      const leaves = createLeaves(8);
      const tree = buildMerkleTree(leaves);
      const proof = generateProof(tree, 3);

      expect(proof.leaf).toBe(tree.leaves[3]);
      expect(proof.index).toBe(3);
      expect(proof.root).toBe(tree.root);
      expect(proof.siblings.length).toBeGreaterThan(0);
    });

    it('should throw for out of bounds index', () => {
      const leaves = createLeaves(4);
      const tree = buildMerkleTree(leaves);

      expect(() => generateProof(tree, 10)).toThrow();
      expect(() => generateProof(tree, -1)).toThrow();
    });
  });

  describe('verifyProof', () => {
    it('should verify valid proof', () => {
      const leaves = createLeaves(8);
      const tree = buildMerkleTree(leaves);

      for (let i = 0; i < leaves.length; i++) {
        const proof = generateProof(tree, i);
        expect(verifyProof(proof)).toBe(true);
      }
    });

    it('should reject invalid proof', () => {
      const leaves = createLeaves(4);
      const tree = buildMerkleTree(leaves);
      const proof = generateProof(tree, 0);

      // Tamper with proof
      const tamperedProof = { ...proof, leaf: hash('tampered') };
      expect(verifyProof(tamperedProof)).toBe(false);
    });

    it('should reject proof with wrong root', () => {
      const leaves = createLeaves(4);
      const tree = buildMerkleTree(leaves);
      const proof = generateProof(tree, 0);

      const tamperedProof = { ...proof, root: hash('wrong-root') };
      expect(verifyProof(tamperedProof)).toBe(false);
    });
  });

  describe('getMerkleRoot', () => {
    it('should return consistent root', () => {
      const leaves = createLeaves(4);
      const root1 = getMerkleRoot(leaves);
      const root2 = getMerkleRoot(leaves);

      expect(root1).toBe(root2);
    });

    it('should return different root for different leaves', () => {
      const leaves1 = createLeaves(4);
      const leaves2 = createLeaves(5);

      const root1 = getMerkleRoot(leaves1);
      const root2 = getMerkleRoot(leaves2);

      expect(root1).not.toBe(root2);
    });
  });
});
