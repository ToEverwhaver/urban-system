import {
  Clarinet,
  Tx,
  Chain,
  Account,
  types,
} from "https://deno.land/x/clarinet@v1.7.1/index.ts";
import { assertEquals } from "https://deno.land/std@0.170.0/testing/asserts.ts";

// ============================================
// SIP-010 Compliance Tests
// ============================================

Clarinet.test({
  name: "get-name: Returns correct token name",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn("bccp-token", "get-name", [], deployer.address);
    assertEquals(result.result, '(ok "BCCP Token")');
  },
});

Clarinet.test({
  name: "get-symbol: Returns correct token symbol",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn("bccp-token", "get-symbol", [], deployer.address);
    assertEquals(result.result, '(ok "BCCP")');
  },
});

Clarinet.test({
  name: "get-decimals: Returns correct decimals",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn("bccp-token", "get-decimals", [], deployer.address);
    assertEquals(result.result, "(ok u6)");
  },
});

Clarinet.test({
  name: "get-total-supply: Returns initial supply",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn("bccp-token", "get-total-supply", [], deployer.address);
    assertEquals(result.result, "(ok u1000000000000000)");
  },
});

Clarinet.test({
  name: "get-balance: Deployer has initial supply",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn(
      "bccp-token",
      "get-balance",
      [types.principal(deployer.address)],
      deployer.address
    );
    assertEquals(result.result, "(ok u1000000000000000)");
  },
});

Clarinet.test({
  name: "get-balance: Non-holder has zero balance",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    const result = chain.callReadOnlyFn(
      "bccp-token",
      "get-balance",
      [types.principal(alice.address)],
      deployer.address
    );
    assertEquals(result.result, "(ok u0)");
  },
});

// ============================================
// Transfer Tests
// ============================================

Clarinet.test({
  name: "transfer: Successfully transfers tokens",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "transfer",
        [
          types.uint(1000000),
          types.principal(deployer.address),
          types.principal(alice.address),
          types.none(),
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const aliceBalance = chain.callReadOnlyFn(
      "bccp-token",
      "get-balance",
      [types.principal(alice.address)],
      deployer.address
    );
    assertEquals(aliceBalance.result, "(ok u1000000)");
  },
});

Clarinet.test({
  name: "transfer: Fails with insufficient balance",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "transfer",
        [
          types.uint(1000000),
          types.principal(alice.address),
          types.principal(bob.address),
          types.none(),
        ],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

Clarinet.test({
  name: "transfer: Cannot transfer zero amount",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "transfer",
        [
          types.uint(0),
          types.principal(deployer.address),
          types.principal(alice.address),
          types.none(),
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

Clarinet.test({
  name: "transfer: Cannot transfer from others without authorization",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    // Alice tries to transfer deployer's tokens
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "transfer",
        [
          types.uint(1000000),
          types.principal(deployer.address),
          types.principal(bob.address),
          types.none(),
        ],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Mint Tests
// ============================================

Clarinet.test({
  name: "mint: Owner can mint tokens",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "mint",
        [types.uint(5000000), types.principal(alice.address)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const aliceBalance = chain.callReadOnlyFn(
      "bccp-token",
      "get-balance",
      [types.principal(alice.address)],
      deployer.address
    );
    assertEquals(aliceBalance.result, "(ok u5000000)");
  },
});

Clarinet.test({
  name: "mint: Non-owner cannot mint",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "mint",
        [types.uint(5000000), types.principal(bob.address)],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Burn Tests
// ============================================

Clarinet.test({
  name: "burn: Can burn own tokens",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const initialSupply = "u1000000000000000";

    // Burn some tokens
    const block = chain.mineBlock([
      Tx.contractCall("bccp-token", "burn", [types.uint(1000000)], deployer.address),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const newSupply = chain.callReadOnlyFn("bccp-token", "get-total-supply", [], deployer.address);
    assertEquals(newSupply.result, "(ok u999999999000000)");
  },
});

Clarinet.test({
  name: "burn: Cannot burn more than balance",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall("bccp-token", "burn", [types.uint(1000000)], alice.address),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Allowance Tests
// ============================================

Clarinet.test({
  name: "set-allowance: Can set allowance",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "set-allowance",
        [types.principal(alice.address), types.uint(5000000)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const allowance = chain.callReadOnlyFn(
      "bccp-token",
      "get-allowance",
      [types.principal(deployer.address), types.principal(alice.address)],
      deployer.address
    );
    assertEquals(allowance.result, "(ok u5000000)");
  },
});

Clarinet.test({
  name: "transfer-from: Can transfer with allowance",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    // Set allowance
    chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "set-allowance",
        [types.principal(alice.address), types.uint(5000000)],
        deployer.address
      ),
    ]);

    // Alice transfers from deployer to bob
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "transfer-from",
        [types.uint(3000000), types.principal(deployer.address), types.principal(bob.address)],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const bobBalance = chain.callReadOnlyFn(
      "bccp-token",
      "get-balance",
      [types.principal(bob.address)],
      deployer.address
    );
    assertEquals(bobBalance.result, "(ok u3000000)");

    // Check allowance reduced
    const allowance = chain.callReadOnlyFn(
      "bccp-token",
      "get-allowance",
      [types.principal(deployer.address), types.principal(alice.address)],
      deployer.address
    );
    assertEquals(allowance.result, "(ok u2000000)");
  },
});

// ============================================
// Minter Authorization Tests
// ============================================

Clarinet.test({
  name: "authorize-minter: Owner can authorize minters",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const minter = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "authorize-minter",
        [types.principal(minter.address)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const isAuthorized = chain.callReadOnlyFn(
      "bccp-token",
      "is-authorized-minter",
      [types.principal(minter.address)],
      deployer.address
    );
    assertEquals(isAuthorized.result, "true");
  },
});

Clarinet.test({
  name: "revoke-minter: Owner can revoke minters",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const minter = accounts.get("wallet_1")!;

    // Authorize first
    chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "authorize-minter",
        [types.principal(minter.address)],
        deployer.address
      ),
    ]);

    // Then revoke
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-token",
        "revoke-minter",
        [types.principal(minter.address)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const isAuthorized = chain.callReadOnlyFn(
      "bccp-token",
      "is-authorized-minter",
      [types.principal(minter.address)],
      deployer.address
    );
    assertEquals(isAuthorized.result, "false");
  },
});
