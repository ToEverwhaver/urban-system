import { TX, TXState } from '../types/tx';
import { SignaturePair } from '../types/signature';
import { Address, Hash } from '../types/common';
import { recoverPublicKey, publicKeyToAddress, hashTypedData } from '../crypto/signature';
import { hashObject } from '../crypto/hash';
import { verifyProof, buildMerkleTree, generateProof } from '../crypto/merkle';
import { getBCCPDomain } from '../signature/protocol';

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

/**
 * Validate entire TX structure and signatures
 */
export function validateTX(tx: TX): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (tx.chain.length === 0) {
    errors.push('TX chain is empty');
  }

  if (tx.chain[0]?.signaturePair !== null) {
    errors.push('Initiator should not have incoming signature');
  }

  for (let i = 1; i < tx.chain.length; i++) {
    const entry = tx.chain[i];
    const prevEntry = tx.chain[i - 1];

    if (!entry.signaturePair) {
      errors.push(`Missing signature at index ${i}`);
      continue;
    }

    const result = validateSignaturePair(
      entry.signaturePair,
      prevEntry.contributor.address,
      entry.contributor.address
    );

    if (!result.valid) {
      errors.push(`Chain entry ${i}: ${result.errors.join(', ')}`);
    }
    warnings.push(...result.warnings.map(w => `Chain entry ${i}: ${w}`));
  }

  const weightResult = validateWeights(tx);
  errors.push(...weightResult.errors);
  warnings.push(...weightResult.warnings);

  return { valid: errors.length === 0, errors, warnings };
}

/**
 * Validate a signature pair
 */
export function validateSignaturePair(
  pair: SignaturePair,
  expectedFrom: Address,
  expectedTo: Address
): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    // Use EIP-712 typed data hash (same as signing)
    const outboundMessage = {
      type: pair.outbound.type,
      from: pair.outbound.from,
      to: pair.outbound.to,
      contentHash: pair.outbound.contentHash,
      previousHash: pair.outbound.previousHash,
      role: pair.outbound.role,
      timestamp: pair.outbound.timestamp
    };
    const outboundHash = hashTypedData(getBCCPDomain(), outboundMessage);

    const recoveredPubKey = recoverPublicKey(outboundHash, pair.outbound.signature);
    const recoveredAddress = publicKeyToAddress(recoveredPubKey);

    if (recoveredAddress !== expectedFrom) {
      errors.push(`Outbound not from expected: ${expectedFrom}`);
    }
  } catch (e) {
    errors.push(`Invalid outbound signature: ${e}`);
  }

  try {
    // Use EIP-712 typed data hash (same as signing)
    const counterMessage = {
      type: pair.counter.type,
      from: pair.counter.from,
      originalSigner: pair.counter.originalSigner,
      outboundSignatureHash: pair.counter.outboundSignatureHash,
      responsibilityAccepted: pair.counter.responsibilityAccepted,
      timestamp: pair.counter.timestamp
    };
    const counterHash = hashTypedData(getBCCPDomain(), counterMessage);

    const recoveredPubKey = recoverPublicKey(counterHash, pair.counter.signature);
    const recoveredAddress = publicKeyToAddress(recoveredPubKey);

    if (recoveredAddress !== expectedTo) {
      errors.push(`Counter not from expected: ${expectedTo}`);
    }
  } catch (e) {
    errors.push(`Invalid counter signature: ${e}`);
  }

  if (!pair.counter.responsibilityAccepted) {
    warnings.push('Receiver did not accept responsibility');
  }

  return { valid: errors.length === 0, errors, warnings };
}

/**
 * Validate weights configuration
 */
export function validateWeights(tx: TX): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  for (const entry of tx.chain) {
    if (!tx.weights.has(entry.contributor.address)) {
      errors.push(`Missing weight for: ${entry.contributor.address}`);
    }
  }

  const total = Array.from(tx.weights.values()).reduce((a, b) => a + b, 0);
  if (total !== 10000) {
    errors.push(`Weights sum to ${total}, expected 10000`);
  }

  for (const [address, weight] of tx.weights) {
    if (weight === 0) {
      warnings.push(`${address} has 0% weight`);
    }
  }

  return { valid: errors.length === 0, errors, warnings };
}

/**
 * Validate TX state transition
 */
export function validateStateTransition(
  currentState: TXState,
  newState: TXState
): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  const validTransitions: Record<TXState, TXState[]> = {
    [TXState.Draft]: [TXState.Open, TXState.Cancelled],
    [TXState.Open]: [TXState.PendingClosure, TXState.Disputed, TXState.Cancelled],
    [TXState.PendingClosure]: [TXState.Closed, TXState.Disputed],
    [TXState.Closed]: [],
    [TXState.Disputed]: [TXState.Open, TXState.Cancelled],
    [TXState.Cancelled]: []
  };

  if (!validTransitions[currentState].includes(newState)) {
    errors.push(`Invalid transition from ${currentState} to ${newState}`);
  }

  return { valid: errors.length === 0, errors, warnings };
}

/**
 * Validate chain integrity using Merkle proof
 */
export function validateChainIntegrity(tx: TX, expectedRoot: Hash): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  const leaves = tx.chain.map(entry =>
    hashObject({
      address: entry.contributor.address,
      role: entry.contributor.role,
      contentHash: entry.contentHash
    })
  );

  const tree = buildMerkleTree(leaves);

  if (tree.root !== expectedRoot) {
    errors.push('Merkle root mismatch');
  }

  for (let i = 0; i < leaves.length; i++) {
    const proof = generateProof(tree, i);
    if (!verifyProof(proof)) {
      errors.push(`Invalid Merkle proof for entry ${i}`);
    }
  }

  return { valid: errors.length === 0, errors, warnings };
}

/**
 * Validate TX for closure
 */
export function validateForClosure(tx: TX): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (tx.state !== TXState.Open) {
    errors.push(`TX must be OPEN for closure, current: ${tx.state}`);
  }

  if (tx.chain.length < 2) {
    errors.push('TX chain must have at least 2 contributors');
  }

  const txValidation = validateTX(tx);
  errors.push(...txValidation.errors);
  warnings.push(...txValidation.warnings);

  return { valid: errors.length === 0, errors, warnings };
}
