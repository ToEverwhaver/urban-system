import { SlashingEvent, SlashReason, RelayNode, NodeStatus } from '../types/node';
import { Hash, Satoshi, Timestamp, Address } from '../types/common';
import { hash } from '../crypto/hash';
import { getNode, getAllNodes } from './node';
import { PROTOCOL_CONSTANTS } from '../constants';

const slashingEvents: SlashingEvent[] = [];

/**
 * Create a slashing event
 */
export function createSlashingEvent(
  nodeId: Hash,
  reason: SlashReason,
  evidence?: Hash
): SlashingEvent {
  const node = getNode(nodeId);
  if (!node) throw new Error('Node not found');

  const now = Date.now() as Timestamp;
  const rate = PROTOCOL_CONSTANTS.SLASHING_RATES[reason];
  const amount = BigInt(Math.floor(Number(node.stake) * rate)) as Satoshi;

  const event: SlashingEvent = {
    id: hash(`slash:${nodeId}:${now}`) as Hash,
    nodeId,
    reason,
    evidence,
    amount,
    timestamp: now,
    appealed: false,
    appealDeadline: (now + PROTOCOL_CONSTANTS.APPEAL_WINDOW_MS) as Timestamp,
    resolved: false
  };

  slashingEvents.push(event);
  return event;
}

/**
 * Execute slashing on a node
 */
export function executeSlashing(eventId: Hash): {
  success: boolean;
  node?: RelayNode;
  slashedAmount?: Satoshi;
  error?: string;
} {
  const event = slashingEvents.find(e => e.id === eventId);
  if (!event) {
    return { success: false, error: 'Slashing event not found' };
  }

  if (event.resolved) {
    return { success: false, error: 'Event already resolved' };
  }

  if (event.appealed && Date.now() < event.appealDeadline) {
    return { success: false, error: 'Appeal pending' };
  }

  const node = getNode(event.nodeId);
  if (!node) {
    return { success: false, error: 'Node not found' };
  }

  const newStake = (node.stake - event.amount) as Satoshi;
  node.stake = newStake > 0n ? newStake : (0n as Satoshi);
  node.status = NodeStatus.Slashed;

  event.resolved = true;
  event.resolution = 'UPHELD';

  return {
    success: true,
    node,
    slashedAmount: event.amount
  };
}

/**
 * File an appeal against slashing
 */
export function fileAppeal(eventId: Hash): SlashingEvent {
  const event = slashingEvents.find(e => e.id === eventId);
  if (!event) throw new Error('Slashing event not found');

  if (event.resolved) {
    throw new Error('Cannot appeal resolved event');
  }

  if (Date.now() > event.appealDeadline) {
    throw new Error('Appeal deadline passed');
  }

  event.appealed = true;
  return event;
}

/**
 * Resolve an appeal
 */
export function resolveAppeal(
  eventId: Hash,
  upheld: boolean
): SlashingEvent {
  const event = slashingEvents.find(e => e.id === eventId);
  if (!event) throw new Error('Slashing event not found');

  if (!event.appealed) {
    throw new Error('No appeal filed');
  }

  if (event.resolved) {
    throw new Error('Already resolved');
  }

  event.resolved = true;
  event.resolution = upheld ? 'UPHELD' : 'REVERSED';

  if (upheld) {
    const node = getNode(event.nodeId);
    if (node) {
      node.stake = ((node.stake - event.amount) as Satoshi);
      if (node.stake < 0n) node.stake = 0n as Satoshi;
      node.status = NodeStatus.Slashed;
    }
  }

  return event;
}

/**
 * Get slashing events for a node
 */
export function getSlashingEvents(nodeId: Hash): SlashingEvent[] {
  return slashingEvents.filter(e => e.nodeId === nodeId);
}

/**
 * Get pending slashing events
 */
export function getPendingSlashingEvents(): SlashingEvent[] {
  return slashingEvents.filter(e => !e.resolved);
}

/**
 * Get appealed events
 */
export function getAppealedEvents(): SlashingEvent[] {
  return slashingEvents.filter(e => e.appealed && !e.resolved);
}

/**
 * Calculate total slashed amount
 */
export function getTotalSlashed(): Satoshi {
  return slashingEvents
    .filter(e => e.resolved && e.resolution === 'UPHELD')
    .reduce((sum, e) => (sum + e.amount) as Satoshi, 0n as Satoshi);
}

/**
 * Get slashing statistics
 */
export function getSlashingStats(): {
  total: number;
  pending: number;
  upheld: number;
  reversed: number;
  totalAmount: Satoshi;
  byReason: Record<SlashReason, number>;
} {
  const all = slashingEvents;
  const byReason = {
    [SlashReason.ExtendedDowntime]: 0,
    [SlashReason.DataManipulation]: 0,
    [SlashReason.MaliciousActivity]: 0,
    [SlashReason.ProtocolViolation]: 0
  };

  for (const e of all) {
    byReason[e.reason]++;
  }

  return {
    total: all.length,
    pending: all.filter(e => !e.resolved).length,
    upheld: all.filter(e => e.resolution === 'UPHELD').length,
    reversed: all.filter(e => e.resolution === 'REVERSED').length,
    totalAmount: getTotalSlashed(),
    byReason
  };
}

/**
 * Check if node is at risk of slashing
 */
export function isAtRisk(nodeId: Hash): {
  atRisk: boolean;
  reasons: SlashReason[];
} {
  const node = getNode(nodeId);
  if (!node) return { atRisk: false, reasons: [] };

  const reasons: SlashReason[] = [];

  const hoursSinceHeartbeat = (Date.now() - node.lastHeartbeat) / (60 * 60 * 1000);
  if (hoursSinceHeartbeat > 24) {
    reasons.push(SlashReason.ExtendedDowntime);
  }

  if (node.honestyScore < 50) {
    reasons.push(SlashReason.DataManipulation);
  }

  if (node.score < 20) {
    reasons.push(SlashReason.ProtocolViolation);
  }

  return {
    atRisk: reasons.length > 0,
    reasons
  };
}

/**
 * Clear slashing events (for testing)
 */
export function clearSlashingEvents(): void {
  slashingEvents.length = 0;
}
