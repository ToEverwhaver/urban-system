/**
 * Integration Test: Full BCCP Flow (A→B→C→D→S)
 *
 * This test validates the complete lifecycle of a TX:
 * 1. Create TX with Initiator (A)
 * 2. Add Receiver (B) with dual signature
 * 3. Add Producer (C) with dual signature
 * 4. Add Editor (D) with dual signature
 * 5. Validate the TX chain
 * 6. Close TX with Sponsor (S)
 * 7. Verify token issuance
 * 8. Verify reward distribution
 */

import {
  createTX,
  addContributor,
  setWeights,
  getContributor,
  isContributor,
  serializeTX,
  deserializeTX
} from '../../src/tx/chain';
import { validateTX, validateForClosure, validateWeights } from '../../src/tx/validator';
import { createSignaturePair } from '../../src/signature/protocol';
import { verifySignaturePair, verifySignatureChain } from '../../src/signature/verifier';
import { processClosure, getClosureSummary, verifyClosureComplete } from '../../src/closure/processor';
import { distributeRewards, previewDistribution, calculateProtocolFee } from '../../src/closure/distribution';
import { mintTokens, getBalance, getTotalSupply, clearLedger } from '../../src/token/minter';
import { depositBTC, getReserveState, resetReserve } from '../../src/token/reserve';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { hash, hashObject } from '../../src/crypto/hash';
import { buildMerkleTree, generateProof, verifyProof } from '../../src/crypto/merkle';
import { Role } from '../../src/types/contributor';
import { TXState } from '../../src/types/tx';
import { Hash, Address, BasisPoints, Timestamp, Satoshi, UUID, HexString } from '../../src/types/common';

describe('Full BCCP Flow Integration Test', () => {
  // Generate key pairs for all participants
  const initiatorKeys = generateKeyPair();  // A
  const receiverKeys = generateKeyPair();   // B
  const producerKeys = generateKeyPair();   // C
  const editorKeys = generateKeyPair();     // D
  const sponsorKeys = generateKeyPair();    // S

  const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);
  const producerAddress = privateKeyToAddress(producerKeys.privateKey);
  const editorAddress = privateKeyToAddress(editorKeys.privateKey);
  const sponsorAddress = privateKeyToAddress(sponsorKeys.privateKey);

  const assetHash = hash('test-content-asset') as Hash;

  beforeEach(() => {
    clearLedger();
    resetReserve();
  });

  it('should complete A→B→C→D→S flow', async () => {
    // ========================================
    // Step 1: Create TX with Initiator (A)
    // ========================================
    let tx = createTX({
      assetHash,
      assetType: 'video',
      assetMetadata: { title: 'Test Content', format: 'mp4' },
      initiator: initiatorAddress
    });

    expect(tx.state).toBe(TXState.Draft);
    expect(tx.chain.length).toBe(1);
    expect(tx.chain[0].contributor.role).toBe(Role.Initiator);
    expect(tx.chain[0].signaturePair).toBeNull(); // Initiator has no signature pair

    // ========================================
    // Step 2: Add Receiver (B) with A→B signature
    // ========================================
    const contentHashB = hash('receiver-content') as Hash;
    const sigPairAB = createSignaturePair(
      { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
      { address: receiverAddress, privateKey: receiverKeys.privateKey },
      contentHashB,
      assetHash,
      Role.Receiver
    );

    // Verify signature pair
    expect(verifySignaturePair(sigPairAB, initiatorAddress, receiverAddress).valid).toBe(true);

    tx = addContributor(
      tx,
      {
        address: receiverAddress,
        role: Role.Receiver,
        weight: 2000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPairAB,
      contentHashB
    );

    expect(tx.state).toBe(TXState.Open);
    expect(tx.chain.length).toBe(2);

    // ========================================
    // Step 3: Add Producer (C) with B→C signature
    // ========================================
    const contentHashC = hash('producer-content') as Hash;
    const sigPairBC = createSignaturePair(
      { address: receiverAddress, privateKey: receiverKeys.privateKey },
      { address: producerAddress, privateKey: producerKeys.privateKey },
      contentHashC,
      contentHashB,
      Role.Producer
    );

    expect(verifySignaturePair(sigPairBC, receiverAddress, producerAddress).valid).toBe(true);

    tx = addContributor(
      tx,
      {
        address: producerAddress,
        role: Role.Producer,
        weight: 3000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPairBC,
      contentHashC
    );

    expect(tx.chain.length).toBe(3);

    // ========================================
    // Step 4: Add Editor (D) with C→D signature
    // ========================================
    const contentHashD = hash('editor-content') as Hash;
    const sigPairCD = createSignaturePair(
      { address: producerAddress, privateKey: producerKeys.privateKey },
      { address: editorAddress, privateKey: editorKeys.privateKey },
      contentHashD,
      contentHashC,
      Role.Editor
    );

    expect(verifySignaturePair(sigPairCD, producerAddress, editorAddress).valid).toBe(true);

    tx = addContributor(
      tx,
      {
        address: editorAddress,
        role: Role.Editor,
        weight: 2000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPairCD,
      contentHashD
    );

    expect(tx.chain.length).toBe(4);

    // ========================================
    // Step 5: Validate TX chain
    // ========================================

    // Set final weights (must sum to 10000)
    const weights = new Map<Address, BasisPoints>();
    weights.set(initiatorAddress, 3000 as BasisPoints);  // A: 30%
    weights.set(receiverAddress, 2000 as BasisPoints);   // B: 20%
    weights.set(producerAddress, 3000 as BasisPoints);   // C: 30%
    weights.set(editorAddress, 2000 as BasisPoints);     // D: 20%
    tx = setWeights(tx, weights);

    // Validate TX
    const txValidation = validateTX(tx);
    expect(txValidation.valid).toBe(true);
    expect(txValidation.errors).toHaveLength(0);

    // Validate weights
    const weightValidation = validateWeights(tx);
    expect(weightValidation.valid).toBe(true);

    // Validate for closure
    const closureValidation = validateForClosure(tx);
    expect(closureValidation.valid).toBe(true);

    // Verify Merkle root (must use same hashing as chain module)
    expect(tx.chainMerkleRoot).toBeDefined();
    const leaves = tx.chain.map(entry =>
      hashObject({
        address: entry.contributor.address,
        role: entry.contributor.role,
        contentHash: entry.contentHash
      })
    );
    const tree = buildMerkleTree(leaves);
    expect(tree.root).toBe(tx.chainMerkleRoot);

    // ========================================
    // Step 6: Close TX with Sponsor (S)
    // ========================================
    const paymentAmount = 10000000n as Satoshi; // 0.1 BTC

    const closureRequest = {
      txId: tx.id,
      sponsor: sponsorAddress,
      sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as HexString, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as HexString, v: 27 },
      paymentAmount
    };

    const closureResult = await processClosure(tx, closureRequest);

    expect(closureResult.success).toBe(true);
    expect(closureResult.tx).toBeDefined();
    expect(closureResult.tx!.state).toBe(TXState.Closed);
    expect(closureResult.distribution).toBeDefined();

    const closedTX = closureResult.tx!;

    // Verify closure is complete
    expect(verifyClosureComplete(closedTX)).toBe(true);

    // Get closure summary
    const summary = getClosureSummary(closedTX);
    expect(summary.isClosed).toBe(true);
    expect(summary.sponsor).toBe(sponsorAddress);
    expect(summary.paymentAmount).toBe(paymentAmount);
    expect(summary.contributorCount).toBe(4);

    // ========================================
    // Step 7: Verify token issuance
    // ========================================
    const distribution = closureResult.distribution!;

    // Mint tokens based on distribution
    const issuance = await mintTokens(closedTX.id, distribution);

    expect(issuance.recipients.length).toBe(4);
    expect(issuance.amount).toBeGreaterThan(0n);

    // Verify all contributors received tokens
    expect(getBalance(initiatorAddress)).toBeGreaterThan(0n);
    expect(getBalance(receiverAddress)).toBeGreaterThan(0n);
    expect(getBalance(producerAddress)).toBeGreaterThan(0n);
    expect(getBalance(editorAddress)).toBeGreaterThan(0n);

    // ========================================
    // Step 8: Verify reward distribution
    // ========================================

    // Check distribution proportions match weights
    const initiatorDist = distribution.find(d => d.contributor === initiatorAddress)!;
    const receiverDist = distribution.find(d => d.contributor === receiverAddress)!;
    const producerDist = distribution.find(d => d.contributor === producerAddress)!;
    const editorDist = distribution.find(d => d.contributor === editorAddress)!;

    // Initiator (30%) should have 1.5x Receiver (20%)
    const initiatorRatio = Number(initiatorDist.btcAmount) / Number(receiverDist.btcAmount);
    expect(initiatorRatio).toBeCloseTo(1.5, 1);

    // Producer (30%) should have 1.5x Editor (20%)
    const producerRatio = Number(producerDist.btcAmount) / Number(editorDist.btcAmount);
    expect(producerRatio).toBeCloseTo(1.5, 1);

    // Verify 80/20 BTC/Token split
    const totalBTC = distribution.reduce((sum, d) => sum + d.btcAmount, 0n);
    const protocolFee = calculateProtocolFee(paymentAmount);
    const distributable = paymentAmount - protocolFee;

    // BTC should be ~80% of distributable
    const btcRatio = Number(totalBTC) / Number(distributable);
    expect(btcRatio).toBeCloseTo(0.8, 1);

    // ========================================
    // Step 9: Verify serialization
    // ========================================
    const serialized = serializeTX(closedTX);
    const deserialized = deserializeTX(serialized);

    expect(deserialized.id).toBe(closedTX.id);
    expect(deserialized.state).toBe(TXState.Closed);
    expect(deserialized.chain.length).toBe(4);
    expect(deserialized.closure).toBeDefined();
  });

  it('should handle token forfeit decisions', async () => {
    // Create and close a TX
    let tx = createTX({
      assetHash,
      assetType: 'test',
      initiator: initiatorAddress
    });

    const contentHash = hash('content') as Hash;
    const sigPair = createSignaturePair(
      { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
      { address: receiverAddress, privateKey: receiverKeys.privateKey },
      contentHash,
      assetHash,
      Role.Receiver
    );

    tx = addContributor(
      tx,
      {
        address: receiverAddress,
        role: Role.Receiver,
        weight: 4000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPair,
      contentHash
    );

    const weights = new Map<Address, BasisPoints>();
    weights.set(initiatorAddress, 6000 as BasisPoints);
    weights.set(receiverAddress, 4000 as BasisPoints);
    tx = setWeights(tx, weights);

    // Close with token decisions (receiver forfeits)
    const closureResult = await processClosure(
      tx,
      {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as HexString, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as HexString, v: 27 },
        paymentAmount: 1000000n as Satoshi
      },
      [
        { contributor: initiatorAddress, accept: true },
        { contributor: receiverAddress, accept: false }
      ]
    );

    expect(closureResult.success).toBe(true);

    const receiverDist = closureResult.distribution!.find(d => d.contributor === receiverAddress)!;
    expect(receiverDist.tokenAccepted).toBe(false);
    expect(receiverDist.forfeitedAmount).toBe(receiverDist.tokenAmount);
  });

  it('should validate chain integrity with Merkle proofs', async () => {
    let tx = createTX({
      assetHash,
      assetType: 'test',
      initiator: initiatorAddress
    });

    const contentHash = hash('content') as Hash;
    const sigPair = createSignaturePair(
      { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
      { address: receiverAddress, privateKey: receiverKeys.privateKey },
      contentHash,
      assetHash,
      Role.Receiver
    );

    tx = addContributor(
      tx,
      {
        address: receiverAddress,
        role: Role.Receiver,
        weight: 4000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPair,
      contentHash
    );

    // Build Merkle tree and verify proofs
    const leaves = tx.chain.map(entry => hash(JSON.stringify(entry)) as Hash);
    const tree = buildMerkleTree(leaves);

    for (let i = 0; i < leaves.length; i++) {
      const proof = generateProof(tree, i);
      expect(verifyProof(proof)).toBe(true);
    }
  });

  it('should preview distribution before closure', () => {
    let tx = createTX({
      assetHash,
      assetType: 'test',
      initiator: initiatorAddress
    });

    const contentHash = hash('content') as Hash;
    const sigPair = createSignaturePair(
      { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
      { address: receiverAddress, privateKey: receiverKeys.privateKey },
      contentHash,
      assetHash,
      Role.Receiver
    );

    tx = addContributor(
      tx,
      {
        address: receiverAddress,
        role: Role.Receiver,
        weight: 4000 as BasisPoints,
        joinedAt: Date.now() as Timestamp
      },
      sigPair,
      contentHash
    );

    const weights = new Map<Address, BasisPoints>();
    weights.set(initiatorAddress, 6000 as BasisPoints);
    weights.set(receiverAddress, 4000 as BasisPoints);
    tx = setWeights(tx, weights);

    const payment = 10000000n as Satoshi;
    const preview = previewDistribution(tx, payment);

    expect(preview.protocolFee).toBeGreaterThan(0n);
    expect(preview.totalBTC).toBeGreaterThan(0n);
    expect(preview.totalTokens).toBeGreaterThan(0n);
    expect(preview.distributions.length).toBe(2);

    // Verify weight proportions in preview
    const initiatorPreview = preview.distributions.find(d => d.address === initiatorAddress)!;
    const receiverPreview = preview.distributions.find(d => d.address === receiverAddress)!;

    expect(initiatorPreview.weight).toBe(6000);
    expect(receiverPreview.weight).toBe(4000);
  });

  it('should reject closure of invalid TX', async () => {
    // Create TX but don't set weights properly
    const tx = createTX({
      assetHash,
      assetType: 'test',
      initiator: initiatorAddress
    });

    const closureResult = await processClosure(
      tx,
      {
        txId: tx.id,
        sponsor: sponsorAddress,
        sponsorSignature: { r: '0x0000000000000000000000000000000000000000000000000000000000000001' as HexString, s: '0x0000000000000000000000000000000000000000000000000000000000000002' as HexString, v: 27 },
        paymentAmount: 1000000n as Satoshi
      }
    );

    expect(closureResult.success).toBe(false);
    expect(closureResult.error).toBeDefined();
  });
});
