// Hash utilities
export {
  hash,
  hashMultiple,
  hashObject,
  verifyHash,
  createHashChain,
  hashWithDomain,
  contentId
} from './hash';

// Merkle tree
export {
  MerkleTree,
  MerkleProof,
  buildMerkleTree,
  generateProof,
  verifyProof,
  getMerkleRoot,
  generateMultiProof
} from './merkle';

// ECDSA signature operations
export {
  generateKeyPair,
  publicKeyToAddress,
  privateKeyToAddress,
  sign,
  verify,
  recoverPublicKey,
  recoverAddress,
  hashTypedData,
  signTypedData,
  verifyTypedData,
  signMessage,
  verifyMessage
} from './signature';

// UUID v7
export {
  generateUUID,
  extractTimestamp,
  isValidUUID,
  compareUUIDs,
  sortUUIDs,
  isWithinTimeWindow,
  generateSequentialUUIDs
} from './uuid';
