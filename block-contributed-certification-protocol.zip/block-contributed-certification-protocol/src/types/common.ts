// Hexadecimal string (0x prefixed)
export type HexString = `0x${string}`;

// 32-byte hash
export type Hash = HexString & { readonly __brand: 'Hash' };

// 20-byte address
export type Address = HexString & { readonly __brand: 'Address' };

// UUID v7
export type UUID = string & { readonly __brand: 'UUID' };

// Unix timestamp (milliseconds)
export type Timestamp = number & { readonly __brand: 'Timestamp' };

// Satoshi (1 BTC = 100,000,000)
export type Satoshi = bigint & { readonly __brand: 'Satoshi' };

// Token amount (18 decimals)
export type TokenAmount = bigint & { readonly __brand: 'TokenAmount' };

// Basis points (0-10000 = 0%-100%)
export type BasisPoints = number & { readonly __brand: 'BasisPoints' };

// Type guards and converters
export function toHash(hex: string): Hash {
  if (!/^0x[0-9a-f]{64}$/i.test(hex)) {
    throw new Error('Invalid hash format');
  }
  return hex.toLowerCase() as Hash;
}

export function toAddress(hex: string): Address {
  if (!/^0x[0-9a-f]{40}$/i.test(hex)) {
    throw new Error('Invalid address format');
  }
  return hex.toLowerCase() as Address;
}

export function toTimestamp(ms: number): Timestamp {
  return ms as Timestamp;
}

export function toSatoshi(btc: number): Satoshi {
  return BigInt(Math.floor(btc * 100_000_000)) as Satoshi;
}

export function toTokenAmount(amount: number, decimals: number = 18): TokenAmount {
  return BigInt(Math.floor(amount * 10 ** decimals)) as TokenAmount;
}

export function toBasisPoints(percentage: number): BasisPoints {
  if (percentage < 0 || percentage > 100) {
    throw new Error('Percentage must be 0-100');
  }
  return Math.floor(percentage * 100) as BasisPoints;
}

export function isHash(value: string): value is Hash {
  return /^0x[0-9a-f]{64}$/i.test(value);
}

export function isAddress(value: string): value is Address {
  return /^0x[0-9a-f]{40}$/i.test(value);
}

export function satoshiToBTC(satoshi: Satoshi): number {
  return Number(satoshi) / 100_000_000;
}

export function tokenToNumber(amount: TokenAmount, decimals: number = 18): number {
  return Number(amount) / 10 ** decimals;
}

export function basisPointsToPercentage(bp: BasisPoints): number {
  return bp / 100;
}
