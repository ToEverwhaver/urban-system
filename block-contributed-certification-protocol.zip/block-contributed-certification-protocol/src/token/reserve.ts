import { ReserveState, ForfeitRecord, ForfeitAction } from '../types/token';
import { Hash, Satoshi, TokenAmount, Timestamp, Address, UUID } from '../types/common';
import { hash } from '../crypto/hash';
import { getTotalSupply } from './minter';
import { PROTOCOL_CONSTANTS } from '../constants';

let reserveState: ReserveState = {
  totalBTC: 0n as Satoshi,
  totalTokenSupply: 0n as TokenAmount,
  circulatingSupply: 0n as TokenAmount,
  forfeitPool: 0n as TokenAmount,
  floorPrice: 0n as Satoshi,
  lastUpdated: Date.now() as Timestamp
};

const forfeitRecords: ForfeitRecord[] = [];

/**
 * Deposit BTC to reserve
 */
export function depositBTC(amount: Satoshi, _reference?: string): ReserveState {
  reserveState = {
    ...reserveState,
    totalBTC: (reserveState.totalBTC + amount) as Satoshi,
    lastUpdated: Date.now() as Timestamp
  };
  updateFloorPrice();
  return reserveState;
}

/**
 * Withdraw BTC from reserve
 */
export function withdrawBTC(amount: Satoshi): ReserveState | null {
  if (reserveState.totalBTC < amount) {
    return null;
  }

  reserveState = {
    ...reserveState,
    totalBTC: (reserveState.totalBTC - amount) as Satoshi,
    lastUpdated: Date.now() as Timestamp
  };
  updateFloorPrice();
  return reserveState;
}

/**
 * Record a forfeit event
 */
export function recordForfeit(
  contributor: Address,
  amount: TokenAmount,
  txId: UUID
): ForfeitRecord {
  const now = Date.now() as Timestamp;
  const record: ForfeitRecord = {
    id: hash(`forfeit:${contributor}:${txId}:${now}`) as Hash,
    contributor,
    amount,
    txId,
    timestamp: now,
    processed: false
  };

  forfeitRecords.push(record);
  reserveState = {
    ...reserveState,
    forfeitPool: (reserveState.forfeitPool + amount) as TokenAmount,
    lastUpdated: now
  };

  return record;
}

/**
 * Process accumulated forfeits
 */
export async function processForfeits(
  action: ForfeitAction
): Promise<TokenAmount> {
  const toProcess = reserveState.forfeitPool;
  if (toProcess === 0n) return 0n as TokenAmount;

  const now = Date.now() as Timestamp;

  if (action === 'BURN_AND_BUY') {
    const btcValue = calculateTokenBTCValue(toProcess);
    reserveState = {
      ...reserveState,
      totalBTC: (reserveState.totalBTC + btcValue) as Satoshi,
      forfeitPool: 0n as TokenAmount,
      circulatingSupply: (reserveState.circulatingSupply - toProcess) as TokenAmount,
      lastUpdated: now
    };
  } else {
    reserveState = {
      ...reserveState,
      forfeitPool: 0n as TokenAmount,
      lastUpdated: now
    };
  }

  for (const r of forfeitRecords) {
    if (!r.processed) {
      r.processed = true;
      r.processedAt = now;
      r.action = action;
    }
  }

  updateFloorPrice();
  return toProcess;
}

/**
 * Update floor price based on current state
 */
function updateFloorPrice(): void {
  const supply = reserveState.circulatingSupply || getTotalSupply();
  reserveState.floorPrice = supply === 0n
    ? (0n as Satoshi)
    : (((reserveState.totalBTC * BigInt(10 ** 18)) / supply) as Satoshi);
}

/**
 * Calculate BTC value of tokens
 */
export function calculateTokenBTCValue(tokens: TokenAmount): Satoshi {
  const floorValue = (tokens * reserveState.floorPrice) / BigInt(10 ** 18);
  const rateValue = (tokens * PROTOCOL_CONSTANTS.TOKEN_RATE) / BigInt(10 ** 18);
  return (floorValue > rateValue ? floorValue : rateValue) as Satoshi;
}

/**
 * Get current reserve state
 */
export function getReserveState(): ReserveState {
  reserveState.circulatingSupply = getTotalSupply();
  reserveState.totalTokenSupply = getTotalSupply();
  updateFloorPrice();
  return { ...reserveState };
}

/**
 * Get floor price
 */
export function getFloorPrice(): Satoshi {
  updateFloorPrice();
  return reserveState.floorPrice;
}

/**
 * Get unprocessed forfeits
 */
export function getUnprocessedForfeits(): ForfeitRecord[] {
  return forfeitRecords.filter(r => !r.processed);
}

/**
 * Get all forfeit records
 */
export function getAllForfeits(): ForfeitRecord[] {
  return [...forfeitRecords];
}

/**
 * Get forfeits by contributor
 */
export function getForfeitsByContributor(contributor: Address): ForfeitRecord[] {
  return forfeitRecords.filter(r => r.contributor === contributor);
}

/**
 * Get reserve ratio
 */
export function getReserveRatio(marketPrice: Satoshi): number {
  const supply = getTotalSupply();
  if (supply === 0n || marketPrice === 0n) return 0;
  const marketCap = (supply * marketPrice) / BigInt(10 ** 18);
  if (marketCap === 0n) return 0;
  return Number(reserveState.totalBTC) / Number(marketCap);
}

/**
 * Reset reserve state (for testing)
 */
export function resetReserve(): void {
  reserveState = {
    totalBTC: 0n as Satoshi,
    totalTokenSupply: 0n as TokenAmount,
    circulatingSupply: 0n as TokenAmount,
    forfeitPool: 0n as TokenAmount,
    floorPrice: 0n as Satoshi,
    lastUpdated: Date.now() as Timestamp
  };
  forfeitRecords.length = 0;
}
