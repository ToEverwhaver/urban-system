import { TX, DistributionResult } from '../types/tx';
import { Role } from '../types/contributor';
import { Address, Satoshi, TokenAmount, BasisPoints } from '../types/common';
import { PROTOCOL_CONSTANTS } from '../constants';

/**
 * Calculate reward distribution for all contributors
 */
export async function distributeRewards(
  tx: TX,
  totalPayment: Satoshi
): Promise<DistributionResult[]> {
  const results: DistributionResult[] = [];

  const protocolFee = calculateProtocolFee(totalPayment);
  const distributable = (totalPayment - protocolFee) as Satoshi;

  const btcRatio = PROTOCOL_CONSTANTS.BTC_DISTRIBUTION_RATIO;
  const tokenRatio = PROTOCOL_CONSTANTS.TOKEN_DISTRIBUTION_RATIO;

  const totalBTC = BigInt(Math.floor(Number(distributable) * btcRatio)) as Satoshi;
  const totalTokenValue = BigInt(Math.floor(Number(distributable) * tokenRatio)) as Satoshi;

  const tokenRate = PROTOCOL_CONSTANTS.TOKEN_RATE;
  const totalTokens = ((totalTokenValue * BigInt(10 ** 18)) / tokenRate) as TokenAmount;

  for (const entry of tx.chain) {
    const weight = tx.weights.get(entry.contributor.address) ?? 0;
    const ratio = weight / 10000;

    results.push({
      contributor: entry.contributor.address,
      role: entry.contributor.role,
      weight: weight as BasisPoints,
      btcAmount: BigInt(Math.floor(Number(totalBTC) * ratio)) as Satoshi,
      tokenAmount: BigInt(Math.floor(Number(totalTokens) * ratio)) as TokenAmount,
      tokenAccepted: true
    });
  }

  return results;
}

/**
 * Calculate protocol fee from payment
 */
export function calculateProtocolFee(total: Satoshi): Satoshi {
  const rate = PROTOCOL_CONSTANTS.PROTOCOL_FEE_RATE;
  return BigInt(Math.floor(Number(total) * rate)) as Satoshi;
}

/**
 * Process token accept/forfeit decisions
 */
export function processTokenDecisions(
  distribution: DistributionResult[],
  decisions: Map<Address, boolean>
): DistributionResult[] {
  return distribution.map(result => {
    const accepted = decisions.get(result.contributor) ?? true;
    return accepted ? result : {
      ...result,
      tokenAccepted: false,
      forfeitedAmount: result.tokenAmount
    };
  });
}

/**
 * Calculate total forfeited tokens
 */
export function getTotalForfeited(distribution: DistributionResult[]): TokenAmount {
  return distribution.reduce((total, r) => {
    return r.forfeitedAmount
      ? ((total + r.forfeitedAmount) as TokenAmount)
      : total;
  }, 0n as TokenAmount);
}

/**
 * Preview distribution before closure
 */
export function previewDistribution(tx: TX, payment: Satoshi): {
  protocolFee: Satoshi;
  totalBTC: Satoshi;
  totalTokens: TokenAmount;
  distributions: Array<{
    address: Address;
    role: Role;
    weight: number;
    btcAmount: Satoshi;
    tokenAmount: TokenAmount;
  }>;
} {
  const protocolFee = calculateProtocolFee(payment);
  const distributable = (payment - protocolFee) as Satoshi;

  const totalBTC = BigInt(
    Math.floor(Number(distributable) * PROTOCOL_CONSTANTS.BTC_DISTRIBUTION_RATIO)
  ) as Satoshi;

  const totalTokenValue = BigInt(
    Math.floor(Number(distributable) * PROTOCOL_CONSTANTS.TOKEN_DISTRIBUTION_RATIO)
  ) as Satoshi;

  const totalTokens = ((totalTokenValue * BigInt(10 ** 18)) / PROTOCOL_CONSTANTS.TOKEN_RATE) as TokenAmount;

  const distributions = tx.chain.map(entry => {
    const weight = tx.weights.get(entry.contributor.address) ?? 0;
    const ratio = weight / 10000;
    return {
      address: entry.contributor.address,
      role: entry.contributor.role,
      weight,
      btcAmount: BigInt(Math.floor(Number(totalBTC) * ratio)) as Satoshi,
      tokenAmount: BigInt(Math.floor(Number(totalTokens) * ratio)) as TokenAmount
    };
  });

  return { protocolFee, totalBTC, totalTokens, distributions };
}

/**
 * Calculate individual contributor share
 */
export function calculateContributorShare(
  payment: Satoshi,
  weight: BasisPoints
): { btc: Satoshi; tokens: TokenAmount } {
  const protocolFee = calculateProtocolFee(payment);
  const distributable = (payment - protocolFee) as Satoshi;
  const ratio = weight / 10000;

  const btcPool = BigInt(
    Math.floor(Number(distributable) * PROTOCOL_CONSTANTS.BTC_DISTRIBUTION_RATIO)
  );
  const tokenPool = BigInt(
    Math.floor(Number(distributable) * PROTOCOL_CONSTANTS.TOKEN_DISTRIBUTION_RATIO)
  );

  const btc = BigInt(Math.floor(Number(btcPool) * ratio)) as Satoshi;
  const tokenValue = BigInt(Math.floor(Number(tokenPool) * ratio));
  const tokens = ((tokenValue * BigInt(10 ** 18)) / PROTOCOL_CONSTANTS.TOKEN_RATE) as TokenAmount;

  return { btc, tokens };
}

/**
 * Validate distribution totals
 */
export function validateDistribution(
  distribution: DistributionResult[],
  expectedPayment: Satoshi
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  const totalWeight = distribution.reduce((sum, d) => sum + d.weight, 0);
  if (totalWeight !== 10000) {
    errors.push(`Weight total ${totalWeight} != 10000`);
  }

  const protocolFee = calculateProtocolFee(expectedPayment);
  const distributable = (expectedPayment - protocolFee) as Satoshi;
  const expectedBTC = BigInt(
    Math.floor(Number(distributable) * PROTOCOL_CONSTANTS.BTC_DISTRIBUTION_RATIO)
  );

  const actualBTC = distribution.reduce((sum, d) => sum + d.btcAmount, 0n);
  const btcDiff = expectedBTC - actualBTC;

  if (btcDiff < 0n || btcDiff > BigInt(distribution.length)) {
    errors.push('BTC distribution mismatch');
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Redistribute forfeited tokens among acceptors
 */
export function redistributeForfeited(
  distribution: DistributionResult[]
): DistributionResult[] {
  const forfeited = getTotalForfeited(distribution);
  if (forfeited === 0n) return distribution;

  const acceptors = distribution.filter(d => d.tokenAccepted);
  if (acceptors.length === 0) return distribution;

  const totalAcceptorWeight = acceptors.reduce((sum, d) => sum + d.weight, 0);
  const bonusPerBP = forfeited / BigInt(totalAcceptorWeight);

  return distribution.map(d => {
    if (!d.tokenAccepted) return d;
    const bonus = (bonusPerBP * BigInt(d.weight)) as TokenAmount;
    return {
      ...d,
      tokenAmount: (d.tokenAmount + bonus) as TokenAmount
    };
  });
}
