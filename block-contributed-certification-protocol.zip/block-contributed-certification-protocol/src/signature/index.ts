// Protocol functions
export {
  getBCCPDomain,
  createOutboundSignature,
  createCounterSignature,
  createSignaturePair,
  getSignaturePairHash,
  createClosureSignature,
  createDisputeSignature,
  createResolutionSignature,
  getOutboundMessageHash,
  getCounterMessageHash,
  computeChainHash
} from './protocol';

// Verification functions
export {
  verifyOutboundSignature,
  verifyCounterSignature,
  verifySignaturePair,
  verifyTimestamp,
  verifySignaturePairTimestamps,
  verifySignaturePairFull,
  verifySignatureChain,
  extractChainAddresses
} from './verifier';
