import { hash, hashMultiple, hashObject, verifyHash, createHashChain } from '../../src/crypto/hash';

describe('Hash Module', () => {
  describe('hash', () => {
    it('should produce consistent SHA3-256 hash for string input', () => {
      const input = 'hello world';
      const result1 = hash(input);
      const result2 = hash(input);

      expect(result1).toBe(result2);
      expect(result1).toMatch(/^0x[0-9a-f]{64}$/);
    });

    it('should produce different hashes for different inputs', () => {
      const hash1 = hash('input1');
      const hash2 = hash('input2');

      expect(hash1).not.toBe(hash2);
    });

    it('should handle Buffer input', () => {
      const buffer = Buffer.from('test data');
      const result = hash(buffer);

      expect(result).toMatch(/^0x[0-9a-f]{64}$/);
    });

    it('should handle Uint8Array input', () => {
      const array = new Uint8Array([1, 2, 3, 4]);
      const result = hash(array);

      expect(result).toMatch(/^0x[0-9a-f]{64}$/);
    });
  });

  describe('hashMultiple', () => {
    it('should combine multiple values and hash', () => {
      const result = hashMultiple('a', 'b', 'c');

      expect(result).toMatch(/^0x[0-9a-f]{64}$/);
    });

    it('should produce different results for different order', () => {
      const hash1 = hashMultiple('a', 'b');
      const hash2 = hashMultiple('b', 'a');

      expect(hash1).not.toBe(hash2);
    });
  });

  describe('hashObject', () => {
    it('should hash object deterministically', () => {
      const obj = { b: 2, a: 1 };
      const result1 = hashObject(obj);
      const result2 = hashObject({ a: 1, b: 2 });

      expect(result1).toBe(result2);
    });

    it('should produce different hashes for different objects', () => {
      const hash1 = hashObject({ a: 1 });
      const hash2 = hashObject({ a: 2 });

      expect(hash1).not.toBe(hash2);
    });
  });

  describe('verifyHash', () => {
    it('should return true for matching hash', () => {
      const data = 'test data';
      const expectedHash = hash(data);

      expect(verifyHash(data, expectedHash)).toBe(true);
    });

    it('should return false for non-matching hash', () => {
      const data = 'test data';
      const wrongHash = hash('wrong data');

      expect(verifyHash(data, wrongHash)).toBe(false);
    });
  });

  describe('createHashChain', () => {
    it('should create linked hash chain', () => {
      const items = ['item1', 'item2', 'item3'];
      const chain = createHashChain(items);

      expect(chain).toHaveLength(3);
      chain.forEach(h => {
        expect(h).toMatch(/^0x[0-9a-f]{64}$/);
      });
    });

    it('should produce different chains for different inputs', () => {
      const chain1 = createHashChain(['a', 'b']);
      const chain2 = createHashChain(['a', 'c']);

      expect(chain1[0]).toBe(chain2[0]); // First element same
      expect(chain1[1]).not.toBe(chain2[1]); // Second element different
    });
  });
});
