import { Address, Satoshi, TokenAmount } from './types/common';

/**
 * Protocol-wide constants
 */
export const PROTOCOL_CONSTANTS = {
  // Registry contract address
  REGISTRY_ADDRESS: '0x0000000000000000000000000000000000000001' as Address,

  // Fee configuration
  PROTOCOL_FEE_RATE: 0.03,            // 3% protocol fee

  // Distribution ratios
  BTC_DISTRIBUTION_RATIO: 0.8,        // 80% paid in BTC
  TOKEN_DISTRIBUTION_RATIO: 0.2,      // 20% paid in tokens

  // Token economics
  TOKEN_RATE: 1000n as Satoshi,       // 1000 satoshi per token
  TOKEN_DECIMALS: 18,
  MIN_PAYMENT: 10000n as Satoshi,     // 0.0001 BTC minimum

  // Signature validity
  SIGNATURE_VALIDITY_MS: 24 * 60 * 60 * 1000,  // 24 hours

  // Node staking
  MIN_NODE_STAKE: 100000n as Satoshi, // 0.001 BTC minimum stake
  MAX_NODE_STAKE: 100000000n as Satoshi, // 1 BTC maximum stake

  // Node scoring
  HEARTBEAT_INTERVAL: 60 * 1000,      // 1 minute
  NODE_SCORE_WEIGHTS: {
    uptime: 0.3,
    latency: 0.3,
    honesty: 0.4
  },

  // Slashing parameters
  SLASHING_RATES: {
    EXTENDED_DOWNTIME: 0.05,          // 5% of stake
    DATA_MANIPULATION: 0.50,          // 50% of stake
    MALICIOUS_ACTIVITY: 1.00,         // 100% of stake
    PROTOCOL_VIOLATION: 0.20          // 20% of stake
  },

  // Appeal window
  APPEAL_WINDOW_MS: 7 * 24 * 60 * 60 * 1000, // 7 days

  // Reputation thresholds
  REPUTATION_TIERS: {
    DIAMOND: 900,
    PLATINUM: 800,
    GOLD: 700,
    SILVER: 600,
    BRONZE: 0
  },

  // Weight limits
  MAX_WEIGHT: 10000,
  MIN_CONTRIBUTOR_WEIGHT: 100,

  // Chain limits
  MAX_CHAIN_LENGTH: 50,
  MIN_CHAIN_LENGTH: 2,

  // Route configuration
  MIN_ROUTE_NODES: 3,
  MAX_ROUTE_NODES: 7,
  ROUTE_EXPIRY_MS: 5 * 60 * 1000,     // 5 minutes

  // Forfeit processing
  FORFEIT_BATCH_SIZE: 100,
  FORFEIT_PROCESSING_INTERVAL: 24 * 60 * 60 * 1000  // 24 hours
} as const;

/**
 * Default weight distribution by role
 */
export const DEFAULT_WEIGHT_DISTRIBUTION = {
  INITIATOR: 3000,
  RECEIVER: 2500,
  PRODUCER: 2000,
  EDITOR: 1500,
  CUSTOM: 1000
} as const;

/**
 * TX state machine transitions
 */
export const STATE_TRANSITIONS = {
  DRAFT: ['OPEN', 'CANCELLED'],
  OPEN: ['PENDING', 'DISPUTED', 'CANCELLED'],
  PENDING: ['CLOSED', 'DISPUTED'],
  CLOSED: [],
  DISPUTED: ['OPEN', 'CANCELLED'],
  CANCELLED: []
} as const;

/**
 * Error codes
 */
export const ERROR_CODES = {
  INVALID_SIGNATURE: 'E001',
  CHAIN_BROKEN: 'E002',
  INVALID_STATE: 'E003',
  WEIGHT_MISMATCH: 'E004',
  INSUFFICIENT_STAKE: 'E005',
  NODE_NOT_FOUND: 'E006',
  TX_NOT_FOUND: 'E007',
  UNAUTHORIZED: 'E008',
  EXPIRED: 'E009',
  ALREADY_EXISTS: 'E010'
} as const;

/**
 * Event types for logging/webhooks
 */
export const EVENT_TYPES = {
  TX_CREATED: 'tx.created',
  TX_UPDATED: 'tx.updated',
  TX_CLOSED: 'tx.closed',
  TX_CANCELLED: 'tx.cancelled',
  CONTRIBUTOR_ADDED: 'contributor.added',
  TOKEN_MINTED: 'token.minted',
  TOKEN_FORFEITED: 'token.forfeited',
  NODE_REGISTERED: 'node.registered',
  NODE_SLASHED: 'node.slashed',
  RELAY_COMPLETED: 'relay.completed'
} as const;
