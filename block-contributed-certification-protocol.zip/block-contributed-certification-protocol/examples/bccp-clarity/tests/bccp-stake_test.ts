import {
  Clarinet,
  Tx,
  Chain,
  Account,
  types,
} from "https://deno.land/x/clarinet@v1.7.1/index.ts";
import { assertEquals } from "https://deno.land/std@0.170.0/testing/asserts.ts";

// ============================================
// Stake Deposit Tests
// ============================================

Clarinet.test({
  name: "deposit-stake: Successfully deposits stake for position A",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)], // TX ID 1, 1 STX
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    // Verify stake info
    const stakeInfo = chain.callReadOnlyFn(
      "bccp-stake",
      "get-stake-info",
      [types.uint(1), types.principal(alice.address)],
      alice.address
    );
    assertEquals(stakeInfo.result.includes("amount: u1000000"), true);
  },
});

Clarinet.test({
  name: "deposit-stake: Successfully deposits stake for position B",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    // A stakes first
    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        alice.address
      ),
    ]);

    // B stakes second
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(2000000)],
        bob.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    // Verify both stakes
    const summary = chain.callReadOnlyFn(
      "bccp-stake",
      "get-tx-stake-summary",
      [types.uint(1)],
      alice.address
    );
    assertEquals(summary.result.includes("stake-a: u1000000"), true);
    assertEquals(summary.result.includes("stake-b: u2000000"), true);
  },
});

Clarinet.test({
  name: "deposit-stake: Fails with amount below minimum",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(100)], // Below 1 STX minimum
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

Clarinet.test({
  name: "deposit-stake: Cannot stake more than twice per TX",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const charlie = accounts.get("wallet_3")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        alice.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        bob.address
      ),
    ]);

    // Third stake should fail
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        charlie.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Has Both Stakes Tests
// ============================================

Clarinet.test({
  name: "has-both-stakes: Returns false with no stakes",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn(
      "bccp-stake",
      "has-both-stakes",
      [types.uint(1)],
      deployer.address
    );
    assertEquals(result.result, "false");
  },
});

Clarinet.test({
  name: "has-both-stakes: Returns false with one stake",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        alice.address
      ),
    ]);

    const result = chain.callReadOnlyFn(
      "bccp-stake",
      "has-both-stakes",
      [types.uint(1)],
      deployer.address
    );
    assertEquals(result.result, "false");
  },
});

Clarinet.test({
  name: "has-both-stakes: Returns true with both stakes",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        alice.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        bob.address
      ),
    ]);

    const result = chain.callReadOnlyFn(
      "bccp-stake",
      "has-both-stakes",
      [types.uint(1)],
      deployer.address
    );
    assertEquals(result.result, "true");
  },
});

// ============================================
// Stake Statistics Tests
// ============================================

Clarinet.test({
  name: "get-stake-stats: Returns correct statistics",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        alice.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(2000000)],
        bob.address
      ),
    ]);

    const stats = chain.callReadOnlyFn(
      "bccp-stake",
      "get-stake-stats",
      [],
      deployer.address
    );
    assertEquals(stats.result.includes("total-staked: u3000000"), true);
  },
});

// ============================================
// Get Stake Position Tests
// ============================================

Clarinet.test({
  name: "get-stake-at-position: Returns correct stake data",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1500000)],
        alice.address
      ),
    ]);

    const stake = chain.callReadOnlyFn(
      "bccp-stake",
      "get-stake-at-position",
      [types.uint(1), types.uint(0)], // Position A
      deployer.address
    );
    assertEquals(stake.result.includes("amount: u1500000"), true);
    assertEquals(stake.result.includes(alice.address), true);
    assertEquals(stake.result.includes('status: "active"'), true);
  },
});

// ============================================
// User Stake History Tests
// ============================================

Clarinet.test({
  name: "get-user-stake-count: Returns correct count",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const deployer = accounts.get("deployer")!;

    // Stake in multiple TXs
    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(1), types.uint(1000000)],
        alice.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "deposit-stake",
        [types.uint(2), types.uint(1000000)],
        alice.address
      ),
    ]);

    const count = chain.callReadOnlyFn(
      "bccp-stake",
      "get-user-stake-count",
      [types.principal(alice.address)],
      deployer.address
    );
    assertEquals(count.result, "u2");
  },
});

// ============================================
// Admin Function Tests
// ============================================

Clarinet.test({
  name: "set-min-stake-amount: Owner can update minimum",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "set-min-stake-amount",
        [types.uint(2000000)], // 2 STX
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const minStake = chain.callReadOnlyFn(
      "bccp-stake",
      "get-min-stake-amount",
      [],
      deployer.address
    );
    assertEquals(minStake.result, "u2000000");
  },
});

Clarinet.test({
  name: "set-min-stake-amount: Non-owner cannot update",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-stake",
        "set-min-stake-amount",
        [types.uint(2000000)],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});
