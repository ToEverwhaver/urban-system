import {
  mintTokens,
  getBalance,
  getTotalSupply,
  getIssuanceByTX,
  getIssuanceHistory,
  getAllBalances,
  getTopHolders,
  transfer,
  burn,
  getTotalMinted,
  clearLedger
} from '../../src/token/minter';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { DistributionResult } from '../../src/types/tx';
import { Role } from '../../src/types/contributor';
import { Address, BasisPoints, Satoshi, TokenAmount, UUID } from '../../src/types/common';
import { generateUUID } from '../../src/crypto/uuid';

describe('Token Minter Module', () => {
  const keys1 = generateKeyPair();
  const keys2 = generateKeyPair();
  const address1 = privateKeyToAddress(keys1.privateKey);
  const address2 = privateKeyToAddress(keys2.privateKey);

  beforeEach(() => {
    clearLedger();
  });

  describe('mintTokens', () => {
    it('should mint tokens for distribution', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 6000 as BasisPoints,
          btcAmount: 800000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: true
        },
        {
          contributor: address2,
          role: Role.Receiver,
          weight: 4000 as BasisPoints,
          btcAmount: 200000n as Satoshi,
          tokenAmount: 500000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];

      const issuance = await mintTokens(txId, distribution);

      expect(issuance.id).toBeDefined();
      expect(issuance.txId).toBe(txId);
      expect(issuance.recipients).toHaveLength(2);
      expect(issuance.amount).toBe(1500000000000000000n);
    });

    it('should not credit balance for rejected tokens', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: false
        }
      ];

      await mintTokens(txId, distribution);

      expect(getBalance(address1)).toBe(0n);
    });

    it('should track issuance history', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      const history = getIssuanceHistory();
      expect(history).toHaveLength(1);
      expect(history[0].txId).toBe(txId);
    });
  });

  describe('getBalance', () => {
    it('should return 0 for unknown address', () => {
      expect(getBalance(address1)).toBe(0n);
    });

    it('should return correct balance after minting', async () => {
      const txId = generateUUID() as UUID;
      const amount = 1000000000000000000n as TokenAmount;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: amount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      expect(getBalance(address1)).toBe(amount);
    });
  });

  describe('getTotalSupply', () => {
    it('should return 0 for empty ledger', () => {
      expect(getTotalSupply()).toBe(0n);
    });

    it('should sum all balances', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 6000 as BasisPoints,
          btcAmount: 600000n as Satoshi,
          tokenAmount: 600n as TokenAmount,
          tokenAccepted: true
        },
        {
          contributor: address2,
          role: Role.Receiver,
          weight: 4000 as BasisPoints,
          btcAmount: 400000n as Satoshi,
          tokenAmount: 400n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      expect(getTotalSupply()).toBe(1000n);
    });
  });

  describe('getIssuanceByTX', () => {
    it('should find issuance by TX ID', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      const found = getIssuanceByTX(txId);
      expect(found).toBeDefined();
      expect(found!.txId).toBe(txId);
    });

    it('should return undefined for unknown TX', () => {
      const unknown = generateUUID() as UUID;
      expect(getIssuanceByTX(unknown)).toBeUndefined();
    });
  });

  describe('transfer', () => {
    it('should transfer tokens between addresses', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      const result = transfer(address1, address2, 400n as TokenAmount);

      expect(result).toBe(true);
      expect(getBalance(address1)).toBe(600n);
      expect(getBalance(address2)).toBe(400n);
    });

    it('should fail for insufficient balance', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 100n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      const result = transfer(address1, address2, 200n as TokenAmount);

      expect(result).toBe(false);
      expect(getBalance(address1)).toBe(100n);
    });
  });

  describe('burn', () => {
    it('should burn tokens', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      const result = burn(address1, 400n as TokenAmount);

      expect(result).toBe(true);
      expect(getBalance(address1)).toBe(600n);
      expect(getTotalSupply()).toBe(600n);
    });

    it('should fail for insufficient balance', async () => {
      const result = burn(address1, 100n as TokenAmount);

      expect(result).toBe(false);
    });
  });

  describe('getTopHolders', () => {
    it('should return holders sorted by balance', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 3000 as BasisPoints,
          btcAmount: 300000n as Satoshi,
          tokenAmount: 300n as TokenAmount,
          tokenAccepted: true
        },
        {
          contributor: address2,
          role: Role.Receiver,
          weight: 7000 as BasisPoints,
          btcAmount: 700000n as Satoshi,
          tokenAmount: 700n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);

      const holders = getTopHolders();

      expect(holders[0].address).toBe(address2);
      expect(holders[0].balance).toBe(700n);
      expect(holders[1].address).toBe(address1);
    });
  });

  describe('getTotalMinted', () => {
    it('should track total minted including burned', async () => {
      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000n as TokenAmount,
          tokenAccepted: true
        }
      ];

      await mintTokens(txId, distribution);
      burn(address1, 300n as TokenAmount);

      expect(getTotalMinted()).toBe(1000n);
      expect(getTotalSupply()).toBe(700n);
    });
  });
});
