import { hash } from './hash';
import { Hash } from '../types/common';

export interface MerkleTree {
  root: Hash;
  leaves: Hash[];
  layers: Hash[][];
}

export interface MerkleProof {
  leaf: Hash;
  index: number;
  siblings: Hash[];
  root: Hash;
}

/**
 * Build a Merkle tree from leaf hashes
 */
export function buildMerkleTree(leaves: Hash[]): MerkleTree {
  if (leaves.length === 0) {
    throw new Error('Cannot build tree with no leaves');
  }

  const paddedLeaves = [...leaves];
  if (paddedLeaves.length % 2 !== 0) {
    paddedLeaves.push(paddedLeaves[paddedLeaves.length - 1]);
  }

  const layers: Hash[][] = [paddedLeaves];
  let current = paddedLeaves;

  while (current.length > 1) {
    const next: Hash[] = [];
    for (let i = 0; i < current.length; i += 2) {
      const left = current[i];
      const right = current[i + 1] || left;
      next.push(hash(`${left}${right}`));
    }
    layers.push(next);
    current = next;
  }

  return { root: current[0], leaves: paddedLeaves, layers };
}

/**
 * Generate a proof for a leaf at given index
 */
export function generateProof(tree: MerkleTree, leafIndex: number): MerkleProof {
  if (leafIndex < 0 || leafIndex >= tree.leaves.length) {
    throw new Error('Leaf index out of bounds');
  }

  const siblings: Hash[] = [];
  let index = leafIndex;

  for (let i = 0; i < tree.layers.length - 1; i++) {
    const layer = tree.layers[i];
    const isRight = index % 2 === 1;
    const siblingIndex = isRight ? index - 1 : index + 1;

    if (siblingIndex < layer.length) {
      siblings.push(layer[siblingIndex]);
    }
    index = Math.floor(index / 2);
  }

  return {
    leaf: tree.leaves[leafIndex],
    index: leafIndex,
    siblings,
    root: tree.root
  };
}

/**
 * Verify a Merkle proof
 */
export function verifyProof(proof: MerkleProof): boolean {
  let current = proof.leaf;
  let index = proof.index;

  for (const sibling of proof.siblings) {
    const isRight = index % 2 === 1;
    current = isRight
      ? hash(`${sibling}${current}`)
      : hash(`${current}${sibling}`);
    index = Math.floor(index / 2);
  }

  return current === proof.root;
}

/**
 * Get root hash directly from leaves
 */
export function getMerkleRoot(leaves: Hash[]): Hash {
  return buildMerkleTree(leaves).root;
}

/**
 * Create a multi-proof for multiple leaves
 */
export function generateMultiProof(tree: MerkleTree, indices: number[]): {
  leaves: Hash[];
  proof: Hash[];
  indices: number[];
} {
  const sortedIndices = [...new Set(indices)].sort((a, b) => a - b);
  const leaves = sortedIndices.map(i => tree.leaves[i]);

  const proofSet = new Set<string>();
  const usedIndices = new Set<number>();

  for (const leafIndex of sortedIndices) {
    let index = leafIndex;
    for (let layer = 0; layer < tree.layers.length - 1; layer++) {
      const isRight = index % 2 === 1;
      const siblingIndex = isRight ? index - 1 : index + 1;
      const globalIndex = layer * 1000 + siblingIndex;

      if (!usedIndices.has(globalIndex) && siblingIndex < tree.layers[layer].length) {
        const siblingLeafIndex = siblingIndex * Math.pow(2, layer);
        if (!sortedIndices.some(i => {
          const range = Math.pow(2, layer);
          return i >= siblingLeafIndex && i < siblingLeafIndex + range;
        })) {
          proofSet.add(tree.layers[layer][siblingIndex]);
        }
      }
      usedIndices.add(globalIndex);
      index = Math.floor(index / 2);
    }
  }

  return {
    leaves,
    proof: Array.from(proofSet) as Hash[],
    indices: sortedIndices
  };
}
