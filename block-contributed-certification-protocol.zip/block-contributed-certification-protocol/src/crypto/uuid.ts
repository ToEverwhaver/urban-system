import { UUID, Timestamp } from '../types/common';

/**
 * Generate UUID v7 (time-ordered)
 */
export function generateUUID(timestamp?: Timestamp): UUID {
  const ts = timestamp ?? Date.now();

  const tsHex = ts.toString(16).padStart(12, '0');
  const version = '7';

  // Need 10 bytes (20 hex chars) for the random portion
  const randomBytes = crypto.getRandomValues(new Uint8Array(10));
  const randomHex = Array.from(randomBytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');

  // UUID v7 format: xxxxxxxx-xxxx-7xxx-yxxx-xxxxxxxxxxxx
  // where y is 8, 9, a, or b (variant bits)
  const uuid = [
    tsHex.slice(0, 8),                                                    // 8 chars
    tsHex.slice(8, 12),                                                   // 4 chars
    version + randomHex.slice(0, 3),                                      // 4 chars (7 + 3 random)
    ((parseInt(randomHex.slice(3, 5), 16) & 0x3f) | 0x80)
      .toString(16).padStart(2, '0') + randomHex.slice(5, 7),             // 4 chars (variant + 2 random)
    randomHex.slice(7, 19)                                                // 12 chars
  ].join('-');

  return uuid as UUID;
}

/**
 * Extract timestamp from UUID v7
 */
export function extractTimestamp(uuid: UUID): Timestamp {
  const hex = uuid.replace(/-/g, '').slice(0, 12);
  return parseInt(hex, 16) as Timestamp;
}

/**
 * Validate UUID v7 format
 */
export function isValidUUID(uuid: string): uuid is UUID {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uuid);
}

/**
 * Compare UUIDs chronologically
 */
export function compareUUIDs(a: UUID, b: UUID): -1 | 0 | 1 {
  const tsA = extractTimestamp(a);
  const tsB = extractTimestamp(b);
  if (tsA < tsB) return -1;
  if (tsA > tsB) return 1;
  return a < b ? -1 : a > b ? 1 : 0;
}

/**
 * Sort UUIDs by timestamp
 */
export function sortUUIDs(uuids: UUID[]): UUID[] {
  return [...uuids].sort(compareUUIDs);
}

/**
 * Check if UUID was generated within time window
 */
export function isWithinTimeWindow(uuid: UUID, windowMs: number): boolean {
  const ts = extractTimestamp(uuid);
  const now = Date.now();
  return now - ts <= windowMs;
}

/**
 * Generate sequential UUIDs for batch operations
 */
export function generateSequentialUUIDs(count: number): UUID[] {
  const baseTime = Date.now();
  return Array.from({ length: count }, (_, i) =>
    generateUUID((baseTime + i) as Timestamp)
  );
}
