import { TX, TXState, TXChainEntry, CreateTXParams } from '../types/tx';
import { Contributor, Role } from '../types/contributor';
import { SignaturePair } from '../types/signature';
import { Hash, Address, Timestamp, BasisPoints } from '../types/common';
import { generateUUID } from '../crypto/uuid';
import { hashObject } from '../crypto/hash';
import { getMerkleRoot } from '../crypto/merkle';

/**
 * Create a new TX with initiator
 */
export function createTX(params: CreateTXParams): TX {
  const now = Date.now() as Timestamp;
  const id = generateUUID(now);

  const initiator: Contributor = {
    address: params.initiator,
    role: Role.Initiator,
    weight: 3000 as BasisPoints,
    joinedAt: now
  };

  const firstEntry: TXChainEntry = {
    contributor: initiator,
    signaturePair: null,
    contentHash: params.assetHash
  };

  const weights = params.initialWeights ?? new Map<Address, BasisPoints>();
  if (!weights.has(params.initiator)) {
    weights.set(params.initiator, 3000 as BasisPoints);
  }

  return {
    id,
    assetHash: params.assetHash,
    assetType: params.assetType,
    assetMetadata: params.assetMetadata,
    chain: [firstEntry],
    weights,
    state: TXState.Draft,
    createdAt: now,
    updatedAt: now
  };
}

/**
 * Add a contributor to the TX chain
 */
export function addContributor(
  tx: TX,
  contributor: Contributor,
  signaturePair: SignaturePair,
  contentHash: Hash
): TX {
  if (tx.state !== TXState.Draft && tx.state !== TXState.Open) {
    throw new Error(`Cannot add contributor in state: ${tx.state}`);
  }

  const lastEntry = tx.chain[tx.chain.length - 1];
  if (signaturePair.outbound.from !== lastEntry.contributor.address) {
    throw new Error('Chain broken: outbound.from must match last contributor');
  }

  const entry: TXChainEntry = {
    contributor,
    signaturePair,
    contentHash
  };

  const now = Date.now() as Timestamp;
  const newChain = [...tx.chain, entry];

  return {
    ...tx,
    chain: newChain,
    state: TXState.Open,
    updatedAt: now,
    chainMerkleRoot: computeChainMerkleRoot(newChain)
  };
}

/**
 * Set contributor weights
 */
export function setWeights(tx: TX, weights: Map<Address, BasisPoints>): TX {
  const total = Array.from(weights.values()).reduce((a, b) => a + b, 0);
  if (total !== 10000) {
    throw new Error(`Weights must sum to 10000, got ${total}`);
  }

  for (const entry of tx.chain) {
    if (!weights.has(entry.contributor.address)) {
      throw new Error(`Missing weight for: ${entry.contributor.address}`);
    }
  }

  return {
    ...tx,
    weights,
    updatedAt: Date.now() as Timestamp
  };
}

/**
 * Compute Merkle root of chain entries
 */
export function computeChainMerkleRoot(chain: TXChainEntry[]): Hash {
  const leaves = chain.map(entry =>
    hashObject({
      address: entry.contributor.address,
      role: entry.contributor.role,
      contentHash: entry.contentHash
    })
  );
  return getMerkleRoot(leaves);
}

/**
 * Get contributor by address
 */
export function getContributor(tx: TX, address: Address): Contributor | undefined {
  return tx.chain.find(e => e.contributor.address === address)?.contributor;
}

/**
 * Get chain entry by address
 */
export function getChainEntry(tx: TX, address: Address): TXChainEntry | undefined {
  return tx.chain.find(e => e.contributor.address === address);
}

/**
 * Get contributor by role
 */
export function getContributorByRole(tx: TX, role: Role): Contributor | undefined {
  return tx.chain.find(e => e.contributor.role === role)?.contributor;
}

/**
 * Check if address is a contributor
 */
export function isContributor(tx: TX, address: Address): boolean {
  return tx.chain.some(e => e.contributor.address === address);
}

/**
 * Get last contributor in chain
 */
export function getLastContributor(tx: TX): Contributor {
  return tx.chain[tx.chain.length - 1].contributor;
}

/**
 * Update TX state
 */
export function updateState(tx: TX, state: TXState): TX {
  return {
    ...tx,
    state,
    updatedAt: Date.now() as Timestamp
  };
}

/**
 * Cancel a TX
 */
export function cancelTX(tx: TX): TX {
  if (tx.state === TXState.Closed) {
    throw new Error('Cannot cancel closed TX');
  }
  return updateState(tx, TXState.Cancelled);
}

/**
 * Serialize TX to JSON string (handles BigInt)
 */
export function serializeTX(tx: TX): string {
  const replacer = (_key: string, value: unknown): unknown => {
    if (typeof value === 'bigint') {
      return { __type: 'bigint', value: value.toString() };
    }
    return value;
  };

  return JSON.stringify({
    ...tx,
    weights: Array.from(tx.weights.entries())
  }, replacer);
}

/**
 * Deserialize TX from JSON string (handles BigInt)
 */
export function deserializeTX(json: string): TX {
  const reviver = (_key: string, value: unknown): unknown => {
    if (value && typeof value === 'object' && (value as Record<string, unknown>).__type === 'bigint') {
      return BigInt((value as Record<string, string>).value);
    }
    return value;
  };

  const parsed = JSON.parse(json, reviver);
  return {
    ...parsed,
    weights: new Map(parsed.weights)
  };
}

/**
 * Clone a TX
 */
export function cloneTX(tx: TX): TX {
  return deserializeTX(serializeTX(tx));
}
