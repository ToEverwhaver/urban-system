import { TX, TXState, CreateTXParams, DistributionResult } from '../types/tx';
import { Contributor, Role } from '../types/contributor';
import { SignaturePair, ECDSASignature } from '../types/signature';
import { Hash, Address, UUID, Satoshi, BasisPoints } from '../types/common';
import { createTX, addContributor, setWeights, cancelTX } from '../tx/chain';
import { validateTX, validateForClosure } from '../tx/validator';
import { processClosure, previewDistribution } from '../closure';
import { getDefaultStorage } from '../storage/memory';

export interface CreateTXRequest {
  assetHash: Hash;
  assetType: string;
  assetMetadata?: Record<string, string>;
  initiator: Address;
}

export interface AddContributorRequest {
  txId: UUID;
  address: Address;
  role: Role;
  signaturePair: SignaturePair;
  contentHash: Hash;
  weight?: BasisPoints;
}

export interface CloseTXRequest {
  txId: UUID;
  sponsor: Address;
  sponsorSignature: ECDSASignature;
  paymentAmount: Satoshi;
  paymentTxHash?: Hash;
}

export interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

/**
 * Create a new TX
 */
export async function apiCreateTX(
  request: CreateTXRequest
): Promise<APIResponse<TX>> {
  try {
    const tx = createTX({
      assetHash: request.assetHash,
      assetType: request.assetType,
      assetMetadata: request.assetMetadata,
      initiator: request.initiator
    });

    await getDefaultStorage().saveTX(tx);
    return { success: true, data: tx };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get TX by ID
 */
export async function apiGetTX(id: UUID): Promise<APIResponse<TX>> {
  try {
    const tx = await getDefaultStorage().getTX(id);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }
    return { success: true, data: tx };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Add contributor to TX
 */
export async function apiAddContributor(
  request: AddContributorRequest
): Promise<APIResponse<TX>> {
  try {
    const tx = await getDefaultStorage().getTX(request.txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const contributor: Contributor = {
      address: request.address,
      role: request.role,
      weight: request.weight ?? (2000 as BasisPoints),
      joinedAt: Date.now() as any
    };

    const updated = addContributor(
      tx,
      contributor,
      request.signaturePair,
      request.contentHash
    );

    await getDefaultStorage().saveTX(updated);
    return { success: true, data: updated };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Set TX weights
 */
export async function apiSetWeights(
  txId: UUID,
  weights: Map<Address, BasisPoints>
): Promise<APIResponse<TX>> {
  try {
    const tx = await getDefaultStorage().getTX(txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const updated = setWeights(tx, weights);
    await getDefaultStorage().saveTX(updated);
    return { success: true, data: updated };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Validate TX
 */
export async function apiValidateTX(
  txId: UUID
): Promise<APIResponse<{ valid: boolean; errors: string[]; warnings: string[] }>> {
  try {
    const tx = await getDefaultStorage().getTX(txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const result = validateTX(tx);
    return { success: true, data: result };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Preview distribution
 */
export async function apiPreviewDistribution(
  txId: UUID,
  payment: Satoshi
): Promise<APIResponse<ReturnType<typeof previewDistribution>>> {
  try {
    const tx = await getDefaultStorage().getTX(txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const preview = previewDistribution(tx, payment);
    return { success: true, data: preview };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Close TX
 */
export async function apiCloseTX(
  request: CloseTXRequest
): Promise<APIResponse<{ tx: TX; distribution: DistributionResult[] }>> {
  try {
    const tx = await getDefaultStorage().getTX(request.txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const result = await processClosure(tx, {
      txId: request.txId,
      sponsor: request.sponsor,
      sponsorSignature: request.sponsorSignature,
      paymentAmount: request.paymentAmount,
      paymentTxHash: request.paymentTxHash
    });

    if (!result.success || !result.tx || !result.distribution) {
      return { success: false, error: result.error };
    }

    await getDefaultStorage().saveTX(result.tx);
    return {
      success: true,
      data: { tx: result.tx, distribution: result.distribution }
    };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Cancel TX
 */
export async function apiCancelTX(txId: UUID): Promise<APIResponse<TX>> {
  try {
    const tx = await getDefaultStorage().getTX(txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const cancelled = cancelTX(tx);
    await getDefaultStorage().saveTX(cancelled);
    return { success: true, data: cancelled };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get TXs by state
 */
export async function apiGetTXsByState(state: TXState): Promise<APIResponse<TX[]>> {
  try {
    const txs = await getDefaultStorage().getTXsByState(state);
    return { success: true, data: txs };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get TXs by contributor
 */
export async function apiGetTXsByContributor(address: Address): Promise<APIResponse<TX[]>> {
  try {
    const txs = await getDefaultStorage().getTXsByContributor(address);
    return { success: true, data: txs };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}
