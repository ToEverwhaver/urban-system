import { Address, Hash, Timestamp, HexString } from './common';
import { Role } from './contributor';

// ECDSA signature components
export interface ECDSASignature {
  r: HexString;
  s: HexString;
  v: number;                  // Recovery id (27 or 28)
}

// Outbound signature (A → B)
export interface OutboundSignature {
  type: 'OUTBOUND';
  from: Address;
  to: Address;
  contentHash: Hash;
  previousHash: Hash | null;  // null for first in chain
  role: Role;
  timestamp: Timestamp;
  signature: ECDSASignature;
}

// Counter signature (B acknowledges A)
export interface CounterSignature {
  type: 'COUNTER';
  from: Address;              // Acknowledger
  originalSigner: Address;    // Original sender
  outboundSignatureHash: Hash;
  responsibilityAccepted: boolean;
  timestamp: Timestamp;
  signature: ECDSASignature;
}

// Combined signature pair
export interface SignaturePair {
  outbound: OutboundSignature;
  counter: CounterSignature;
}

// EIP-712 domain
export interface EIP712Domain {
  name: string;
  version: string;
  chainId: number;
  verifyingContract: Address;
}

// Signature verification result
export interface SignatureVerificationResult {
  valid: boolean;
  recoveredAddress?: Address;
  error?: string;
}

// Create empty ECDSA signature (for testing)
export function createEmptySignature(): ECDSASignature {
  return {
    r: '0x0000000000000000000000000000000000000000000000000000000000000000' as HexString,
    s: '0x0000000000000000000000000000000000000000000000000000000000000000' as HexString,
    v: 27
  };
}
