import { z } from 'zod';
import { Address, Hash, UUID, BasisPoints, Satoshi, TokenAmount } from '../types/common';
import { Role } from '../types/contributor';
import { TXState } from '../types/tx';
import { NodeStatus } from '../types/node';

/**
 * Address validation schema
 */
export const addressSchema = z.string().regex(/^0x[0-9a-f]{40}$/i, 'Invalid address format');

/**
 * Hash validation schema
 */
export const hashSchema = z.string().regex(/^0x[0-9a-f]{64}$/i, 'Invalid hash format');

/**
 * UUID v7 validation schema
 */
export const uuidSchema = z.string().regex(
  /^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
  'Invalid UUID v7 format'
);

/**
 * Basis points validation (0-10000)
 */
export const basisPointsSchema = z.number().int().min(0).max(10000);

/**
 * Role validation
 */
export const roleSchema = z.nativeEnum(Role);

/**
 * TX state validation
 */
export const txStateSchema = z.nativeEnum(TXState);

/**
 * Node status validation
 */
export const nodeStatusSchema = z.nativeEnum(NodeStatus);

/**
 * Endpoint URL validation
 */
export const endpointSchema = z.string().url('Invalid endpoint URL');

/**
 * Positive bigint validation
 */
export const positiveBigintSchema = z.bigint().positive();

/**
 * ECDSA signature schema
 */
export const signatureSchema = z.object({
  r: z.string().regex(/^0x[0-9a-f]{64}$/i),
  s: z.string().regex(/^0x[0-9a-f]{64}$/i),
  v: z.number().int().min(27).max(28)
});

/**
 * Contributor schema
 */
export const contributorSchema = z.object({
  address: addressSchema,
  role: roleSchema,
  customRoleName: z.string().optional(),
  weight: basisPointsSchema,
  joinedAt: z.number()
});

/**
 * Create TX params schema
 */
export const createTXParamsSchema = z.object({
  assetHash: hashSchema,
  assetType: z.string().min(1).max(100),
  assetMetadata: z.record(z.string()).optional(),
  initiator: addressSchema
});

/**
 * Register node params schema
 */
export const registerNodeParamsSchema = z.object({
  operator: addressSchema,
  publicKey: z.string().regex(/^0x[0-9a-f]+$/i),
  endpoint: endpointSchema,
  stake: z.bigint().positive()
});

/**
 * Validate address
 */
export function validateAddress(value: string): value is Address {
  return addressSchema.safeParse(value).success;
}

/**
 * Validate hash
 */
export function validateHash(value: string): value is Hash {
  return hashSchema.safeParse(value).success;
}

/**
 * Validate UUID
 */
export function validateUUID(value: string): value is UUID {
  return uuidSchema.safeParse(value).success;
}

/**
 * Validate basis points
 */
export function validateBasisPoints(value: number): value is BasisPoints {
  return basisPointsSchema.safeParse(value).success;
}

/**
 * Validate weights sum to 10000
 */
export function validateWeightsSum(weights: Map<string, number>): boolean {
  const total = Array.from(weights.values()).reduce((a, b) => a + b, 0);
  return total === 10000;
}

/**
 * Validate payment amount
 */
export function validatePayment(amount: bigint, minAmount: bigint): boolean {
  return amount >= minAmount;
}

/**
 * Validate timestamp is not in future
 */
export function validateTimestamp(timestamp: number): boolean {
  return timestamp <= Date.now();
}

/**
 * Validate timestamp is within window
 */
export function validateTimestampWindow(
  timestamp: number,
  windowMs: number
): boolean {
  const now = Date.now();
  return timestamp >= now - windowMs && timestamp <= now;
}

/**
 * Safe parse with type assertion
 */
export function safeParse<T>(schema: z.ZodSchema<T>, value: unknown): {
  success: boolean;
  data?: T;
  error?: string;
} {
  const result = schema.safeParse(value);
  if (result.success) {
    return { success: true, data: result.data };
  }
  return { success: false, error: result.error.message };
}
