import {
  createTX,
  addContributor,
  setWeights,
  getContributor,
  isContributor,
  cancelTX,
  serializeTX,
  deserializeTX
} from '../../src/tx/chain';
import { hash } from '../../src/crypto/hash';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { createSignaturePair } from '../../src/signature/protocol';
import { Role } from '../../src/types/contributor';
import { TXState } from '../../src/types/tx';
import { Hash, Address, BasisPoints, Timestamp } from '../../src/types/common';

describe('TX Chain Module', () => {
  const initiatorKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();

  const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);

  const assetHash = hash('test-asset') as Hash;

  describe('createTX', () => {
    it('should create TX with initiator', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      expect(tx.id).toBeDefined();
      expect(tx.state).toBe(TXState.Draft);
      expect(tx.chain.length).toBe(1);
      expect(tx.chain[0].contributor.address).toBe(initiatorAddress);
      expect(tx.chain[0].contributor.role).toBe(Role.Initiator);
      expect(tx.chain[0].signaturePair).toBeNull();
    });

    it('should set asset metadata', () => {
      const tx = createTX({
        assetHash,
        assetType: 'video',
        assetMetadata: { title: 'Test', format: 'mp4' },
        initiator: initiatorAddress
      });

      expect(tx.assetMetadata).toEqual({ title: 'Test', format: 'mp4' });
    });

    it('should initialize weights', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      expect(tx.weights.get(initiatorAddress)).toBe(3000);
    });
  });

  describe('addContributor', () => {
    it('should add contributor with signature pair', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contentHash = hash('receiver-content') as Hash;
      const sigPair = createSignaturePair(
        { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        assetHash,
        Role.Receiver
      );

      tx = addContributor(
        tx,
        {
          address: receiverAddress,
          role: Role.Receiver,
          weight: 2500 as BasisPoints,
          joinedAt: Date.now() as Timestamp
        },
        sigPair,
        contentHash
      );

      expect(tx.chain.length).toBe(2);
      expect(tx.state).toBe(TXState.Open);
      expect(tx.chain[1].contributor.address).toBe(receiverAddress);
      expect(tx.chainMerkleRoot).toBeDefined();
    });

    it('should throw for closed TX', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });
      tx = { ...tx, state: TXState.Closed };

      const contentHash = hash('content') as Hash;
      const sigPair = createSignaturePair(
        { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        assetHash,
        Role.Receiver
      );

      expect(() =>
        addContributor(
          tx,
          {
            address: receiverAddress,
            role: Role.Receiver,
            weight: 2500 as BasisPoints,
            joinedAt: Date.now() as Timestamp
          },
          sigPair,
          contentHash
        )
      ).toThrow();
    });
  });

  describe('setWeights', () => {
    it('should set weights summing to 10000', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const weights = new Map<Address, BasisPoints>();
      weights.set(initiatorAddress, 10000 as BasisPoints);

      tx = setWeights(tx, weights);

      expect(tx.weights.get(initiatorAddress)).toBe(10000);
    });

    it('should throw if weights do not sum to 10000', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const weights = new Map<Address, BasisPoints>();
      weights.set(initiatorAddress, 5000 as BasisPoints);

      expect(() => setWeights(tx, weights)).toThrow();
    });
  });

  describe('getContributor', () => {
    it('should find contributor by address', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contributor = getContributor(tx, initiatorAddress);

      expect(contributor).toBeDefined();
      expect(contributor!.address).toBe(initiatorAddress);
    });

    it('should return undefined for unknown address', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const contributor = getContributor(tx, receiverAddress);

      expect(contributor).toBeUndefined();
    });
  });

  describe('isContributor', () => {
    it('should return true for contributor', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      expect(isContributor(tx, initiatorAddress)).toBe(true);
    });

    it('should return false for non-contributor', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      expect(isContributor(tx, receiverAddress)).toBe(false);
    });
  });

  describe('cancelTX', () => {
    it('should cancel draft TX', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });

      const cancelled = cancelTX(tx);

      expect(cancelled.state).toBe(TXState.Cancelled);
    });

    it('should throw for closed TX', () => {
      let tx = createTX({
        assetHash,
        assetType: 'test',
        initiator: initiatorAddress
      });
      tx = { ...tx, state: TXState.Closed };

      expect(() => cancelTX(tx)).toThrow();
    });
  });

  describe('serialization', () => {
    it('should serialize and deserialize TX', () => {
      const tx = createTX({
        assetHash,
        assetType: 'test',
        assetMetadata: { key: 'value' },
        initiator: initiatorAddress
      });

      const serialized = serializeTX(tx);
      const deserialized = deserializeTX(serialized);

      expect(deserialized.id).toBe(tx.id);
      expect(deserialized.assetHash).toBe(tx.assetHash);
      expect(deserialized.weights.get(initiatorAddress)).toBe(tx.weights.get(initiatorAddress));
    });
  });
});
