// Chain operations
export {
  createTX,
  addContributor,
  setWeights,
  computeChainMerkleRoot,
  getContributor,
  getChainEntry,
  getContributorByRole,
  isContributor,
  getLastContributor,
  updateState,
  cancelTX,
  serializeTX,
  deserializeTX,
  cloneTX
} from './chain';

// Builder pattern
export {
  TXBuilder,
  txBuilder,
  buildSimpleTX
} from './builder';

// Validation
export {
  ValidationResult,
  validateTX,
  validateSignaturePair,
  validateWeights,
  validateStateTransition,
  validateChainIntegrity,
  validateForClosure
} from './validator';
