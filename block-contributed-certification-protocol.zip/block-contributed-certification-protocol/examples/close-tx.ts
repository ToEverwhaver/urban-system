/**
 * Example: Closing a TX and distributing rewards
 */

import {
  createTX,
  addContributor,
  txBuilder,
  processClosure,
  previewDistribution,
  mintTokens,
  depositBTC,
  getReserveState,
  getFloorPrice,
  updateProfileFromClosure,
  getProfile,
  generateKeyPair,
  privateKeyToAddress,
  createSignaturePair,
  createClosureSignature,
  hash,
  Role,
  BasisPoints,
  Satoshi,
  Hash,
  Address
} from '../src';

async function main() {
  console.log('=== BCCP TX Closure Example ===\n');

  // Setup participants
  const initiatorKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();
  const sponsorKeys = generateKeyPair();

  const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);
  const sponsorAddress = privateKeyToAddress(sponsorKeys.privateKey);

  console.log('Participants:');
  console.log(`  Initiator: ${initiatorAddress}`);
  console.log(`  Receiver:  ${receiverAddress}`);
  console.log(`  Sponsor:   ${sponsorAddress}`);
  console.log('');

  // Create TX
  const assetHash = hash('Original content') as Hash;
  const receiverContent = hash('Processed content') as Hash;

  const receiverSigPair = createSignaturePair(
    { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
    { address: receiverAddress, privateKey: receiverKeys.privateKey },
    receiverContent,
    assetHash,
    Role.Receiver
  );

  const tx = txBuilder({
    assetHash,
    assetType: 'content',
    initiator: initiatorAddress
  })
    .addReceiver(receiverAddress, receiverSigPair, receiverContent, 4000 as BasisPoints)
    .setWeight(initiatorAddress, 6000 as BasisPoints)
    .build();

  console.log(`TX created: ${tx.id}`);
  console.log(`State: ${tx.state}`);
  console.log('');

  // Preview distribution before closure
  const paymentAmount = 1000000n as Satoshi; // 0.01 BTC
  console.log('=== Distribution Preview ===');
  console.log(`Payment: ${Number(paymentAmount) / 100_000_000} BTC`);
  console.log('');

  const preview = previewDistribution(tx, paymentAmount);
  console.log(`Protocol Fee: ${Number(preview.protocolFee) / 100_000_000} BTC`);
  console.log(`Total BTC to distribute: ${Number(preview.totalBTC) / 100_000_000} BTC`);
  console.log(`Total Tokens to mint: ${Number(preview.totalTokens) / 1e18}`);
  console.log('');

  console.log('Per Contributor:');
  for (const dist of preview.distributions) {
    console.log(`  ${dist.role}:`);
    console.log(`    Address: ${dist.address}`);
    console.log(`    Weight: ${dist.weight / 100}%`);
    console.log(`    BTC: ${Number(dist.btcAmount) / 100_000_000}`);
    console.log(`    Tokens: ${Number(dist.tokenAmount) / 1e18}`);
  }
  console.log('');

  // Deposit BTC to reserve (simulating initial funding)
  depositBTC(10000000n as Satoshi); // 0.1 BTC initial reserve
  console.log('=== Reserve State Before Closure ===');
  const reserveBefore = getReserveState();
  console.log(`Total BTC: ${Number(reserveBefore.totalBTC) / 100_000_000}`);
  console.log(`Floor Price: ${Number(reserveBefore.floorPrice) / 100_000_000} BTC per token`);
  console.log('');

  // Create sponsor signature
  const sponsorSig = createClosureSignature(
    sponsorAddress,
    tx.id,
    tx.chainMerkleRoot!,
    paymentAmount,
    sponsorKeys.privateKey
  );

  // Close TX
  console.log('=== Closing TX ===');
  const closureResult = await processClosure(tx, {
    txId: tx.id,
    sponsor: sponsorAddress,
    sponsorSignature: sponsorSig,
    paymentAmount
  });

  if (!closureResult.success) {
    console.error('Closure failed:', closureResult.error);
    return;
  }

  console.log(`Closure successful!`);
  console.log(`New TX State: ${closureResult.tx!.state}`);
  console.log('');

  // Mint tokens
  console.log('=== Minting Tokens ===');
  const issuance = await mintTokens(tx.id, closureResult.distribution!);
  console.log(`Issuance ID: ${issuance.id}`);
  console.log(`Total Minted: ${Number(issuance.amount) / 1e18} tokens`);
  console.log('');

  // Update reputation profiles
  console.log('=== Updating Reputation ===');
  for (const dist of closureResult.distribution!) {
    const profile = updateProfileFromClosure(dist);
    console.log(`${dist.role}:`);
    console.log(`  Closed TX Count: ${profile.closedTXCount}`);
    console.log(`  Reputation Score: ${profile.reputationScore}`);
  }
  console.log('');

  // Check reserve after
  console.log('=== Reserve State After Closure ===');
  const reserveAfter = getReserveState();
  console.log(`Total BTC: ${Number(reserveAfter.totalBTC) / 100_000_000}`);
  console.log(`Total Token Supply: ${Number(reserveAfter.totalTokenSupply) / 1e18}`);
  console.log(`Floor Price: ${Number(reserveAfter.floorPrice) / 100_000_000} BTC per token`);

  console.log('\n=== Example Complete ===');
}

main().catch(console.error);
