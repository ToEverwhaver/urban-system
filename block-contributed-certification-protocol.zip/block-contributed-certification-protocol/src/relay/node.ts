import { RelayNode, NodeStatus, RegisterNodeParams, Heartbeat, NodeMetrics } from '../types/node';
import { Hash, Address, Satoshi, Timestamp, HexString } from '../types/common';
import { hash } from '../crypto/hash';
import { PROTOCOL_CONSTANTS } from '../constants';

const nodes = new Map<Hash, RelayNode>();

/**
 * Register a new relay node
 */
export function registerNode(params: RegisterNodeParams): RelayNode {
  const now = Date.now() as Timestamp;
  const id = hash(`node:${params.operator}:${now}`) as Hash;

  if (params.stake < PROTOCOL_CONSTANTS.MIN_NODE_STAKE) {
    throw new Error(`Minimum stake required: ${PROTOCOL_CONSTANTS.MIN_NODE_STAKE}`);
  }

  const node: RelayNode = {
    id,
    operator: params.operator,
    publicKey: params.publicKey,
    endpoint: params.endpoint,
    stake: params.stake,
    score: 50,
    uptimeScore: 100,
    latencyScore: 100,
    honestyScore: 100,
    totalRelays: 0,
    successfulRelays: 0,
    failedRelays: 0,
    status: NodeStatus.Pending,
    registeredAt: now,
    lastHeartbeat: now,
    lastScoreUpdate: now
  };

  nodes.set(id, node);
  return node;
}

/**
 * Activate a pending node
 */
export function activateNode(nodeId: Hash): RelayNode {
  const node = nodes.get(nodeId);
  if (!node) throw new Error('Node not found');
  if (node.status !== NodeStatus.Pending) {
    throw new Error(`Cannot activate node in status: ${node.status}`);
  }

  node.status = NodeStatus.Active;
  nodes.set(nodeId, node);
  return node;
}

/**
 * Process heartbeat from node
 */
export function processHeartbeat(heartbeat: Heartbeat): RelayNode {
  const node = nodes.get(heartbeat.nodeId);
  if (!node) throw new Error('Node not found');

  const now = Date.now() as Timestamp;

  node.latencyScore = Math.max(0, 100 - Math.floor(heartbeat.metrics.latencyAvg / 5));

  const interval = PROTOCOL_CONSTANTS.HEARTBEAT_INTERVAL;
  const missed = Math.floor((heartbeat.timestamp - node.lastHeartbeat) / interval) - 1;
  node.uptimeScore = Math.max(0, node.uptimeScore - missed * 5);

  node.lastHeartbeat = now;
  node.score = calculateNodeScore(node);
  node.lastScoreUpdate = now;

  if (node.status === NodeStatus.Inactive && heartbeat.metrics.uptime > 0) {
    node.status = NodeStatus.Active;
  }

  nodes.set(node.id, node);
  return node;
}

/**
 * Calculate overall node score
 */
function calculateNodeScore(node: RelayNode): number {
  const weights = PROTOCOL_CONSTANTS.NODE_SCORE_WEIGHTS;
  return Math.floor(
    weights.uptime * node.uptimeScore +
    weights.latency * node.latencyScore +
    weights.honesty * node.honestyScore
  );
}

/**
 * Deactivate a node
 */
export function deactivateNode(nodeId: Hash): RelayNode {
  const node = nodes.get(nodeId);
  if (!node) throw new Error('Node not found');
  node.status = NodeStatus.Inactive;
  nodes.set(nodeId, node);
  return node;
}

/**
 * Record a relay operation
 */
export function recordRelay(nodeId: Hash, success: boolean): RelayNode {
  const node = nodes.get(nodeId);
  if (!node) throw new Error('Node not found');

  node.totalRelays += 1;
  if (success) {
    node.successfulRelays += 1;
  } else {
    node.failedRelays += 1;
  }

  node.honestyScore = Math.floor((node.successfulRelays / node.totalRelays) * 100);
  node.score = calculateNodeScore(node);
  node.lastScoreUpdate = Date.now() as Timestamp;

  nodes.set(nodeId, node);
  return node;
}

/**
 * Get node by ID
 */
export function getNode(nodeId: Hash): RelayNode | undefined {
  return nodes.get(nodeId);
}

/**
 * Get all active nodes
 */
export function getActiveNodes(): RelayNode[] {
  return Array.from(nodes.values()).filter(n => n.status === NodeStatus.Active);
}

/**
 * Get nodes by operator
 */
export function getNodesByOperator(operator: Address): RelayNode[] {
  return Array.from(nodes.values()).filter(n => n.operator === operator);
}

/**
 * Get all nodes
 */
export function getAllNodes(): RelayNode[] {
  return Array.from(nodes.values());
}

/**
 * Get nodes by status
 */
export function getNodesByStatus(status: NodeStatus): RelayNode[] {
  return Array.from(nodes.values()).filter(n => n.status === status);
}

/**
 * Update node stake
 */
export function updateStake(nodeId: Hash, newStake: Satoshi): RelayNode {
  const node = nodes.get(nodeId);
  if (!node) throw new Error('Node not found');

  if (newStake < PROTOCOL_CONSTANTS.MIN_NODE_STAKE) {
    throw new Error(`Stake below minimum: ${PROTOCOL_CONSTANTS.MIN_NODE_STAKE}`);
  }

  node.stake = newStake;
  nodes.set(nodeId, node);
  return node;
}

/**
 * Get node count
 */
export function getNodeCount(): { total: number; active: number; pending: number } {
  const all = Array.from(nodes.values());
  return {
    total: all.length,
    active: all.filter(n => n.status === NodeStatus.Active).length,
    pending: all.filter(n => n.status === NodeStatus.Pending).length
  };
}

/**
 * Clear all nodes (for testing)
 */
export function clearNodes(): void {
  nodes.clear();
}
