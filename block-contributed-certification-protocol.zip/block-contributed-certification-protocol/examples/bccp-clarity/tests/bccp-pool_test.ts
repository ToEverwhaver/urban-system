import {
  Clarinet,
  Tx,
  Chain,
  Account,
  types,
} from "https://deno.land/x/clarinet@v1.7.1/index.ts";
import { assertEquals } from "https://deno.land/std@0.170.0/testing/asserts.ts";

// ============================================
// Pool Balance Tests
// ============================================

Clarinet.test({
  name: "get-pool-balance: Returns zero initially",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn(
      "bccp-pool",
      "get-pool-balance",
      [],
      deployer.address
    );

    assertEquals(result.result, "(ok u0)");
  },
});

// ============================================
// Add to Pool Tests
// ============================================

Clarinet.test({
  name: "add-to-pool: Successfully adds STX (converted to BCCP)",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    // Authorize deployer
    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    // Add to pool
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "add-to-pool",
        [types.uint(1000000)], // 1 STX
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    // Check balance (should be 100 BCCP tokens at default rate)
    const balance = chain.callReadOnlyFn(
      "bccp-pool",
      "get-pool-balance",
      [],
      deployer.address
    );

    // 1 STX * 100 conversion rate = 100,000,000 BCCP (with decimals)
    assertEquals(balance.result, "(ok u100000000)");
  },
});

Clarinet.test({
  name: "add-to-pool: Unauthorized caller fails",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "add-to-pool",
        [types.uint(1000000)],
        alice.address // Not authorized
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

Clarinet.test({
  name: "add-to-pool: Zero amount fails",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "add-to-pool",
        [types.uint(0)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Add BCCP to Pool Tests
// ============================================

Clarinet.test({
  name: "add-bccp-to-pool: Successfully adds BCCP directly",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "add-bccp-to-pool",
        [types.uint(5000000)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const balance = chain.callReadOnlyFn(
      "bccp-pool",
      "get-pool-balance",
      [],
      deployer.address
    );

    assertEquals(balance.result, "(ok u5000000)");
  },
});

// ============================================
// Record Forfeiture Tests
// ============================================

Clarinet.test({
  name: "record-forfeiture: Successfully records and adds to pool",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "record-forfeiture",
        [
          types.uint(1),        // tx-id
          types.uint(2000000),  // total amount
          types.uint(1000000),  // from-a
          types.uint(1000000)   // from-b
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    // Check total forfeited
    const forfeited = chain.callReadOnlyFn(
      "bccp-pool",
      "get-total-forfeited",
      [],
      deployer.address
    );

    // 2 STX * 100 rate = 200,000,000
    assertEquals(forfeited.result, "u200000000");
  },
});

Clarinet.test({
  name: "record-forfeiture: Fails if amounts don't match",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "record-forfeiture",
        [
          types.uint(1),
          types.uint(2000000),
          types.uint(1000000),
          types.uint(500000) // Doesn't add up to 2000000
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Conversion Rate Tests
// ============================================

Clarinet.test({
  name: "get-conversion-rate: Returns default rate",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const result = chain.callReadOnlyFn(
      "bccp-pool",
      "get-conversion-rate",
      [],
      deployer.address
    );

    assertEquals(result.result, "u100");
  },
});

Clarinet.test({
  name: "set-conversion-rate: Owner can update",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "set-conversion-rate",
        [types.uint(200)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const rate = chain.callReadOnlyFn(
      "bccp-pool",
      "get-conversion-rate",
      [],
      deployer.address
    );

    assertEquals(rate.result, "u200");
  },
});

Clarinet.test({
  name: "set-conversion-rate: Non-owner cannot update",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "set-conversion-rate",
        [types.uint(200)],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Pool Statistics Tests
// ============================================

Clarinet.test({
  name: "get-pool-stats: Returns correct statistics",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    // Add some funds
    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "add-to-pool",
        [types.uint(1000000)],
        deployer.address
      ),
    ]);

    const stats = chain.callReadOnlyFn(
      "bccp-pool",
      "get-pool-stats",
      [],
      deployer.address
    );

    assertEquals(stats.result.includes("balance: u100000000"), true);
    assertEquals(stats.result.includes("total-forfeited: u100000000"), true);
    assertEquals(stats.result.includes("conversion-rate: u100"), true);
  },
});

// ============================================
// Authorization Tests
// ============================================

Clarinet.test({
  name: "authorize-caller: Owner can authorize",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(alice.address)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const isAuth = chain.callReadOnlyFn(
      "bccp-pool",
      "is-caller-authorized",
      [types.principal(alice.address)],
      deployer.address
    );

    assertEquals(isAuth.result, "true");
  },
});

Clarinet.test({
  name: "revoke-caller: Owner can revoke",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    // Authorize first
    chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(alice.address)],
        deployer.address
      ),
    ]);

    // Then revoke
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "revoke-caller",
        [types.principal(alice.address)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const isAuth = chain.callReadOnlyFn(
      "bccp-pool",
      "is-caller-authorized",
      [types.principal(alice.address)],
      deployer.address
    );

    assertEquals(isAuth.result, "false");
  },
});

Clarinet.test({
  name: "authorize-caller: Non-owner cannot authorize",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-pool",
        "authorize-caller",
        [types.principal(bob.address)],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});
