# BCCP - Blockchain Certified Contribution Protocol v2.0

A comprehensive protocol for certifying and rewarding contributions through blockchain-based signature chains.

## Overview

BCCP (Blockchain Certified Contribution Protocol) is a decentralized protocol that enables transparent tracking, certification, and reward distribution for collaborative contributions. The protocol uses cryptographic signatures to create immutable chains of contribution records.

### Key Features

- **Signature-Based Trust**: All protocol decisions are based solely on cryptographic signatures
- **Immutable Records**: Once signed, contributions cannot be revoked or modified
- **Fair Responsibility Distribution**: Two-layer responsibility system (financial and ethical)
- **On-Chain Portfolio**: Permanent, public record of all participations
- **Stake System**: Financial commitment from initiators and receivers
- **SIP-010 Compliant Token**: Native protocol token on Stacks blockchain

### Core Principle

```
NO Sponsor Closure = NO Value Created
```

Value is only generated when a Sponsor cryptographically closes a TX chain, eliminating:
- Impression fraud (ads counted but never acted upon)
- Last-click attribution manipulation
- Unpaid volunteer labor in privacy networks

## Architecture

BCCP v2 provides two implementations:

| Component | Language | Purpose |
|-----------|----------|---------|
| TypeScript SDK | TypeScript | Off-chain operations, API, client library |
| Clarity Contracts | Clarity | On-chain smart contracts on Stacks blockchain |

## Protocol Specification

### Chain Structure

```
A → B → C → D → ... → Closure Declaration → S (Sponsor)
```

| Property | Specification |
|----------|---------------|
| Minimum Length | A → B (2 participants) |
| Maximum Length | Unlimited |
| Same Person Multiple Participation | Allowed (A = C is valid) |

### Signature Types

| Type | Signers | Meaning |
|------|---------|---------|
| Chain Signature | A, B, C, D, ... | "I accept previous work and declare my responsibility" |
| Closure Declaration | Anyone | "This TX is complete, seeking sponsors" |
| Sponsor Signature | Sponsor (S) | "I purchase this completed work" + payment |

### TX States

```
Open (In Progress)
    │
    ├─→ Closure Declaration → Open + Seeking Sponsors
    │                              │
    │                              ├─→ Sponsor Signature → Closed
    │                              │
    │                              └─→ Timeout → Expired
    │
    └─→ Rejection → Rejected
```

### Stake System

| Participant | Stake Required |
|-------------|----------------|
| A (Initiator) | Yes |
| B (Receiver) | Yes |
| C onwards | No |

| TX Result | Stake Processing |
|-----------|------------------|
| Closed | Returned + Rewards |
| Expired | Returned (No Penalty) |
| Rejected | Forfeited based on responsibility ratio |

### Responsibility Distribution

**Core Principle:** "Who approved, not who created"

**Two-Layer Structure (Independent):**

| Type | Target | Distribution | Description |
|------|--------|--------------|-------------|
| Financial | A, B only | Always 50% / 50% | Stake forfeiture (independent of chain length) |
| Ethical | Rejected + Previous | 51% / 49% | Portfolio record |

**Ethical Responsibility Rules:**

| Chain Length | Rejected Party (n-2) | Previous Party (n-3) | Rejector (n-1) | Others |
|--------------|---------------------|---------------------|----------------|--------|
| 2 (A→B rejects) | A: 100% | N/A | B: 0% | N/A |
| 3+ (e.g., E rejects) | D: 51% | C: 49% | E: 0% | 0% |

**Key Rules:**
- Rejector always gets 0% (absolute rule - no reward, no responsibility)
- Financial and ethical responsibilities are calculated independently
- Only the last two parties before rejector bear ethical responsibility

## Project Structure

```
BCCP/
├── src/                          # TypeScript SDK Source
│   ├── api/                      # REST API endpoints
│   │   ├── closure-api.ts        # Closure workflow API
│   │   ├── node-api.ts           # Node management API
│   │   └── tx-api.ts             # Transaction API
│   ├── closure/                  # TX closure and distribution
│   │   ├── distribution.ts       # Reward distribution logic
│   │   └── processor.ts          # Closure processing
│   ├── crypto/                   # Cryptographic utilities
│   │   ├── hash.ts               # SHA3-256 hashing
│   │   ├── merkle.ts             # Merkle tree operations
│   │   ├── signature.ts          # ECDSA secp256k1 signing
│   │   └── uuid.ts               # UUID v7 generation
│   ├── relay/                    # Node relay system
│   │   ├── node.ts               # Node registration
│   │   ├── scoring.ts            # Node scoring
│   │   ├── selector.ts           # Route selection
│   │   └── slashing.ts           # Slashing mechanism
│   ├── reputation/               # Reputation calculation
│   │   ├── calculator.ts         # Score calculation
│   │   └── profile.ts            # User profiles
│   ├── signature/                # Signature protocol
│   │   ├── protocol.ts           # Signature creation
│   │   └── verifier.ts           # Signature verification
│   ├── storage/                  # Data storage interfaces
│   │   ├── interface.ts          # Storage interface
│   │   └── memory.ts             # In-memory implementation
│   ├── token/                    # Token economics
│   │   ├── calculator.ts         # Token calculations
│   │   ├── forfeit.ts            # Forfeit processing
│   │   ├── minter.ts             # Token minting
│   │   └── reserve.ts            # BTC reserve management
│   ├── tx/                       # Transaction management
│   │   ├── builder.ts            # Fluent TX builder
│   │   ├── chain.ts              # Chain management
│   │   └── validator.ts          # TX validation
│   ├── types/                    # TypeScript type definitions
│   │   ├── common.ts             # Common types
│   │   ├── contributor.ts        # Contributor types
│   │   ├── node.ts               # Node types
│   │   ├── signature.ts          # Signature types
│   │   ├── token.ts              # Token types
│   │   └── tx.ts                 # Transaction types
│   ├── utils/                    # Utility functions
│   │   ├── errors.ts             # Error definitions
│   │   └── validation.ts         # Validation schemas
│   ├── constants.ts              # Protocol constants
│   └── index.ts                  # Main exports
├── tests/                        # TypeScript test suite (173 tests)
│   ├── closure/                  # Closure tests
│   ├── crypto/                   # Crypto tests
│   ├── integration/              # Integration tests
│   ├── signature/                # Signature tests
│   ├── token/                    # Token tests
│   └── tx/                       # TX tests
├── examples/                     # Usage examples
│   ├── create-tx.ts              # TX creation example
│   ├── close-tx.ts               # TX closure example
│   └── run-node.ts               # Node operation example
├── bccp-clarity/                 # Clarity Smart Contracts
│   ├── contracts/
│   │   ├── bccp-traits.clar      # Trait definitions (SIP-010, core, stake, portfolio, pool)
│   │   ├── bccp-token.clar       # SIP-010 compliant BCCP token
│   │   ├── bccp-pool.clar        # Forfeiture pool management
│   │   ├── bccp-portfolio.clar   # Portfolio records
│   │   ├── bccp-stake.clar       # Stake management
│   │   └── bccp-core.clar        # Core TX logic
│   ├── tests/                    # Clarity tests (50+ tests)
│   │   ├── bccp-core_test.ts
│   │   ├── bccp-token_test.ts
│   │   ├── bccp-stake_test.ts
│   │   ├── bccp-portfolio_test.ts
│   │   └── bccp-pool_test.ts
│   ├── settings/
│   │   └── Devnet.toml           # Devnet configuration
│   └── Clarinet.toml             # Project configuration
└── docs/                         # Specification documents
    ├── BCCP_FULL_DEVELOPMENT_SPEC.md
    ├── BCCP_README_v2.md
    └── bccp-core-rules-v2.md
```

## Installation

### TypeScript SDK

```bash
# Clone the repository
git clone https://github.com/ToEverwhaver/BCCP.git
cd BCCP

# Install dependencies
npm install

# Build
npm run build

# Run tests
npm test
```

### Clarity Contracts

```bash
# Install Clarinet (https://github.com/hirosystems/clarinet)
brew install clarinet  # macOS
# or
curl -L https://github.com/hirosystems/clarinet/releases/download/v1.7.1/clarinet-linux-x64.tar.gz | tar xz

# Navigate to Clarity project
cd bccp-clarity

# Check contracts
clarinet check

# Run tests
clarinet test

# Start local devnet
clarinet integrate
```

## Usage

### TypeScript SDK

#### Creating a Transaction

```typescript
import {
  txBuilder,
  generateKeyPair,
  privateKeyToAddress,
  createSignaturePair,
  hash,
  Role,
  BasisPoints,
  Hash
} from 'bccp-protocol';

// Generate participant keys
const initiatorKeys = generateKeyPair();
const receiverKeys = generateKeyPair();

const initiatorAddress = privateKeyToAddress(initiatorKeys.privateKey);
const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);

// Create asset hash
const assetHash = hash('Original content') as Hash;
const receiverContent = hash('Processed content') as Hash;

// Create signature pair
const sigPair = createSignaturePair(
  { address: initiatorAddress, privateKey: initiatorKeys.privateKey },
  { address: receiverAddress, privateKey: receiverKeys.privateKey },
  receiverContent,
  assetHash,
  Role.Receiver
);

// Build TX
const tx = txBuilder({
  assetHash,
  assetType: 'article',
  initiator: initiatorAddress
})
  .addReceiver(receiverAddress, sigPair, receiverContent, 4000 as BasisPoints)
  .setWeight(initiatorAddress, 6000 as BasisPoints)
  .build();
```

#### Closing a Transaction

```typescript
import {
  processClosure,
  previewDistribution,
  mintTokens,
  createClosureSignature,
  Satoshi
} from 'bccp-protocol';

// Preview distribution
const payment = 1000000n as Satoshi; // 0.01 BTC
const preview = previewDistribution(tx, payment);

console.log(`Protocol Fee: ${preview.protocolFee}`);
console.log(`BTC to distribute: ${preview.totalBTC}`);
console.log(`Tokens to mint: ${preview.totalTokens}`);

// Create sponsor signature
const sponsorSig = createClosureSignature(
  sponsorAddress,
  tx.id,
  tx.chainMerkleRoot!,
  payment,
  sponsorKeys.privateKey
);

// Process closure
const result = await processClosure(tx, {
  txId: tx.id,
  sponsor: sponsorAddress,
  sponsorSignature: sponsorSig,
  paymentAmount: payment
});

// Mint tokens
if (result.success) {
  await mintTokens(tx.id, result.distribution!);
}
```

### Clarity Contracts

#### Creating a TX (On-Chain)

```clarity
;; Create a new TX with content hash
(contract-call? .bccp-core create-tx 0x1234567890abcdef...)

;; Accept as receiver (B)
(contract-call? .bccp-core accept-as-receiver u1)

;; Add next participant (C onwards)
(contract-call? .bccp-core add-participant u1 'ST1PQHQKV0RJXZFY1DGX8MNSNYVE3VGZJSRTPGZGM)
```

#### Staking

```clarity
;; Deposit stake (A or B only, minimum 1 STX)
(contract-call? .bccp-stake deposit-stake u1 u1000000)

;; Check stake status
(contract-call? .bccp-stake get-tx-stake-summary u1)

;; Check if both parties have staked
(contract-call? .bccp-stake has-both-stakes u1)
```

#### Closure and Sponsoring

```clarity
;; Declare closure ready (anyone can do this)
(contract-call? .bccp-core declare-closure-ready u1)

;; Sponsor and close (pay and finalize)
(contract-call? .bccp-core sponsor-close u1 u10000000)  ;; Pay 10 STX
```

#### Rejection

```clarity
;; Reject TX (only next expected participant can reject)
(contract-call? .bccp-core reject-tx u1)
```

## Smart Contract Reference

### bccp-core.clar

| Function | Description |
|----------|-------------|
| `create-tx` | Create a new TX with content hash |
| `accept-as-receiver` | Accept as receiver (B position) |
| `add-participant` | Add participant to chain (C onwards) |
| `reject-tx` | Reject TX (next participant only) |
| `declare-closure-ready` | Declare TX ready for sponsorship |
| `sponsor-close` | Pay and close TX |
| `expire-tx` | Mark TX as expired |
| `get-tx-info` | Get TX information |
| `get-tx-full` | Get full TX data |
| `get-chain-entry` | Get chain participant at position |

### bccp-token.clar (SIP-010 Compliant)

| Function | Description |
|----------|-------------|
| `transfer` | Transfer tokens |
| `get-balance` | Get balance of principal |
| `get-total-supply` | Get total supply |
| `get-name` | Get token name ("BCCP Token") |
| `get-symbol` | Get token symbol ("BCCP") |
| `get-decimals` | Get decimals (6) |
| `mint` | Mint new tokens (authorized only) |
| `burn` | Burn tokens |
| `set-allowance` | Set spending allowance |
| `transfer-from` | Transfer using allowance |

### bccp-stake.clar

| Function | Description |
|----------|-------------|
| `deposit-stake` | Deposit stake (A or B position) |
| `return-stakes` | Return stakes on successful close |
| `forfeit-stakes` | Forfeit stakes on rejection |
| `get-stake-info` | Get stake information |
| `get-tx-stake-summary` | Get TX stake summary |
| `has-both-stakes` | Check if both A and B have staked |

### bccp-portfolio.clar

| Function | Description |
|----------|-------------|
| `record-participation` | Record new participation |
| `record-rejection` | Record rejection responsibility |
| `record-closure` | Record successful closure |
| `record-expiration` | Record TX expiration |
| `get-portfolio-summary` | Get portfolio summary |
| `get-participation` | Get specific participation record |

### bccp-pool.clar

| Function | Description |
|----------|-------------|
| `add-to-pool` | Add forfeited STX (auto-converts to BCCP) |
| `add-bccp-to-pool` | Add BCCP directly to pool |
| `record-forfeiture` | Record forfeiture with breakdown |
| `get-pool-balance` | Get current pool balance |
| `distribute-from-pool` | Distribute from pool (governance) |
| `get-pool-stats` | Get pool statistics |

## Protocol Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `PROTOCOL_FEE_RATE` | 3% | Fee on closure payments |
| `BTC_DISTRIBUTION_RATIO` | 80% | Portion distributed as BTC |
| `TOKEN_DISTRIBUTION_RATIO` | 20% | Portion distributed as tokens |
| `MIN_NODE_STAKE` | 0.001 BTC | Minimum relay node stake |
| `DEFAULT_MIN_STAKE` | 1 STX | Default minimum stake (Clarity) |
| `DEFAULT_TIMEOUT_BLOCKS` | 1008 | ~7 days timeout |
| `CONVERSION_RATE` | 100 | 1 STX = 100 BCCP |

## Testing

### TypeScript Tests

```bash
# Run all tests
npm test

# Run specific test file
npm test -- tests/tx/chain.test.ts

# Run with coverage
npm test -- --coverage
```

**Test Coverage: 173 tests across 13 test files**

### Clarity Tests

```bash
cd bccp-clarity

# Run all tests
clarinet test

# Run specific test
clarinet test tests/bccp-core_test.ts

# Run with verbose output
clarinet test --verbose
```

**Test Coverage: 50+ tests across 5 test files**

## Deployment

### Local Development

```bash
cd bccp-clarity

# Start local devnet with all services
clarinet integrate

# This starts:
# - Bitcoin node (port 18443)
# - Stacks node (port 20443)
# - Stacks API (port 3999)
# - Explorer (port 3020)
```

### Testnet Deployment

```bash
cd bccp-clarity

# Generate deployment plan
clarinet deployments generate --testnet

# Review generated plan in deployments/default.testnet.yaml

# Deploy to testnet
clarinet deployments apply --testnet
```

### Mainnet Deployment

```bash
# Generate mainnet deployment
clarinet deployments generate --mainnet

# Review and verify deployment plan

# Apply (requires STX for transaction fees)
clarinet deployments apply --mainnet
```

## Token Economics

### Floor Price Guarantee

```
Floor Price = Total BTC Reserve / Circulating Token Supply
```

Tokens are always redeemable at floor price, providing downside protection.

### Forfeit Processing

| Strategy | Effect |
|----------|--------|
| **BURN_AND_BUY** | Burns tokens, adds BTC value to reserve, increases floor price |
| **AIRDROP** | Redistributes forfeited tokens to active holders |

## Reputation System

### Score Components (0-1000)

| Component | Max Points | Calculation |
|-----------|------------|-------------|
| Base | 500 | Starting score |
| Activity | +200 | `min(closedTXCount * 5, 200)` |
| Acceptance | +150 | `acceptRate * 150` |
| Diversity | +100 | `rolesUsed * 20` |
| Consistency | +50 | `min(txPerDay * 50, 50)` |

### Tiers

| Score | Tier |
|-------|------|
| 900+ | DIAMOND |
| 800-899 | PLATINUM |
| 700-799 | GOLD |
| 600-699 | SILVER |
| 0-599 | BRONZE |

## Protocol Boundaries

### Protocol Defines

- Signature verification and chain structure
- Stake requirements (A and B only)
- Responsibility distribution rules
- Portfolio recording requirements
- TX state transitions

### Implementation Defines (Not Protocol)

- Reward distribution percentages
- Price negotiation mechanisms
- Sponsor selection methods
- Timeout duration specifics
- UI/UX design
- Specific stake amounts

## Statistics

| Component | Files | Lines of Code |
|-----------|-------|---------------|
| TypeScript SDK | 52 | ~6,800 |
| TypeScript Tests | 13 | ~2,500 |
| Clarity Contracts | 6 | ~2,200 |
| Clarity Tests | 5 | ~2,200 |
| **Total** | **76** | **~13,700** |

## Error Handling

### TypeScript Errors

```typescript
import { BCCPError, SignatureError, ChainError, isBCCPError } from 'bccp-protocol';

try {
  // operation
} catch (error) {
  if (isBCCPError(error)) {
    console.log(error.code, error.message, error.details);
  }
}
```

### Clarity Errors

| Contract | Error Code | Description |
|----------|------------|-------------|
| bccp-core | u5001 | Not authorized |
| bccp-core | u5002 | Invalid TX |
| bccp-core | u5003 | Invalid state |
| bccp-core | u5004 | Not next participant |
| bccp-stake | u4001 | Not authorized |
| bccp-stake | u4002 | Invalid amount |
| bccp-stake | u4007 | Invalid position |
| bccp-token | u1001 | Not authorized |
| bccp-token | u1002 | Insufficient balance |

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Links

- [Core Rules v2](bccp-core-rules-v2.md)
- [Full Development Spec](BCCP_FULL_DEVELOPMENT_SPEC.md)
- [Stacks Documentation](https://docs.stacks.co/)
- [Clarity Language Reference](https://docs.stacks.co/clarity)
- [SIP-010 Standard](https://github.com/stacksgov/sips/blob/main/sips/sip-010/sip-010-fungible-token-standard.md)

---

**Version**: 2.0.0
**Last Updated**: 2025-12-14
**日本語版**: [README_ja.md](README_ja.md)
