import { ForfeitRecord, ForfeitAction } from '../types/token';
import { Address, TokenAmount, UUID, Timestamp, Hash } from '../types/common';
import { DistributionResult } from '../types/tx';
import { recordForfeit, getUnprocessedForfeits, processForfeits as processReserveForfeits } from './reserve';
import { getBalance, getTotalSupply } from './minter';
import { hash } from '../crypto/hash';

/**
 * Process forfeit decisions from distribution
 */
export function processForfeitDecisions(
  txId: UUID,
  distribution: DistributionResult[]
): ForfeitRecord[] {
  const records: ForfeitRecord[] = [];

  for (const result of distribution) {
    if (!result.tokenAccepted && result.forfeitedAmount && result.forfeitedAmount > 0n) {
      const record = recordForfeit(result.contributor, result.forfeitedAmount, txId);
      records.push(record);
    }
  }

  return records;
}

/**
 * Get forfeit statistics
 */
export function getForfeitStats(): {
  totalForfeited: TokenAmount;
  unprocessedCount: number;
  unprocessedAmount: TokenAmount;
  processedCount: number;
} {
  const unprocessed = getUnprocessedForfeits();
  const unprocessedAmount = unprocessed.reduce(
    (sum, r) => (sum + r.amount) as TokenAmount,
    0n as TokenAmount
  );

  return {
    totalForfeited: unprocessedAmount,
    unprocessedCount: unprocessed.length,
    unprocessedAmount,
    processedCount: 0
  };
}

/**
 * Execute batch forfeit processing
 */
export async function executeBatchProcessing(
  action: ForfeitAction,
  batchSize: number = 100
): Promise<{
  processed: number;
  totalAmount: TokenAmount;
}> {
  const unprocessed = getUnprocessedForfeits().slice(0, batchSize);
  if (unprocessed.length === 0) {
    return { processed: 0, totalAmount: 0n as TokenAmount };
  }

  const totalAmount = await processReserveForfeits(action);

  return {
    processed: unprocessed.length,
    totalAmount
  };
}

/**
 * Calculate airdrop distribution
 */
export function calculateAirdropDistribution(
  forfeitedAmount: TokenAmount,
  eligibleAddresses: Address[],
  weightByBalance: boolean = true
): Map<Address, TokenAmount> {
  const distribution = new Map<Address, TokenAmount>();

  if (eligibleAddresses.length === 0) {
    return distribution;
  }

  if (!weightByBalance) {
    const perAddress = forfeitedAmount / BigInt(eligibleAddresses.length);
    for (const address of eligibleAddresses) {
      distribution.set(address, perAddress as TokenAmount);
    }
    return distribution;
  }

  const balances = new Map<Address, TokenAmount>();
  let totalBalance = 0n;

  for (const address of eligibleAddresses) {
    const balance = getBalance(address);
    balances.set(address, balance);
    totalBalance += balance;
  }

  if (totalBalance === 0n) {
    const perAddress = forfeitedAmount / BigInt(eligibleAddresses.length);
    for (const address of eligibleAddresses) {
      distribution.set(address, perAddress as TokenAmount);
    }
    return distribution;
  }

  for (const [address, balance] of balances) {
    const share = (forfeitedAmount * balance) / totalBalance;
    distribution.set(address, share as TokenAmount);
  }

  return distribution;
}

/**
 * Simulate burn and buy effect
 */
export function simulateBurnAndBuy(
  forfeitedAmount: TokenAmount,
  currentBTCReserve: bigint,
  currentSupply: TokenAmount
): {
  newFloorPrice: bigint;
  btcAdded: bigint;
  supplyReduction: TokenAmount;
  floorPriceIncrease: number;
} {
  if (currentSupply === 0n) {
    return {
      newFloorPrice: 0n,
      btcAdded: 0n,
      supplyReduction: forfeitedAmount,
      floorPriceIncrease: 0
    };
  }

  const currentFloor = (currentBTCReserve * BigInt(10 ** 18)) / currentSupply;
  const btcValue = (forfeitedAmount * currentFloor) / BigInt(10 ** 18);

  const newBTC = currentBTCReserve + btcValue;
  const newSupply = (currentSupply - forfeitedAmount) as TokenAmount;

  const newFloor = newSupply === 0n ? 0n : (newBTC * BigInt(10 ** 18)) / newSupply;

  const increase = currentFloor === 0n
    ? 0
    : Number(newFloor - currentFloor) / Number(currentFloor);

  return {
    newFloorPrice: newFloor,
    btcAdded: btcValue,
    supplyReduction: forfeitedAmount,
    floorPriceIncrease: increase
  };
}

/**
 * Get recommended forfeit action
 */
export function getRecommendedAction(
  forfeitedAmount: TokenAmount,
  currentBTCReserve: bigint,
  currentSupply: TokenAmount,
  activeHolderCount: number
): {
  action: ForfeitAction;
  reason: string;
} {
  if (activeHolderCount < 10) {
    return {
      action: 'BURN_AND_BUY',
      reason: 'Low holder count makes airdrop inefficient'
    };
  }

  const simulation = simulateBurnAndBuy(
    forfeitedAmount,
    currentBTCReserve,
    currentSupply
  );

  if (simulation.floorPriceIncrease > 0.01) {
    return {
      action: 'BURN_AND_BUY',
      reason: 'Significant floor price improvement expected'
    };
  }

  return {
    action: 'AIRDROP',
    reason: 'Airdrop provides better holder distribution'
  };
}
