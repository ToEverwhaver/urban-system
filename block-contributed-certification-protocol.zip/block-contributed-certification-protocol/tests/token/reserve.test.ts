import {
  depositBTC,
  withdrawBTC,
  recordForfeit,
  processForfeits,
  calculateTokenBTCValue,
  getReserveState,
  getFloorPrice,
  getUnprocessedForfeits,
  getAllForfeits,
  getForfeitsByContributor,
  getReserveRatio,
  resetReserve
} from '../../src/token/reserve';
import { clearLedger, mintTokens } from '../../src/token/minter';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { DistributionResult } from '../../src/types/tx';
import { Role } from '../../src/types/contributor';
import { Address, BasisPoints, Satoshi, TokenAmount, UUID } from '../../src/types/common';
import { generateUUID } from '../../src/crypto/uuid';

describe('Token Reserve Module', () => {
  const keys1 = generateKeyPair();
  const address1 = privateKeyToAddress(keys1.privateKey);

  beforeEach(() => {
    resetReserve();
    clearLedger();
  });

  describe('depositBTC', () => {
    it('should increase reserve BTC', () => {
      const amount = 1000000n as Satoshi;

      const state = depositBTC(amount);

      expect(state.totalBTC).toBe(amount);
    });

    it('should accumulate deposits', () => {
      depositBTC(1000000n as Satoshi);
      const state = depositBTC(500000n as Satoshi);

      expect(state.totalBTC).toBe(1500000n);
    });
  });

  describe('withdrawBTC', () => {
    it('should decrease reserve BTC', () => {
      depositBTC(1000000n as Satoshi);

      const state = withdrawBTC(400000n as Satoshi);

      expect(state).not.toBeNull();
      expect(state!.totalBTC).toBe(600000n);
    });

    it('should return null for insufficient balance', () => {
      depositBTC(100000n as Satoshi);

      const state = withdrawBTC(200000n as Satoshi);

      expect(state).toBeNull();
    });
  });

  describe('recordForfeit', () => {
    it('should create forfeit record', () => {
      const txId = generateUUID() as UUID;
      const amount = 1000n as TokenAmount;

      const record = recordForfeit(address1, amount, txId);

      expect(record.contributor).toBe(address1);
      expect(record.amount).toBe(amount);
      expect(record.processed).toBe(false);
    });

    it('should add to forfeit pool', () => {
      const txId = generateUUID() as UUID;

      recordForfeit(address1, 1000n as TokenAmount, txId);

      const state = getReserveState();
      expect(state.forfeitPool).toBe(1000n);
    });
  });

  describe('processForfeits', () => {
    it('should process forfeits with BURN_AND_BUY', async () => {
      // First mint some tokens to establish supply
      const txId1 = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 10000n as TokenAmount,
          tokenAccepted: true
        }
      ];
      await mintTokens(txId1, distribution);

      // Deposit some BTC to establish reserve
      depositBTC(1000000n as Satoshi);

      // Record forfeit
      const txId2 = generateUUID() as UUID;
      recordForfeit(address1, 1000n as TokenAmount, txId2);

      const processed = await processForfeits('BURN_AND_BUY');

      expect(processed).toBe(1000n);
      expect(getReserveState().forfeitPool).toBe(0n);
    });

    it('should process forfeits with AIRDROP', async () => {
      const txId = generateUUID() as UUID;
      recordForfeit(address1, 1000n as TokenAmount, txId);

      const processed = await processForfeits('AIRDROP');

      expect(processed).toBe(1000n);
    });

    it('should return 0 when nothing to process', async () => {
      const processed = await processForfeits('BURN_AND_BUY');

      expect(processed).toBe(0n);
    });
  });

  describe('getReserveState', () => {
    it('should return current state', () => {
      depositBTC(500000n as Satoshi);

      const state = getReserveState();

      expect(state.totalBTC).toBe(500000n);
      expect(state.lastUpdated).toBeDefined();
    });
  });

  describe('getFloorPrice', () => {
    it('should return 0 for no supply', () => {
      depositBTC(1000000n as Satoshi);

      const floor = getFloorPrice();

      expect(floor).toBe(0n);
    });

    it('should calculate floor price with supply', async () => {
      depositBTC(1000000n as Satoshi);

      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount, // 1 token
          tokenAccepted: true
        }
      ];
      await mintTokens(txId, distribution);

      const floor = getFloorPrice();

      // Floor = totalBTC * 10^18 / supply
      expect(floor).toBeGreaterThan(0n);
    });
  });

  describe('getUnprocessedForfeits', () => {
    it('should return only unprocessed records', async () => {
      const txId1 = generateUUID() as UUID;
      const txId2 = generateUUID() as UUID;

      recordForfeit(address1, 1000n as TokenAmount, txId1);
      recordForfeit(address1, 500n as TokenAmount, txId2);

      await processForfeits('AIRDROP');

      recordForfeit(address1, 200n as TokenAmount, txId1);

      const unprocessed = getUnprocessedForfeits();

      expect(unprocessed).toHaveLength(1);
      expect(unprocessed[0].amount).toBe(200n);
    });
  });

  describe('getForfeitsByContributor', () => {
    it('should filter by contributor', () => {
      const keys2 = generateKeyPair();
      const address2 = privateKeyToAddress(keys2.privateKey);

      const txId = generateUUID() as UUID;

      recordForfeit(address1, 1000n as TokenAmount, txId);
      recordForfeit(address2, 500n as TokenAmount, txId);

      const forfeits = getForfeitsByContributor(address1);

      expect(forfeits).toHaveLength(1);
      expect(forfeits[0].contributor).toBe(address1);
    });
  });

  describe('calculateTokenBTCValue', () => {
    it('should calculate BTC value of tokens', async () => {
      depositBTC(1000000n as Satoshi);

      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];
      await mintTokens(txId, distribution);

      const value = calculateTokenBTCValue(500000000000000000n as TokenAmount);

      expect(value).toBeGreaterThan(0n);
    });
  });

  describe('getReserveRatio', () => {
    it('should return 0 for no supply', () => {
      const ratio = getReserveRatio(1000000n as Satoshi);

      expect(ratio).toBe(0);
    });

    it('should calculate ratio with supply', async () => {
      depositBTC(1000000n as Satoshi);

      const txId = generateUUID() as UUID;
      const distribution: DistributionResult[] = [
        {
          contributor: address1,
          role: Role.Initiator,
          weight: 10000 as BasisPoints,
          btcAmount: 1000000n as Satoshi,
          tokenAmount: 1000000000000000000n as TokenAmount,
          tokenAccepted: true
        }
      ];
      await mintTokens(txId, distribution);

      const ratio = getReserveRatio(1000000n as Satoshi);

      expect(ratio).toBeGreaterThan(0);
    });
  });
});
