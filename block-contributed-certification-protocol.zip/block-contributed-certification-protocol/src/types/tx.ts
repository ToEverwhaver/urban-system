import { Hash, UUID, Address, Timestamp, Satoshi, BasisPoints, TokenAmount } from './common';
import { Contributor, Role } from './contributor';
import { SignaturePair, ECDSASignature } from './signature';

// TX states
export enum TXState {
  Draft = 'DRAFT',
  Open = 'OPEN',
  PendingClosure = 'PENDING',
  Closed = 'CLOSED',
  Disputed = 'DISPUTED',
  Cancelled = 'CANCELLED'
}

// Single entry in TX chain
export interface TXChainEntry {
  contributor: Contributor;
  signaturePair: SignaturePair | null;  // null for initiator
  contentHash: Hash;
  metadata?: Record<string, string>;
}

// Main TX structure
export interface TX {
  id: UUID;

  // Asset info
  assetHash: Hash;
  assetType: string;
  assetMetadata?: Record<string, string>;

  // Chain of contributions
  chain: TXChainEntry[];

  // Weights (must sum to 10000)
  weights: Map<Address, BasisPoints>;

  // State
  state: TXState;

  // Timestamps
  createdAt: Timestamp;
  updatedAt: Timestamp;
  closedAt?: Timestamp;

  // Closure info
  closure?: TXClosure;

  // Merkle root of chain
  chainMerkleRoot?: Hash;
}

// Closure info
export interface TXClosure {
  sponsor: Address;
  sponsorSignature: ECDSASignature;
  paymentAmount: Satoshi;
  paymentTxHash?: Hash;
  closedAt: Timestamp;
  distribution: DistributionResult[];
}

// Distribution per contributor
export interface DistributionResult {
  contributor: Address;
  role: Role;
  weight: BasisPoints;
  btcAmount: Satoshi;
  tokenAmount: TokenAmount;
  tokenAccepted: boolean;
  forfeitedAmount?: TokenAmount;
}

// Creation params
export interface CreateTXParams {
  assetHash: Hash;
  assetType: string;
  assetMetadata?: Record<string, string>;
  initiator: Address;
  initialWeights?: Map<Address, BasisPoints>;
}

// TX summary for display
export interface TXSummary {
  id: UUID;
  state: TXState;
  contributorCount: number;
  totalWeight: number;
  createdAt: Timestamp;
  closedAt?: Timestamp;
  paymentAmount?: Satoshi;
}

export function getTXSummary(tx: TX): TXSummary {
  return {
    id: tx.id,
    state: tx.state,
    contributorCount: tx.chain.length,
    totalWeight: Array.from(tx.weights.values()).reduce((a, b) => a + b, 0),
    createdAt: tx.createdAt,
    closedAt: tx.closedAt,
    paymentAmount: tx.closure?.paymentAmount
  };
}
