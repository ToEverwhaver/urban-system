import { RelayNode, NodeMetrics } from '../types/node';
import { Hash, Timestamp, Address } from '../types/common';
import { getNode, getActiveNodes } from './node';
import { PROTOCOL_CONSTANTS } from '../constants';

export interface ScoreMeasurement {
  nodeId: Hash;
  timestamp: Timestamp;
  metrics: NodeMetrics;
  measurerNodeId: Hash;
}

export interface AggregatedScore {
  nodeId: Hash;
  score: number;
  measurements: number;
  timestamp: Timestamp;
  confidence: number;
}

const measurements = new Map<Hash, ScoreMeasurement[]>();

/**
 * Submit a measurement from another node
 */
export function submitMeasurement(m: ScoreMeasurement): void {
  const existing = measurements.get(m.nodeId) ?? [];
  measurements.set(m.nodeId, [...existing, m].slice(-100));
}

/**
 * Aggregate scores from multiple measurements
 */
export function aggregateScores(nodeId: Hash): AggregatedScore {
  const nodeMeasurements = measurements.get(nodeId) ?? [];
  const now = Date.now() as Timestamp;

  if (nodeMeasurements.length === 0) {
    return {
      nodeId,
      score: 50,
      measurements: 0,
      timestamp: now,
      confidence: 0
    };
  }

  const recentWindow = 60 * 60 * 1000;
  const recent = nodeMeasurements.filter(m => now - m.timestamp < recentWindow);

  if (recent.length === 0) {
    return {
      nodeId,
      score: 50,
      measurements: 0,
      timestamp: now,
      confidence: 0
    };
  }

  const avgLatency = recent.reduce((sum, m) => sum + m.metrics.latencyAvg, 0) / recent.length;
  const avgUptime = recent.reduce((sum, m) => sum + m.metrics.uptime, 0) / recent.length;

  const latencyScore = Math.max(0, 100 - Math.floor(avgLatency / 5));
  const uptimeScore = Math.min(100, Math.floor(avgUptime / 3600) * 10);

  const weights = PROTOCOL_CONSTANTS.NODE_SCORE_WEIGHTS;
  const score = Math.floor(
    weights.latency * latencyScore +
    weights.uptime * uptimeScore +
    weights.honesty * 100
  );

  const confidence = Math.min(recent.length / 10, 1);

  return {
    nodeId,
    score,
    measurements: recent.length,
    timestamp: now,
    confidence
  };
}

/**
 * Get scoring history for a node
 */
export function getScoringHistory(nodeId: Hash): ScoreMeasurement[] {
  return measurements.get(nodeId) ?? [];
}

/**
 * Calculate network-wide score distribution
 */
export function getScoreDistribution(): {
  avg: number;
  median: number;
  min: number;
  max: number;
  distribution: Map<number, number>;
} {
  const activeNodes = getActiveNodes();
  const scores = activeNodes.map(n => n.score).sort((a, b) => a - b);

  if (scores.length === 0) {
    return { avg: 0, median: 0, min: 0, max: 0, distribution: new Map() };
  }

  const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
  const median = scores[Math.floor(scores.length / 2)];
  const min = scores[0];
  const max = scores[scores.length - 1];

  const distribution = new Map<number, number>();
  for (let bucket = 0; bucket <= 100; bucket += 10) {
    const count = scores.filter(s => s >= bucket && s < bucket + 10).length;
    distribution.set(bucket, count);
  }

  return { avg, median, min, max, distribution };
}

/**
 * Rank nodes by score
 */
export function rankNodes(): Array<{ nodeId: Hash; rank: number; score: number }> {
  const activeNodes = getActiveNodes();
  return activeNodes
    .sort((a, b) => b.score - a.score)
    .map((node, index) => ({
      nodeId: node.id,
      rank: index + 1,
      score: node.score
    }));
}

/**
 * Get node percentile
 */
export function getNodePercentile(nodeId: Hash): number {
  const node = getNode(nodeId);
  if (!node) return 0;

  const activeNodes = getActiveNodes();
  const belowCount = activeNodes.filter(n => n.score < node.score).length;

  return (belowCount / activeNodes.length) * 100;
}

/**
 * Identify underperforming nodes
 */
export function getUnderperformingNodes(threshold: number = 30): RelayNode[] {
  return getActiveNodes().filter(n => n.score < threshold);
}

/**
 * Calculate measurement agreement
 */
export function calculateMeasurementAgreement(nodeId: Hash): number {
  const nodeMeasurements = measurements.get(nodeId) ?? [];
  if (nodeMeasurements.length < 2) return 1;

  const latencies = nodeMeasurements.map(m => m.metrics.latencyAvg);
  const avg = latencies.reduce((a, b) => a + b, 0) / latencies.length;
  const variance = latencies.reduce((sum, l) => sum + Math.pow(l - avg, 2), 0) / latencies.length;
  const stdDev = Math.sqrt(variance);

  const coefficientOfVariation = avg > 0 ? stdDev / avg : 0;
  return Math.max(0, 1 - coefficientOfVariation);
}

/**
 * Clear measurements (for testing)
 */
export function clearMeasurements(): void {
  measurements.clear();
}
