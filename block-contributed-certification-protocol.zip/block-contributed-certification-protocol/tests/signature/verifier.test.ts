import {
  verifyOutboundSignature,
  verifyCounterSignature,
  verifySignaturePair,
  verifyTimestamp,
  verifySignaturePairTimestamps,
  verifySignaturePairFull,
  verifySignatureChain,
  extractChainAddresses
} from '../../src/signature/verifier';
import {
  createOutboundSignature,
  createCounterSignature,
  createSignaturePair
} from '../../src/signature/protocol';
import { generateKeyPair, privateKeyToAddress } from '../../src/crypto/signature';
import { hash } from '../../src/crypto/hash';
import { Role } from '../../src/types/contributor';
import { Hash, Address, Timestamp } from '../../src/types/common';

describe('Signature Verifier Module', () => {
  const senderKeys = generateKeyPair();
  const receiverKeys = generateKeyPair();
  const thirdPartyKeys = generateKeyPair();

  const senderAddress = privateKeyToAddress(senderKeys.privateKey);
  const receiverAddress = privateKeyToAddress(receiverKeys.privateKey);
  const thirdPartyAddress = privateKeyToAddress(thirdPartyKeys.privateKey);

  const contentHash = hash('test-content') as Hash;
  const previousHash = hash('previous') as Hash;

  describe('verifyOutboundSignature', () => {
    it('should verify valid outbound signature', () => {
      const sig = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const result = verifyOutboundSignature(sig);

      expect(result.valid).toBe(true);
      expect(result.recoveredAddress).toBe(senderAddress);
    });

    it('should verify with expected address', () => {
      const sig = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const result = verifyOutboundSignature(sig, senderAddress);

      expect(result.valid).toBe(true);
    });

    it('should fail for wrong expected address', () => {
      const sig = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const result = verifyOutboundSignature(sig, receiverAddress);

      expect(result.valid).toBe(false);
    });
  });

  describe('verifyCounterSignature', () => {
    it('should verify valid counter signature', () => {
      const outbound = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const counter = createCounterSignature(
        receiverAddress,
        outbound,
        true,
        receiverKeys.privateKey
      );

      const result = verifyCounterSignature(counter);

      expect(result.valid).toBe(true);
      expect(result.recoveredAddress).toBe(receiverAddress);
    });
  });

  describe('verifySignaturePair', () => {
    it('should verify valid signature pair', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      const result = verifySignaturePair(pair);

      expect(result.valid).toBe(true);
    });

    it('should verify with expected addresses', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      const result = verifySignaturePair(pair, senderAddress, receiverAddress);

      expect(result.valid).toBe(true);
    });

    it('should fail for tampered outbound hash', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      // Tamper with the outbound signature hash reference
      const tamperedPair = {
        ...pair,
        counter: {
          ...pair.counter,
          outboundSignatureHash: hash('wrong') as Hash
        }
      };

      const result = verifySignaturePair(tamperedPair);

      expect(result.valid).toBe(false);
      // When the outbound hash is tampered, the counter signature verification fails
      // because the signature was made with the original hash
      expect(result.error).toBeDefined();
    });
  });

  describe('verifyTimestamp', () => {
    it('should validate recent timestamp', () => {
      const now = Date.now() as Timestamp;
      const result = verifyTimestamp(now);

      expect(result).toBe(true);
    });

    it('should reject old timestamp', () => {
      const oldTs = (Date.now() - 100000000) as Timestamp;
      const result = verifyTimestamp(oldTs, 1000);

      expect(result).toBe(false);
    });

    it('should reject future timestamp', () => {
      const futureTs = (Date.now() + 100000) as Timestamp;
      const result = verifyTimestamp(futureTs);

      expect(result).toBe(false);
    });
  });

  describe('verifySignaturePairTimestamps', () => {
    it('should validate fresh signature pair', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      const result = verifySignaturePairTimestamps(pair);

      expect(result.valid).toBe(true);
    });

    it('should fail if counter precedes outbound', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      const tamperedPair = {
        ...pair,
        counter: {
          ...pair.counter,
          timestamp: (pair.outbound.timestamp - 1000) as Timestamp
        }
      };

      const result = verifySignaturePairTimestamps(tamperedPair);

      expect(result.valid).toBe(false);
      expect(result.error).toContain('precede');
    });
  });

  describe('verifySignaturePairFull', () => {
    it('should perform full verification', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      const result = verifySignaturePairFull(pair);

      expect(result.valid).toBe(true);
    });

    it('should fail if responsibility not accepted', () => {
      const outbound = createOutboundSignature(
        senderAddress,
        receiverAddress,
        contentHash,
        previousHash,
        Role.Receiver,
        senderKeys.privateKey
      );

      const counter = createCounterSignature(
        receiverAddress,
        outbound,
        false,
        receiverKeys.privateKey
      );

      const pair = { outbound, counter };

      const result = verifySignaturePairFull(pair);

      expect(result.valid).toBe(false);
      expect(result.error).toContain('Responsibility not accepted');
    });

    it('should skip timestamp check when disabled', () => {
      const pair = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        previousHash,
        Role.Receiver
      );

      // Even with old timestamps, should pass if check disabled
      const result = verifySignaturePairFull(pair, undefined, undefined, false);

      expect(result.valid).toBe(true);
    });
  });

  describe('verifySignatureChain', () => {
    it('should verify valid chain', () => {
      const pair1 = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        null,
        Role.Receiver
      );

      const pair2 = createSignaturePair(
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        { address: thirdPartyAddress, privateKey: thirdPartyKeys.privateKey },
        hash('content-2') as Hash,
        contentHash,
        Role.Producer
      );

      const result = verifySignatureChain([pair1, pair2], senderAddress);

      expect(result.valid).toBe(true);
    });

    it('should fail for broken chain', () => {
      const pair1 = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        null,
        Role.Receiver
      );

      // Second pair starts from wrong address (should be receiverAddress)
      const pair2 = createSignaturePair(
        { address: thirdPartyAddress, privateKey: thirdPartyKeys.privateKey },
        { address: senderAddress, privateKey: senderKeys.privateKey },
        hash('content-2') as Hash,
        contentHash,
        Role.Producer
      );

      const result = verifySignatureChain([pair1, pair2], senderAddress);

      expect(result.valid).toBe(false);
      expect(result.error).toContain('Chain broken');
    });
  });

  describe('extractChainAddresses', () => {
    it('should extract all addresses from chain', () => {
      const pair1 = createSignaturePair(
        { address: senderAddress, privateKey: senderKeys.privateKey },
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        contentHash,
        null,
        Role.Receiver
      );

      const pair2 = createSignaturePair(
        { address: receiverAddress, privateKey: receiverKeys.privateKey },
        { address: thirdPartyAddress, privateKey: thirdPartyKeys.privateKey },
        hash('content-2') as Hash,
        contentHash,
        Role.Producer
      );

      const addresses = extractChainAddresses([pair1, pair2]);

      expect(addresses).toHaveLength(3);
      expect(addresses[0]).toBe(senderAddress);
      expect(addresses[1]).toBe(receiverAddress);
      expect(addresses[2]).toBe(thirdPartyAddress);
    });

    it('should return empty array for empty chain', () => {
      const addresses = extractChainAddresses([]);

      expect(addresses).toHaveLength(0);
    });
  });
});
