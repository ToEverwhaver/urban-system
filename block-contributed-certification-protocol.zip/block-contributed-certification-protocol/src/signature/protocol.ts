import {
  OutboundSignature,
  CounterSignature,
  SignaturePair,
  EIP712Domain,
  ECDSASignature
} from '../types/signature';
import { Role } from '../types/contributor';
import { Hash, Address, Timestamp, UUID, Satoshi } from '../types/common';
import { signTypedData, hashObject } from '../crypto/signature';
import { hash } from '../crypto/hash';
import { PROTOCOL_CONSTANTS } from '../constants';

/**
 * Get the BCCP EIP-712 domain configuration
 */
export function getBCCPDomain(chainId: number = 1): EIP712Domain {
  return {
    name: 'BCCP Protocol',
    version: '1',
    chainId,
    verifyingContract: PROTOCOL_CONSTANTS.REGISTRY_ADDRESS as Address
  };
}

/**
 * Create an outbound signature (A → B)
 */
export function createOutboundSignature(
  from: Address,
  to: Address,
  contentHash: Hash,
  previousHash: Hash | null,
  role: Role,
  privateKey: Buffer
): OutboundSignature {
  const timestamp = Date.now() as Timestamp;

  const message = {
    type: 'OUTBOUND',
    from,
    to,
    contentHash,
    previousHash,
    role,
    timestamp
  };

  const signature = signTypedData(getBCCPDomain(), message, privateKey);

  return { ...message, signature } as OutboundSignature;
}

/**
 * Create a counter signature (B acknowledges A)
 */
export function createCounterSignature(
  from: Address,
  outboundSignature: OutboundSignature,
  responsibilityAccepted: boolean,
  privateKey: Buffer
): CounterSignature {
  const timestamp = Date.now() as Timestamp;
  const outboundHash = hashObject(outboundSignature as unknown as Record<string, unknown>);

  const message = {
    type: 'COUNTER',
    from,
    originalSigner: outboundSignature.from,
    outboundSignatureHash: outboundHash,
    responsibilityAccepted,
    timestamp
  };

  const signature = signTypedData(getBCCPDomain(), message, privateKey);

  return { ...message, signature } as CounterSignature;
}

/**
 * Create a complete signature pair
 */
export function createSignaturePair(
  sender: { address: Address; privateKey: Buffer },
  receiver: { address: Address; privateKey: Buffer },
  contentHash: Hash,
  previousHash: Hash | null,
  role: Role
): SignaturePair {
  const outbound = createOutboundSignature(
    sender.address,
    receiver.address,
    contentHash,
    previousHash,
    role,
    sender.privateKey
  );

  const counter = createCounterSignature(
    receiver.address,
    outbound,
    true,
    receiver.privateKey
  );

  return { outbound, counter };
}

/**
 * Get hash of a signature pair
 */
export function getSignaturePairHash(pair: SignaturePair): Hash {
  return hashObject({
    outbound: pair.outbound,
    counter: pair.counter
  });
}

/**
 * Create a closure signature for sponsor
 */
export function createClosureSignature(
  sponsor: Address,
  txId: UUID,
  txMerkleRoot: Hash,
  paymentAmount: Satoshi,
  privateKey: Buffer
): ECDSASignature {
  const message = {
    sponsor,
    txId,
    txMerkleRoot,
    paymentAmount: paymentAmount.toString(),
    timestamp: Date.now()
  };

  return signTypedData(getBCCPDomain(), message, privateKey);
}

/**
 * Create a dispute signature
 */
export function createDisputeSignature(
  disputer: Address,
  txId: UUID,
  reason: string,
  privateKey: Buffer
): ECDSASignature {
  const message = {
    disputer,
    txId,
    reason,
    timestamp: Date.now()
  };

  return signTypedData(getBCCPDomain(), message, privateKey);
}

/**
 * Create a resolution signature
 */
export function createResolutionSignature(
  resolver: Address,
  txId: UUID,
  resolution: 'ACCEPT' | 'REJECT',
  privateKey: Buffer
): ECDSASignature {
  const message = {
    resolver,
    txId,
    resolution,
    timestamp: Date.now()
  };

  return signTypedData(getBCCPDomain(), message, privateKey);
}

/**
 * Get the message hash for an outbound signature
 */
export function getOutboundMessageHash(sig: OutboundSignature): Hash {
  return hashObject({
    type: sig.type,
    from: sig.from,
    to: sig.to,
    contentHash: sig.contentHash,
    previousHash: sig.previousHash,
    role: sig.role,
    timestamp: sig.timestamp
  });
}

/**
 * Get the message hash for a counter signature
 */
export function getCounterMessageHash(sig: CounterSignature): Hash {
  return hashObject({
    type: sig.type,
    from: sig.from,
    originalSigner: sig.originalSigner,
    outboundSignatureHash: sig.outboundSignatureHash,
    responsibilityAccepted: sig.responsibilityAccepted,
    timestamp: sig.timestamp
  });
}

/**
 * Compute the chain hash up to a given index
 */
export function computeChainHash(pairs: SignaturePair[], upToIndex: number): Hash {
  const hashes = pairs.slice(0, upToIndex + 1).map(getSignaturePairHash);
  return hash(hashes.join(''));
}
