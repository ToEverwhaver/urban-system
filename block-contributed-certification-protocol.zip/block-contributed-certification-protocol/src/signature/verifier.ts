import {
  OutboundSignature,
  CounterSignature,
  SignaturePair,
  SignatureVerificationResult
} from '../types/signature';
import { Address, Hash, Timestamp } from '../types/common';
import { recoverAddress, hashTypedData } from '../crypto/signature';
import { hashObject } from '../crypto/hash';
import { getBCCPDomain, getOutboundMessageHash, getCounterMessageHash } from './protocol';
import { PROTOCOL_CONSTANTS } from '../constants';

/**
 * Verify an outbound signature
 */
export function verifyOutboundSignature(
  sig: OutboundSignature,
  expectedFrom?: Address
): SignatureVerificationResult {
  try {
    // Must use EIP-712 typed data hash (same as signing)
    const message = {
      type: sig.type,
      from: sig.from,
      to: sig.to,
      contentHash: sig.contentHash,
      previousHash: sig.previousHash,
      role: sig.role,
      timestamp: sig.timestamp
    };
    const messageHash = hashTypedData(getBCCPDomain(), message);
    const recoveredAddress = recoverAddress(messageHash, sig.signature);

    if (expectedFrom && recoveredAddress !== expectedFrom) {
      return {
        valid: false,
        recoveredAddress,
        error: `Expected ${expectedFrom}, got ${recoveredAddress}`
      };
    }

    if (recoveredAddress !== sig.from) {
      return {
        valid: false,
        recoveredAddress,
        error: `Signature from mismatch: expected ${sig.from}`
      };
    }

    return { valid: true, recoveredAddress };
  } catch (e) {
    return {
      valid: false,
      error: `Verification failed: ${e}`
    };
  }
}

/**
 * Verify a counter signature
 */
export function verifyCounterSignature(
  sig: CounterSignature,
  expectedFrom?: Address
): SignatureVerificationResult {
  try {
    // Must use EIP-712 typed data hash (same as signing)
    const message = {
      type: sig.type,
      from: sig.from,
      originalSigner: sig.originalSigner,
      outboundSignatureHash: sig.outboundSignatureHash,
      responsibilityAccepted: sig.responsibilityAccepted,
      timestamp: sig.timestamp
    };
    const messageHash = hashTypedData(getBCCPDomain(), message);
    const recoveredAddress = recoverAddress(messageHash, sig.signature);

    if (expectedFrom && recoveredAddress !== expectedFrom) {
      return {
        valid: false,
        recoveredAddress,
        error: `Expected ${expectedFrom}, got ${recoveredAddress}`
      };
    }

    if (recoveredAddress !== sig.from) {
      return {
        valid: false,
        recoveredAddress,
        error: `Signature from mismatch: expected ${sig.from}`
      };
    }

    return { valid: true, recoveredAddress };
  } catch (e) {
    return {
      valid: false,
      error: `Verification failed: ${e}`
    };
  }
}

/**
 * Verify a complete signature pair
 */
export function verifySignaturePair(
  pair: SignaturePair,
  expectedFrom?: Address,
  expectedTo?: Address
): SignatureVerificationResult {
  const outboundResult = verifyOutboundSignature(pair.outbound, expectedFrom);
  if (!outboundResult.valid) {
    return {
      valid: false,
      error: `Outbound: ${outboundResult.error}`
    };
  }

  const counterResult = verifyCounterSignature(pair.counter, expectedTo);
  if (!counterResult.valid) {
    return {
      valid: false,
      error: `Counter: ${counterResult.error}`
    };
  }

  const outboundHash = hashObject(pair.outbound as unknown as Record<string, unknown>);
  if (outboundHash !== pair.counter.outboundSignatureHash) {
    return {
      valid: false,
      error: 'Counter signature references wrong outbound hash'
    };
  }

  if (pair.outbound.to !== pair.counter.from) {
    return {
      valid: false,
      error: 'Counter from does not match outbound to'
    };
  }

  if (pair.outbound.from !== pair.counter.originalSigner) {
    return {
      valid: false,
      error: 'Counter originalSigner does not match outbound from'
    };
  }

  return { valid: true };
}

/**
 * Verify signature timestamp is within acceptable window
 */
export function verifyTimestamp(
  timestamp: Timestamp,
  maxAgeMs: number = PROTOCOL_CONSTANTS.SIGNATURE_VALIDITY_MS
): boolean {
  const now = Date.now();
  const age = now - timestamp;
  return age >= 0 && age <= maxAgeMs;
}

/**
 * Verify signature pair timestamps
 */
export function verifySignaturePairTimestamps(
  pair: SignaturePair,
  maxAgeMs?: number
): SignatureVerificationResult {
  if (!verifyTimestamp(pair.outbound.timestamp, maxAgeMs)) {
    return {
      valid: false,
      error: 'Outbound signature expired'
    };
  }

  if (!verifyTimestamp(pair.counter.timestamp, maxAgeMs)) {
    return {
      valid: false,
      error: 'Counter signature expired'
    };
  }

  if (pair.counter.timestamp < pair.outbound.timestamp) {
    return {
      valid: false,
      error: 'Counter signature cannot precede outbound'
    };
  }

  return { valid: true };
}

/**
 * Full verification of signature pair with all checks
 */
export function verifySignaturePairFull(
  pair: SignaturePair,
  expectedFrom?: Address,
  expectedTo?: Address,
  checkTimestamps: boolean = true
): SignatureVerificationResult {
  const basicResult = verifySignaturePair(pair, expectedFrom, expectedTo);
  if (!basicResult.valid) {
    return basicResult;
  }

  if (checkTimestamps) {
    const timestampResult = verifySignaturePairTimestamps(pair);
    if (!timestampResult.valid) {
      return timestampResult;
    }
  }

  if (!pair.counter.responsibilityAccepted) {
    return {
      valid: false,
      error: 'Responsibility not accepted'
    };
  }

  return { valid: true };
}

/**
 * Verify a chain of signature pairs
 */
export function verifySignatureChain(
  pairs: SignaturePair[],
  startAddress: Address
): SignatureVerificationResult {
  let currentAddress = startAddress;

  for (let i = 0; i < pairs.length; i++) {
    const pair = pairs[i];

    const result = verifySignaturePair(pair, currentAddress);
    if (!result.valid) {
      return {
        valid: false,
        error: `Chain broken at index ${i}: ${result.error}`
      };
    }

    currentAddress = pair.counter.from;
  }

  return { valid: true };
}

/**
 * Extract all addresses from a signature chain
 */
export function extractChainAddresses(pairs: SignaturePair[]): Address[] {
  if (pairs.length === 0) return [];

  const addresses: Address[] = [pairs[0].outbound.from];
  for (const pair of pairs) {
    addresses.push(pair.counter.from);
  }
  return addresses;
}
