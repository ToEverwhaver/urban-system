import {
  Clarinet,
  Tx,
  Chain,
  Account,
  types,
} from "https://deno.land/x/clarinet@v1.7.1/index.ts";
import { assertEquals, assertExists } from "https://deno.land/std@0.170.0/testing/asserts.ts";

// ============================================
// TX Creation Tests
// ============================================

Clarinet.test({
  name: "create-tx: Successfully creates a new TX",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const contentHash = "0x" + "a".repeat(64);

    const block = chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], deployer.address),
    ]);

    assertEquals(block.receipts.length, 1);
    assertEquals(block.receipts[0].result, "(ok u1)");

    // Verify TX info
    const txInfo = chain.callReadOnlyFn(
      "bccp-core",
      "get-tx-info",
      [types.uint(1)],
      deployer.address
    );

    assertExists(txInfo.result);
    assertEquals(txInfo.result.includes("(ok"), true);
  },
});

Clarinet.test({
  name: "create-tx: TX counter increments correctly",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const contentHash = "0x" + "b".repeat(64);

    const block = chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], deployer.address),
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], deployer.address),
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], deployer.address),
    ]);

    assertEquals(block.receipts[0].result, "(ok u1)");
    assertEquals(block.receipts[1].result, "(ok u2)");
    assertEquals(block.receipts[2].result, "(ok u3)");

    const count = chain.callReadOnlyFn("bccp-core", "get-tx-count", [], deployer.address);
    assertEquals(count.result, "u3");
  },
});

// ============================================
// Accept as Receiver Tests
// ============================================

Clarinet.test({
  name: "accept-as-receiver: B can accept from A",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!; // A (initiator)
    const bob = accounts.get("wallet_2")!;   // B (receiver)
    const contentHash = "0x" + "c".repeat(64);

    // A creates TX
    let block = chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    assertEquals(block.receipts[0].result, "(ok u1)");

    // B accepts
    block = chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);
    assertEquals(block.receipts[0].result, "(ok true)");

    // Verify participant count
    const txInfo = chain.callReadOnlyFn("bccp-core", "get-tx-full", [types.uint(1)], alice.address);
    assertExists(txInfo.result);
    assertEquals(txInfo.result.includes("participant-count: u2"), true);
  },
});

Clarinet.test({
  name: "accept-as-receiver: Cannot accept twice",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const charlie = accounts.get("wallet_3")!;
    const contentHash = "0x" + "d".repeat(64);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);

    // Charlie tries to accept but B already did
    const block = chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], charlie.address),
    ]);
    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Add Participant Tests
// ============================================

Clarinet.test({
  name: "add-participant: Can add C after A and B",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const charlie = accounts.get("wallet_3")!;
    const contentHash = "0x" + "e".repeat(64);

    // Setup: A creates, B accepts
    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);

    // B adds C
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-core",
        "add-participant",
        [types.uint(1), types.principal(charlie.address)],
        bob.address
      ),
    ]);
    assertEquals(block.receipts[0].result, "(ok true)");

    // Verify chain
    const entry = chain.callReadOnlyFn(
      "bccp-core",
      "get-chain-entry",
      [types.uint(1), types.uint(2)],
      alice.address
    );
    assertExists(entry.result);
    assertEquals(entry.result.includes(charlie.address), true);
  },
});

Clarinet.test({
  name: "add-participant: Only last participant can add next",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const charlie = accounts.get("wallet_3")!;
    const contentHash = "0x" + "f".repeat(64);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);

    // Alice (not the last) tries to add Charlie
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-core",
        "add-participant",
        [types.uint(1), types.principal(charlie.address)],
        alice.address
      ),
    ]);
    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Closure Declaration Tests
// ============================================

Clarinet.test({
  name: "declare-closure-ready: Anyone can declare closure",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const charlie = accounts.get("wallet_3")!;
    const contentHash = "0x" + "11".repeat(32);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);

    // Charlie (non-participant) declares closure
    const block = chain.mineBlock([
      Tx.contractCall("bccp-core", "declare-closure-ready", [types.uint(1)], charlie.address),
    ]);
    assertEquals(block.receipts[0].result, "(ok true)");

    const txInfo = chain.callReadOnlyFn("bccp-core", "get-tx-full", [types.uint(1)], alice.address);
    assertEquals(txInfo.result.includes("closure-declared: true"), true);
  },
});

Clarinet.test({
  name: "declare-closure-ready: Cannot declare if chain too short",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const contentHash = "0x" + "22".repeat(32);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);

    // Try to declare with only A (no B yet)
    const block = chain.mineBlock([
      Tx.contractCall("bccp-core", "declare-closure-ready", [types.uint(1)], alice.address),
    ]);
    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Sponsor Close Tests
// ============================================

Clarinet.test({
  name: "sponsor-close: Successfully closes TX with payment",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const sponsor = accounts.get("wallet_4")!;
    const contentHash = "0x" + "33".repeat(32);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "declare-closure-ready", [types.uint(1)], alice.address),
    ]);

    // Sponsor closes
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-core",
        "sponsor-close",
        [types.uint(1), types.uint(1000000)], // 1 STX
        sponsor.address
      ),
    ]);
    assertEquals(block.receipts[0].result, "(ok true)");

    const txInfo = chain.callReadOnlyFn("bccp-core", "get-tx-full", [types.uint(1)], alice.address);
    assertEquals(txInfo.result.includes('state: "closed"'), true);
    assertEquals(txInfo.result.includes(sponsor.address), true);
  },
});

Clarinet.test({
  name: "sponsor-close: Cannot close without closure declaration",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const sponsor = accounts.get("wallet_4")!;
    const contentHash = "0x" + "44".repeat(32);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);

    // Try to sponsor without closure declaration
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-core",
        "sponsor-close",
        [types.uint(1), types.uint(1000000)],
        sponsor.address
      ),
    ]);
    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Rejection Tests
// ============================================

Clarinet.test({
  name: "reject-tx: Next participant can reject",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const charlie = accounts.get("wallet_3")!;
    const contentHash = "0x" + "55".repeat(32);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);
    chain.mineBlock([
      Tx.contractCall(
        "bccp-core",
        "add-participant",
        [types.uint(1), types.principal(charlie.address)],
        bob.address
      ),
    ]);

    // Charlie (next participant) rejects
    const block = chain.mineBlock([
      Tx.contractCall("bccp-core", "reject-tx", [types.uint(1)], charlie.address),
    ]);
    assertEquals(block.receipts[0].result, "(ok true)");

    const txInfo = chain.callReadOnlyFn("bccp-core", "get-tx-full", [types.uint(1)], alice.address);
    assertEquals(txInfo.result.includes('state: "rejected"'), true);
  },
});

// ============================================
// Read Function Tests
// ============================================

Clarinet.test({
  name: "get-chain-entry: Returns correct chain data",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;
    const contentHash = "0x" + "66".repeat(32);

    chain.mineBlock([
      Tx.contractCall("bccp-core", "create-tx", [types.buff(contentHash)], alice.address),
    ]);
    chain.mineBlock([
      Tx.contractCall("bccp-core", "accept-as-receiver", [types.uint(1)], bob.address),
    ]);

    const entry0 = chain.callReadOnlyFn(
      "bccp-core",
      "get-chain-entry",
      [types.uint(1), types.uint(0)],
      alice.address
    );
    assertEquals(entry0.result.includes(alice.address), true);
    assertEquals(entry0.result.includes('role: "initiator"'), true);

    const entry1 = chain.callReadOnlyFn(
      "bccp-core",
      "get-chain-entry",
      [types.uint(1), types.uint(1)],
      alice.address
    );
    assertEquals(entry1.result.includes(bob.address), true);
    assertEquals(entry1.result.includes('role: "receiver"'), true);
  },
});
