import { TX, TXState, TXClosure, DistributionResult } from '../types/tx';
import { ECDSASignature } from '../types/signature';
import { Address, Satoshi, Timestamp, Hash, UUID } from '../types/common';
import { validateTX, validateForClosure } from '../tx/validator';
import { distributeRewards, processTokenDecisions } from './distribution';

export interface ClosureRequest {
  txId: UUID;
  sponsor: Address;
  sponsorSignature: ECDSASignature;
  paymentAmount: Satoshi;
  paymentTxHash?: Hash;
}

export interface ClosureResult {
  success: boolean;
  tx?: TX;
  distribution?: DistributionResult[];
  error?: string;
}

export interface TokenDecision {
  contributor: Address;
  accept: boolean;
}

/**
 * Process TX closure
 */
export async function processClosure(
  tx: TX,
  request: ClosureRequest,
  tokenDecisions?: TokenDecision[]
): Promise<ClosureResult> {
  const validation = validateClosureRequest(tx, request);
  if (!validation.valid) {
    return { success: false, error: validation.errors.join(', ') };
  }

  const closureValidation = validateForClosure(tx);
  if (!closureValidation.valid) {
    return { success: false, error: closureValidation.errors.join(', ') };
  }

  let distribution = await distributeRewards(tx, request.paymentAmount);

  if (tokenDecisions) {
    const decisions = new Map(tokenDecisions.map(d => [d.contributor, d.accept]));
    distribution = processTokenDecisions(distribution, decisions);
  }

  const now = Date.now() as Timestamp;
  const closure: TXClosure = {
    sponsor: request.sponsor,
    sponsorSignature: request.sponsorSignature,
    paymentAmount: request.paymentAmount,
    paymentTxHash: request.paymentTxHash,
    closedAt: now,
    distribution
  };

  const closedTX: TX = {
    ...tx,
    state: TXState.Closed,
    closedAt: now,
    updatedAt: now,
    closure
  };

  return { success: true, tx: closedTX, distribution };
}

/**
 * Validate closure request
 */
export function validateClosureRequest(
  tx: TX,
  request: ClosureRequest
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (tx.id !== request.txId) {
    errors.push('TX ID mismatch');
  }

  if (tx.state !== TXState.Open) {
    errors.push(`TX not open: ${tx.state}`);
  }

  if (request.paymentAmount <= 0n) {
    errors.push('Payment must be positive');
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Initiate closure (move to pending state)
 */
export function initiateClosure(tx: TX, sponsor: Address): TX {
  if (tx.state !== TXState.Open) {
    throw new Error(`Cannot initiate closure in state: ${tx.state}`);
  }

  return {
    ...tx,
    state: TXState.PendingClosure,
    updatedAt: Date.now() as Timestamp
  };
}

/**
 * Cancel pending closure
 */
export function cancelClosure(tx: TX): TX {
  if (tx.state !== TXState.PendingClosure) {
    throw new Error(`Cannot cancel closure in state: ${tx.state}`);
  }

  return {
    ...tx,
    state: TXState.Open,
    updatedAt: Date.now() as Timestamp
  };
}

/**
 * Get closure summary
 */
export function getClosureSummary(tx: TX): {
  isClosed: boolean;
  sponsor?: Address;
  paymentAmount?: Satoshi;
  closedAt?: Timestamp;
  contributorCount: number;
  totalDistributed?: Satoshi;
} {
  const summary = {
    isClosed: tx.state === TXState.Closed,
    contributorCount: tx.chain.length
  };

  if (tx.closure) {
    return {
      ...summary,
      sponsor: tx.closure.sponsor,
      paymentAmount: tx.closure.paymentAmount,
      closedAt: tx.closure.closedAt,
      totalDistributed: tx.closure.distribution.reduce(
        (sum, d) => (sum + d.btcAmount) as Satoshi,
        0n as Satoshi
      )
    };
  }

  return summary;
}

/**
 * Verify closure completeness
 */
export function verifyClosureComplete(tx: TX): boolean {
  if (tx.state !== TXState.Closed || !tx.closure) {
    return false;
  }

  const distributedAddresses = new Set(tx.closure.distribution.map(d => d.contributor));

  for (const entry of tx.chain) {
    if (!distributedAddresses.has(entry.contributor.address)) {
      return false;
    }
  }

  return true;
}
