import {
  Clarinet,
  Tx,
  Chain,
  Account,
  types,
} from "https://deno.land/x/clarinet@v1.7.1/index.ts";
import { assertEquals } from "https://deno.land/std@0.170.0/testing/asserts.ts";

// ============================================
// Portfolio Summary Tests
// ============================================

Clarinet.test({
  name: "get-portfolio-summary: Returns empty for new address",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;

    const result = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-portfolio-summary",
      [types.principal(alice.address)],
      alice.address
    );

    assertEquals(result.result.includes("total-participations: u0"), true);
  },
});

Clarinet.test({
  name: "get-full-portfolio-summary: Returns extended data",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    // Authorize caller and record participation
    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        deployer.address
      ),
    ]);

    const result = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-full-portfolio-summary",
      [types.principal(alice.address)],
      deployer.address
    );

    assertEquals(result.result.includes("total-participations: u1"), true);
    assertEquals(result.result.includes("initiated-count: u1"), true);
  },
});

// ============================================
// Record Participation Tests
// ============================================

Clarinet.test({
  name: "record-participation: Successfully records initiator",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    // Check participation record
    const record = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-participation",
      [types.principal(alice.address), types.uint(1)],
      deployer.address
    );

    assertEquals(record.result.includes('role: "initiator"'), true);
    assertEquals(record.result.includes("position-in-chain: u0"), true);
  },
});

Clarinet.test({
  name: "record-participation: Successfully records receiver",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const bob = accounts.get("wallet_2")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(bob.address),
          types.uint(1),
          types.ascii("receiver"),
          types.uint(1)
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const record = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-participation",
      [types.principal(bob.address), types.uint(1)],
      deployer.address
    );

    assertEquals(record.result.includes('role: "receiver"'), true);
    assertEquals(record.result.includes("position-in-chain: u1"), true);
  },
});

Clarinet.test({
  name: "record-participation: Cannot record same participation twice",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        deployer.address
      ),
    ]);

    // Try to record again
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("participant"),
          types.uint(2)
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Record Rejection Tests
// ============================================

Clarinet.test({
  name: "record-rejection: Successfully records rejection responsibility",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    // First record participation
    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        deployer.address
      ),
    ]);

    // Then record rejection
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-rejection",
        [
          types.principal(alice.address),
          types.uint(1),
          types.uint(5000) // 50% responsibility
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const record = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-participation",
      [types.principal(alice.address), types.uint(1)],
      deployer.address
    );

    assertEquals(record.result.includes('state: "rejected"'), true);
    assertEquals(record.result.includes("responsibility-points: u5000"), true);
  },
});

Clarinet.test({
  name: "record-rejection: Cannot record for non-participant",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    // Try to record rejection without participation
    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-rejection",
        [
          types.principal(alice.address),
          types.uint(1),
          types.uint(5000)
        ],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

// ============================================
// Record Closure Tests
// ============================================

Clarinet.test({
  name: "record-closure: Successfully records closure",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        deployer.address
      ),
    ]);

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-closure",
        [types.principal(alice.address), types.uint(1)],
        deployer.address
      ),
    ]);

    assertEquals(block.receipts[0].result, "(ok true)");

    const record = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-participation",
      [types.principal(alice.address), types.uint(1)],
      deployer.address
    );

    assertEquals(record.result.includes('state: "closed"'), true);
  },
});

// ============================================
// TX Lists Tests
// ============================================

Clarinet.test({
  name: "get-participant-tx-count: Returns correct count",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    // Record multiple participations
    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        deployer.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(2),
          types.ascii("participant"),
          types.uint(3)
        ],
        deployer.address
      ),
    ]);

    const count = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-participant-tx-count",
      [types.principal(alice.address)],
      deployer.address
    );

    assertEquals(count.result, "u2");
  },
});

Clarinet.test({
  name: "get-tx-participant-count: Returns correct count",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const deployer = accounts.get("deployer")!;
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(deployer.address)],
        deployer.address
      ),
    ]);

    // Record multiple participants in same TX
    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(alice.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        deployer.address
      ),
    ]);

    chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(bob.address),
          types.uint(1),
          types.ascii("receiver"),
          types.uint(1)
        ],
        deployer.address
      ),
    ]);

    const count = chain.callReadOnlyFn(
      "bccp-portfolio",
      "get-tx-participant-count",
      [types.uint(1)],
      deployer.address
    );

    assertEquals(count.result, "u2");
  },
});

// ============================================
// Authorization Tests
// ============================================

Clarinet.test({
  name: "authorize-caller: Only owner can authorize",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "authorize-caller",
        [types.principal(bob.address)],
        alice.address
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});

Clarinet.test({
  name: "record-participation: Unauthorized caller fails",
  async fn(chain: Chain, accounts: Map<string, Account>) {
    const alice = accounts.get("wallet_1")!;
    const bob = accounts.get("wallet_2")!;

    const block = chain.mineBlock([
      Tx.contractCall(
        "bccp-portfolio",
        "record-participation",
        [
          types.principal(bob.address),
          types.uint(1),
          types.ascii("initiator"),
          types.uint(0)
        ],
        alice.address // Not authorized
      ),
    ]);

    assertEquals(block.receipts[0].result.includes("err"), true);
  },
});
