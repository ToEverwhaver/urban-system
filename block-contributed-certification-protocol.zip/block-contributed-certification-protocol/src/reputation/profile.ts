import { ContributorProfile, Role } from '../types/contributor';
import { DistributionResult } from '../types/tx';
import { Address, Satoshi, TokenAmount, Timestamp } from '../types/common';

const profiles = new Map<Address, ContributorProfile>();

/**
 * Get or create a contributor profile
 */
export function getOrCreateProfile(address: Address): ContributorProfile {
  let profile = profiles.get(address);

  if (!profile) {
    const now = Date.now() as Timestamp;
    profile = {
      address,
      closedTXCount: 0,
      totalEarnedBTC: 0n as Satoshi,
      totalEarnedToken: 0n as TokenAmount,
      acceptedTokens: 0n as TokenAmount,
      forfeitedTokens: 0n as TokenAmount,
      acceptRate: 1.0,
      roleCount: {
        [Role.Initiator]: 0,
        [Role.Receiver]: 0,
        [Role.Producer]: 0,
        [Role.Editor]: 0,
        [Role.Custom]: 0
      },
      reputationScore: 500,
      firstActivityAt: now,
      lastActivityAt: now
    };
    profiles.set(address, profile);
  }

  return profile;
}

/**
 * Update profile from closure distribution
 */
export function updateProfileFromClosure(dist: DistributionResult): ContributorProfile {
  const profile = getOrCreateProfile(dist.contributor);
  const now = Date.now() as Timestamp;

  profile.closedTXCount += 1;
  profile.roleCount[dist.role] += 1;
  profile.totalEarnedBTC = (profile.totalEarnedBTC + dist.btcAmount) as Satoshi;
  profile.totalEarnedToken = (profile.totalEarnedToken + dist.tokenAmount) as TokenAmount;

  if (dist.tokenAccepted) {
    profile.acceptedTokens = (profile.acceptedTokens + dist.tokenAmount) as TokenAmount;
  } else {
    profile.forfeitedTokens = (profile.forfeitedTokens + dist.tokenAmount) as TokenAmount;
  }

  const total = profile.acceptedTokens + profile.forfeitedTokens;
  profile.acceptRate = total > 0n ? Number(profile.acceptedTokens) / Number(total) : 1.0;
  profile.lastActivityAt = now;
  profile.reputationScore = calculateReputationScore(profile);

  profiles.set(dist.contributor, profile);
  return profile;
}

/**
 * Calculate reputation score
 */
function calculateReputationScore(profile: ContributorProfile): number {
  let score = 500;

  score += Math.min(profile.closedTXCount * 5, 200);

  score += Math.floor(profile.acceptRate * 150);

  const rolesUsed = Object.values(profile.roleCount).filter(c => c > 0).length;
  score += rolesUsed * 20;

  const days = (Date.now() - profile.firstActivityAt) / (1000 * 60 * 60 * 24);
  const txPerDay = profile.closedTXCount / Math.max(days, 1);
  score += Math.min(Math.floor(txPerDay * 50), 50);

  return Math.min(score, 1000);
}

/**
 * Get profile by address
 */
export function getProfile(address: Address): ContributorProfile | undefined {
  return profiles.get(address);
}

/**
 * Get all profiles
 */
export function getAllProfiles(): ContributorProfile[] {
  return Array.from(profiles.values());
}

/**
 * Get top contributors by reputation
 */
export function getTopContributors(limit: number = 100): ContributorProfile[] {
  return getAllProfiles()
    .sort((a, b) => b.reputationScore - a.reputationScore)
    .slice(0, limit);
}

/**
 * Get contributors by role
 */
export function getContributorsByRole(role: Role, limit: number = 100): ContributorProfile[] {
  return getAllProfiles()
    .filter(p => p.roleCount[role] > 0)
    .sort((a, b) => b.roleCount[role] - a.roleCount[role])
    .slice(0, limit);
}

/**
 * Get contributors by minimum reputation
 */
export function getContributorsByMinReputation(
  minScore: number,
  limit: number = 100
): ContributorProfile[] {
  return getAllProfiles()
    .filter(p => p.reputationScore >= minScore)
    .sort((a, b) => b.reputationScore - a.reputationScore)
    .slice(0, limit);
}

/**
 * Get recently active contributors
 */
export function getRecentlyActive(
  sinceMs: number = 24 * 60 * 60 * 1000,
  limit: number = 100
): ContributorProfile[] {
  const cutoff = Date.now() - sinceMs;
  return getAllProfiles()
    .filter(p => p.lastActivityAt >= cutoff)
    .sort((a, b) => b.lastActivityAt - a.lastActivityAt)
    .slice(0, limit);
}

/**
 * Update multiple profiles from distribution array
 */
export function updateProfilesFromDistribution(
  distributions: DistributionResult[]
): ContributorProfile[] {
  return distributions.map(updateProfileFromClosure);
}

/**
 * Clear all profiles (for testing)
 */
export function clearProfiles(): void {
  profiles.clear();
}

/**
 * Get profile count
 */
export function getProfileCount(): number {
  return profiles.size;
}
