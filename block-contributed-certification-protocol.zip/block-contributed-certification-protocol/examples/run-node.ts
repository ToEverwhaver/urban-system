/**
 * Example: Running a relay node
 */

import {
  registerNode,
  activateNode,
  processHeartbeat,
  recordRelay,
  selectRoute,
  verifyRoute,
  getRouteQuality,
  createSlashingEvent,
  isAtRisk,
  getActiveNodes,
  getNodeCount,
  generateKeyPair,
  privateKeyToAddress,
  hash,
  Satoshi,
  Timestamp,
  NodeStatus,
  SlashReason
} from '../src';

async function main() {
  console.log('=== BCCP Relay Node Example ===\n');

  // Generate operator keypairs
  const operators = Array.from({ length: 5 }, () => {
    const keys = generateKeyPair();
    return {
      keys,
      address: privateKeyToAddress(keys.privateKey)
    };
  });

  console.log('Registering 5 relay nodes...\n');

  // Register nodes
  const nodes = operators.map((op, i) => {
    const node = registerNode({
      operator: op.address,
      publicKey: `0x${op.keys.publicKey.toString('hex')}` as any,
      endpoint: `https://node${i + 1}.bccp.network:8443`,
      stake: (500000n + BigInt(i * 100000)) as Satoshi // Variable stake
    });

    console.log(`Node ${i + 1}:`);
    console.log(`  ID: ${node.id.slice(0, 18)}...`);
    console.log(`  Operator: ${node.operator}`);
    console.log(`  Stake: ${Number(node.stake) / 100_000_000} BTC`);
    console.log(`  Status: ${node.status}`);
    console.log('');

    return node;
  });

  // Activate all nodes
  console.log('Activating nodes...\n');
  for (const node of nodes) {
    activateNode(node.id);
  }

  const stats = getNodeCount();
  console.log(`Network Stats: ${stats.active} active, ${stats.pending} pending, ${stats.total} total\n`);

  // Simulate heartbeats
  console.log('Simulating heartbeats...\n');
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    const updatedNode = processHeartbeat({
      nodeId: node.id,
      timestamp: Date.now() as Timestamp,
      metrics: {
        uptime: 3600 * (i + 1), // Variable uptime
        latencyAvg: 20 + i * 5, // Variable latency
        latencyP99: 50 + i * 10,
        bandwidth: 100_000_000,
        activeConnections: 10 + i,
        cpuUsage: 0.3 + i * 0.1,
        memoryUsage: 0.4 + i * 0.05
      },
      signature: { r: '0x' as any, s: '0x' as any, v: 27 }
    });

    console.log(`Node ${i + 1} after heartbeat:`);
    console.log(`  Score: ${updatedNode.score}`);
    console.log(`  Uptime Score: ${updatedNode.uptimeScore}`);
    console.log(`  Latency Score: ${updatedNode.latencyScore}`);
  }
  console.log('');

  // Simulate relay operations
  console.log('Simulating relay operations...\n');
  for (let i = 0; i < nodes.length; i++) {
    const successCount = 10 - i; // First nodes more successful
    const failCount = i;

    for (let j = 0; j < successCount; j++) {
      recordRelay(nodes[i].id, true);
    }
    for (let j = 0; j < failCount; j++) {
      recordRelay(nodes[i].id, false);
    }
  }

  // Show updated scores
  console.log('Updated node scores after relays:');
  const activeNodes = getActiveNodes();
  for (const node of activeNodes) {
    console.log(`  Node ${node.id.slice(0, 10)}... Score: ${node.score}, Honesty: ${node.honestyScore}%`);
  }
  console.log('');

  // Select route
  console.log('=== Route Selection ===\n');
  const route = selectRoute([], 3);

  if (route) {
    console.log(`Route ID: ${route.id.slice(0, 18)}...`);
    console.log(`Expires: ${new Date(route.expiresAt).toISOString()}`);
    console.log(`Quality Score: ${getRouteQuality(route)}`);
    console.log('');
    console.log('Route nodes:');
    for (const rn of route.nodes) {
      const pos = rn.position === 0 ? 'Entry' : rn.position === 1 ? 'Middle' : 'Exit';
      console.log(`  ${pos}: ${rn.node.id.slice(0, 10)}... (Score: ${rn.node.score})`);
    }
    console.log('');

    // Verify route
    const verification = verifyRoute(route);
    console.log(`Route valid: ${verification.valid}`);
    if (!verification.valid) {
      console.log(`Reason: ${verification.reason}`);
    }
  } else {
    console.log('Could not create route (not enough nodes)');
  }
  console.log('');

  // Check for at-risk nodes
  console.log('=== Risk Assessment ===\n');
  for (const node of nodes) {
    const risk = isAtRisk(node.id);
    if (risk.atRisk) {
      console.log(`Node ${node.id.slice(0, 10)}... is AT RISK`);
      console.log(`  Reasons: ${risk.reasons.join(', ')}`);
    }
  }

  // Simulate slashing event
  console.log('\n=== Slashing Example ===\n');
  const worstNode = nodes[nodes.length - 1];
  console.log(`Creating slashing event for node ${worstNode.id.slice(0, 10)}...`);

  const slashEvent = createSlashingEvent(
    worstNode.id,
    SlashReason.ProtocolViolation,
    hash('Evidence of violation') as any
  );

  console.log(`Slashing Event:`);
  console.log(`  ID: ${slashEvent.id.slice(0, 18)}...`);
  console.log(`  Reason: ${slashEvent.reason}`);
  console.log(`  Amount: ${Number(slashEvent.amount) / 100_000_000} BTC`);
  console.log(`  Appeal Deadline: ${new Date(slashEvent.appealDeadline).toISOString()}`);

  console.log('\n=== Example Complete ===');
}

main().catch(console.error);
