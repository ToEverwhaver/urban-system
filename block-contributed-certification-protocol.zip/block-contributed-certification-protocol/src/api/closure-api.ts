import { TX, DistributionResult } from '../types/tx';
import { Address, UUID, Satoshi, TokenAmount } from '../types/common';
import { ECDSASignature } from '../types/signature';
import { processClosure, TokenDecision, previewDistribution, getClosureSummary } from '../closure';
import { mintTokens } from '../token/minter';
import { processForfeitDecisions } from '../token/forfeit';
import { updateProfilesFromDistribution } from '../reputation/profile';
import { getDefaultStorage } from '../storage/memory';

export interface ClosureAPIRequest {
  txId: UUID;
  sponsor: Address;
  sponsorSignature: ECDSASignature;
  paymentAmount: Satoshi;
  paymentTxHash?: string;
  tokenDecisions?: TokenDecision[];
}

export interface ClosureAPIResponse {
  success: boolean;
  tx?: TX;
  distribution?: DistributionResult[];
  tokensIssued?: TokenAmount;
  error?: string;
}

/**
 * Execute full closure workflow
 */
export async function executeClosureWorkflow(
  request: ClosureAPIRequest
): Promise<ClosureAPIResponse> {
  try {
    const tx = await getDefaultStorage().getTX(request.txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const closureResult = await processClosure(
      tx,
      {
        txId: request.txId,
        sponsor: request.sponsor,
        sponsorSignature: request.sponsorSignature,
        paymentAmount: request.paymentAmount
      },
      request.tokenDecisions
    );

    if (!closureResult.success || !closureResult.tx || !closureResult.distribution) {
      return { success: false, error: closureResult.error };
    }

    const issuance = await mintTokens(request.txId, closureResult.distribution);

    processForfeitDecisions(request.txId, closureResult.distribution);

    updateProfilesFromDistribution(closureResult.distribution);

    await getDefaultStorage().saveTX(closureResult.tx);
    await getDefaultStorage().saveIssuance(issuance);

    return {
      success: true,
      tx: closureResult.tx,
      distribution: closureResult.distribution,
      tokensIssued: issuance.amount
    };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get closure preview
 */
export async function getClosurePreview(
  txId: UUID,
  paymentAmount: Satoshi
): Promise<{
  success: boolean;
  preview?: ReturnType<typeof previewDistribution>;
  error?: string;
}> {
  try {
    const tx = await getDefaultStorage().getTX(txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const preview = previewDistribution(tx, paymentAmount);
    return { success: true, preview };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Get closure details for a TX
 */
export async function getClosureDetails(
  txId: UUID
): Promise<{
  success: boolean;
  summary?: ReturnType<typeof getClosureSummary>;
  error?: string;
}> {
  try {
    const tx = await getDefaultStorage().getTX(txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const summary = getClosureSummary(tx);
    return { success: true, summary };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/**
 * Estimate earnings for a contributor
 */
export async function estimateEarnings(
  txId: UUID,
  contributorAddress: Address,
  paymentAmount: Satoshi
): Promise<{
  success: boolean;
  btcAmount?: Satoshi;
  tokenAmount?: TokenAmount;
  error?: string;
}> {
  try {
    const tx = await getDefaultStorage().getTX(txId);
    if (!tx) {
      return { success: false, error: 'TX not found' };
    }

    const preview = previewDistribution(tx, paymentAmount);
    const contribution = preview.distributions.find(
      d => d.address === contributorAddress
    );

    if (!contribution) {
      return { success: false, error: 'Contributor not found in TX' };
    }

    return {
      success: true,
      btcAmount: contribution.btcAmount,
      tokenAmount: contribution.tokenAmount
    };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}
